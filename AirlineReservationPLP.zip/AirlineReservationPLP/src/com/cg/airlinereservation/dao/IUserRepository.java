/**
 ***********************************************************************************
 * File:        IUserRepository.java
 * Package:     com.cg.airlinereservation.dao
 * Desc:        an interface to userRepository
 * Version:     1.0
 * Modifications:
 * Author:            Date:          Change Description:
 * Group 1     		21-01-2017     		Initial Version
 ***********************************************************************************
 */
package com.cg.airlinereservation.dao;

import com.cg.airlinereservation.entities.UserARS;
import com.cg.airlinereservation.exception.ARSException;

public interface IUserRepository 
{
	/**
	 * Method to fetch a user
	 * @param user
	 * @return UserARS
	 * @throws ARSException
	 */
	public UserARS getUser(UserARS user) throws ARSException;

	/**
	 * Method to add a new user after registration
	 * @param user
	 * @throws ARSException
	 */
	public void addUser(UserARS user) throws ARSException;

	/**
	 * Method to remove a user
	 * @param user
	 * @throws ARSException
	 */
	public void removeUser(UserARS user) throws ARSException;

	/**
	 * Method to update a user from customer to executive
	 * @param user
	 * @throws ARSException
	 */
	public void updateUser(UserARS user) throws ARSException;

	/**
	 * Method to fetch user details
	 * @param user
	 * @return UserARS
	 * @throws ARSException
	 */
	public UserARS getUserDetails(UserARS user) throws ARSException;

	/**
	 * Method to update password for a user
	 * @param user
	 * @throws ARSException
	 */
	public void updatePassword(UserARS user) throws ARSException;
}
