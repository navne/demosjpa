/**
 ***********************************************************************************
 * File:        UserRepositoryImpl.java
 * Package:     com.cg.airlinereservation.dao
 * Desc:        to get details about user and do user related operations
 * Version:     1.0
 * Modifications:
 * Author:            Date:          Change Description:
 * Group 1     		21-01-2017     		Initial Version
 ***********************************************************************************
*/
package com.cg.airlinereservation.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.servlet.Registration;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.airlinereservation.encryption.encrypt;
import com.cg.airlinereservation.entities.UserARS;
import com.cg.airlinereservation.exception.ARSException;
import com.cg.airlinereservation.logFile.LogInfo;

@Repository
public class UserRepositoryImpl implements IUserRepository {

	@PersistenceContext
	EntityManager manager;
	
	private static Logger myLogger;
	/**
	 * Default constructor for UserRepositoryImpl
	 */
	public UserRepositoryImpl() {
		myLogger =  Logger.getLogger(LogInfo.class);
	}
	
	/* (non-Javadoc)
	 * to get a specific user after verfying his credentials from the database
	 * @see com.cg.airlinereservation.dao.IUserRepository#getUser(com.cg.airlinereservation.entities.UserARS)
	 */
	@Override
	public UserARS getUser(UserARS user) throws ARSException
	{
		try {
			TypedQuery<UserARS> query = manager.createQuery("SELECT u FROM UserARS u where userName = :puserName AND pwd = :ppwd ", UserARS.class);
			query.setParameter("puserName", user.getUserName());
			query.setParameter("ppwd", encrypt.encrypt(user.getpWd()));
			return query.getSingleResult();
		} catch (Exception e) {
			myLogger.error(e.getMessage());
			throw new ARSException("ERROR: User Doesn't Exist,Please Check UserName/Password");
		}
		
	}

	/* (non-Javadoc)
	 * to register a new user
	 * @see com.cg.airlinereservation.dao.IUserRepository#addUser(com.cg.airlinereservation.entities.UserARS)
	 */
	@Override
	public void addUser(UserARS user) throws ARSException {
		try {
			user.setpWd(encrypt.encrypt(user.getpWd()));
		} catch (Exception e) {
			myLogger.error(e.getMessage(),e);
			throw new ARSException("Registration failed");
		}
		manager.persist(user);
		manager.flush();

	}

	/* (non-Javadoc)
	 * to remove the user from database
	 * @see com.cg.airlinereservation.dao.IUserRepository#removeUser(com.cg.airlinereservation.entities.UserARS)
	 */
	@Override
	public void removeUser(UserARS user) throws ARSException {
		manager.remove(user);

	}

	/* (non-Javadoc)
	 * to update the role of user
	 * @see com.cg.airlinereservation.dao.IUserRepository#updateUser(com.cg.airlinereservation.entities.UserARS)
	 */
	@Override
	public void updateUser(UserARS user) throws ARSException {
			manager.merge(user);
	}

	/* (non-Javadoc)
	 * to get the user details
	 * @see com.cg.airlinereservation.dao.IUserRepository#getUserDetails(com.cg.airlinereservation.entities.UserARS)
	 */
	@Override
	public UserARS getUserDetails(UserARS user)throws ARSException {
		UserARS userDB = manager.find(UserARS.class, user.getuMail());
		if(userDB == null){
			throw new ARSException("No Such User Exists");
		}
		return userDB;
	}

	/* (non-Javadoc)
	 * To update password for a user
	 * @see com.cg.airlinereservation.dao.IUserRepository#updatePassword(com.cg.airlinereservation.entities.UserARS)
	 */
	@Override
	public void updatePassword(UserARS user) throws ARSException {
		try {
			UserARS userDB = getUserDetails(user);
			userDB.setpWd(encrypt.encrypt(user.getpWd()));
			myLogger.info("Password Updated Successfully");
		} catch (Exception e) {
			 myLogger.error(e.getMessage());
			 throw new ARSException("Password Updation Failed");
	}
}
}
