
package com.cg.airlinereservation.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.airlinereservation.entities.BookingInfo;
import com.cg.airlinereservation.exception.ARSException;
import com.cg.airlinereservation.logFile.LogInfo;

/**
 ***********************************************************************************
 * File:        ExecutiveRepositoryImpl.java
 * Package:     com.cg.airlinereservation.dao
 * Desc:        to see the flight details and booking details of a particular flight
 * Version:     1.0
 * Modifications:
 * Author:            Date:          Change Description:
 * Group 1     		21-01-2017     		Initial Version
 ***********************************************************************************
*/
@Repository
public class ExecutiveRepositoryImpl implements IExecutiveRepository {

	@PersistenceContext
	private EntityManager manager;
	
	
	private static Logger myLogger;
	
	
	/**
	 * Default constructor of ExecutiveRepositoryImpl
	 */
	public ExecutiveRepositoryImpl() {
		myLogger =  Logger.getLogger(LogInfo.class);
	}
	
	
	/* (non-Javadoc)
	 * to show the booking details
	 * @see com.cg.airlinereservation.dao.IExecutiveRepository#showBookings(int)
	 */
	@Override
	public List<BookingInfo> showBookings(int flightno) throws ARSException {
		
		TypedQuery<BookingInfo> query = manager.createQuery("SELECT b FROM BookingInfo b where flightno = :pflightno ", BookingInfo.class);
		myLogger.info(query.getResultList());
		return query.getResultList();
	
	}

}
