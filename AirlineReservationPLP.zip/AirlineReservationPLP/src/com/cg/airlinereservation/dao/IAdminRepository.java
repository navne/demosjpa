/**
 ***********************************************************************************
 * File:        IAdminRepository.java
 * Package:    com.cg.airlinereservation.dao
 * Desc:        an interface to adminrepository
 * Version:     1.0
 * Modifications:
 * Author:            Date:          Change Description:
 * Group 1     		21-01-2017     		Initial Version
 ***********************************************************************************
 */
package com.cg.airlinereservation.dao;

import com.cg.airlinereservation.entities.BookingInfo;
import com.cg.airlinereservation.entities.FlightInfo;
import com.cg.airlinereservation.entities.UserARS;
import com.cg.airlinereservation.exception.ARSException;

import java.util.List;

public abstract interface IAdminRepository
{
	/**
	 * Method to fetch a particular flight information based on its flightNo
	 * @param flightNo
	 * @return FlightInfo
	 * @throws ARSException
	 */
	public abstract FlightInfo getFlightInfo(int flightNo)
			throws ARSException;

	/**
	 * Method to update information of a specific flight
	 * @param flightInfo
	 * @throws ARSException
	 */
	public abstract void updateFlightInfo(FlightInfo flightInfo)
			throws ARSException;


	/**
	 * Method to fetch an entire list of Bookings
	 * @param booking_Id
	 * @return List
	 * @throws ARSException
	 */
	public abstract List<BookingInfo> getBookingInfoListFlight(int booking_Id)
			throws ARSException;

	/**
	 * Method to enable admin  update the role of a user
	 * @param user
	 * @throws ARSException
	 */
	public abstract void updateUserRole(UserARS user)
			throws ARSException;

	/**
	 * Method to fetch information of a returning flight while a round trip booking has been made
	 * @param flightDate
	 * @return FlightInfo
	 * @throws ARSException
	 */
	public FlightInfo getFlightInfoReturn(String flightDate)
			throws ARSException;
}
