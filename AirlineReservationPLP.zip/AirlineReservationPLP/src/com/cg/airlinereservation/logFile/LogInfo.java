package com.cg.airlinereservation.logFile;

import java.net.URL;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.helpers.Loader;

/**
 ***********************************************************************************
 * File:        LogInfo.java
 * Package:     com.cg.airlinereservation.logFile
 * Desc:        Applying logger
 * Version:     1.0
 * Modifications:
 * Author:            Date:          Change Description:
 * Group 1     		21-01-2017     		Initial Version
 ***********************************************************************************
*/

public class LogInfo {

	public void configure(){ }

	public void configureLogging() throws Throwable {
		Logger myLog = Logger.getLogger(LogInfo.class);

		URL url=Loader.getResource("log4j.properties");
		PropertyConfigurator.configure(url.getFile());
}
}
