/**
 ***********************************************************************************
 * File:        UserARS.java
 * Package:     com.cg.airlinereservation.entities
 * Desc:        Server Unit to handle all request from users
 * Version:     1.0
 * Modifications:
 * Author:            Date:          Change Description:
 * Group 1     		21-01-2017     		Initial Version
 ***********************************************************************************
*/
package com.cg.airlinereservation.entities;
import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;


@Entity(name="UserARS")
@Table(name="userARS")
public class UserARS implements Serializable {
	
	/*userId NUMBER(4) PRIMARY KEY,
	uName VARCHAR2(20),
	pwd VARCHAR2(20),
	role VARCHAR2(10),
	mblNo NUMBER(10)*/
	
	
	private static final long serialVersionUID = 1L;
	
	private String uName;
	private String userName;
	private String uMail;
	private String pWd;
	private String role;
	private String mblNo;
	private String securityQuestion;
	private String securityAnswer;
	
	private Set<BookingInfo> bookingList;
	
	
	
	/**
	 * Generation of all getters and setters for respective fields 
	 * @return
	 */
	@OneToMany(mappedBy="user", fetch=FetchType.LAZY)
	public Set<BookingInfo> getBookingList() {
		return bookingList;
	}
	public void setBookingList(Set<BookingInfo> bookingList) {
		this.bookingList = bookingList;
	}
	
	@Id
	@NotEmpty(message="uMail empty!")
	@Column(name="uMail")
	public String getuMail() {
		return uMail;
	}
	public void setuMail(String uMail) {
		this.uMail = uMail;
	}
	@NotEmpty(message="securityQuestion empty!")
	@Column(name="securityQuestion")
	public String getSecurityQuestion() {
		return securityQuestion;
	}
	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}
	@NotEmpty(message="securityAnswer empty!")
	@Column(name="securityAnswer")
	public String getSecurityAnswer() {
		return securityAnswer;
	}
	public void setSecurityAnswer(String securityAnswer) {
		this.securityAnswer = securityAnswer;
	}
	@Column(name="uName")
	@NotEmpty(message="UName empty!")
	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	
	@Column(name="userName")
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}

	@NotEmpty(message="pWd empty!")
	@Column(name="pwd")
	public String getpWd() {
		return pWd;
	}
	public void setpWd(String pWd) {
		this.pWd = pWd;
	}
	@Column(name="role")
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@NotEmpty(message="mblNo empty!")
	@Column(name="mblNo")
	public String getMblNo() {
		return mblNo;
	}
	public void setMblNo(String mblNo) {
		this.mblNo = mblNo;
	}
	public UserARS() {
		super();
	}
	public UserARS(String userName, String pWd) {
		super();
		this.userName = userName;
		this.pWd = pWd;
	}
	/**
	 * Parameterized constructor
	 * @param uName
	 * @param userName
	 * @param uMail
	 * @param pWd
	 * @param role
	 * @param mblNo
	 * @param securityQuestion
	 * @param securityAnswer
	 */
	public UserARS(String uName, String userName, String uMail, String pWd,
			String role, String mblNo, String securityQuestion,
			String securityAnswer) {
		super();
		this.uName = uName;
		this.userName = userName;
		this.uMail = uMail;
		this.pWd = pWd;
		this.role = role;
		this.mblNo = mblNo;
		this.securityQuestion = securityQuestion;
		this.securityAnswer = securityAnswer;
	}
	
	
	/* (non-Javadoc)
	 * Generation of toString()
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "UserARS [uName=" + uName + ", userName=" + userName
				+ ", uMail=" + uMail + ", pWd=" + pWd + ", role=" + role
				+ ", mblNo=" + mblNo + ", securityQuestion=" + securityQuestion
				+ ", securityAnswer=" + securityAnswer + "]";
	}
	public UserARS(String userName) {
		super();
		this.userName = userName;
	}
	
	
	
	
	

	
	
	
}
