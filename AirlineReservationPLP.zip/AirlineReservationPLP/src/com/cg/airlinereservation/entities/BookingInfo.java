/**
 ***********************************************************************************
 * File:        BookingInfo.java
 * Package:     com.cg.airlinereservation.entities
 * Desc:        to get information about booking details
 * Version:     1.0
 * Modifications:
 * Author:            Date:          Change Description:
 * Group 1     		21-01-2017     		Initial Version
 ***********************************************************************************
*/
package com.cg.airlinereservation.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity(name="bookingInfo")
@Table(name="bookingInfo")
public class BookingInfo
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  
  
  private String booking_Id;
  private long no_of_passengers;
  private String class_Type;
  private double totalFare;
  private String creditCardInfo;
  private String srcCity;
  private String destCity;
  private int flightNo;
  private Date deptDate;
  
  /*@NotEmpty
  @Column(name="FlightDate")
  private String FlightDate;*/
  
  
  private FlightInfo flightInfo;
  
  private UserARS user;
 
 /*
  * generation of getters and setters for respective fields
  */ 

@OneToOne(fetch=FetchType.LAZY)
  @JoinColumn(name="uMail")	
public UserARS getUser() {
	return user;
}

public void setUser(UserARS user) {
	this.user = user;
}
  
  @OneToOne(fetch=FetchType.LAZY)
  @JoinColumn(name="flightDate")
  public FlightInfo getFlightInfo() {
	return flightInfo;
}

public void setFlightInfo(FlightInfo flightInfo) {
	this.flightInfo = flightInfo;
}

public BookingInfo() {}
  
	@Id
	@Column(name="Booking_id")
  public String getBooking_Id()
  {
    return booking_Id;
  }
  
  public void setBooking_Id(String booking_Id)
  {
    this.booking_Id = booking_Id;
  }
  @Column(name="no_of_passengers")
  public long getNo_of_passengers()
  {
    return no_of_passengers;
  }
  
  public void setNo_of_passengers(long no_of_passengers)
  {
    this.no_of_passengers = no_of_passengers;
  }

  @Column(name="class_type")
  public String getClass_Type()
  {
    return class_Type;
  }
  
  public void setClass_Type(String class_Type)
  {
    this.class_Type = class_Type;
  }

  @Column(name="total_fare")
  public double getTotalFare()
  {
    return totalFare;
  }
  
  public void setTotalFare(double totalFare)
  {
    this.totalFare = totalFare;
  }
  @Column(name="CreditCard_info")
  public String getCreditCardInfo()
  {
    return creditCardInfo;
  }
  
  public void setCreditCardInfo(String creditCardInfo)
  {
    this.creditCardInfo = creditCardInfo;
  }
  @Column(name="src_city")
  public String getSrcCity()
  {
    return srcCity;
  }
  
  public void setSrcCity(String srcCity)
  {
    this.srcCity = srcCity;
  }
  @Column(name="dest_city")
  public String getDestCity()
  {
    return destCity;
  }
  
  public void setDestCity(String destCity)
  {
    this.destCity = destCity;
  }
  @Column(name="flightNo")
  public int getFlightNo()
  {
    return flightNo;
  }
  
  public void setFlightNo(int flightNo)
  {
    this.flightNo = flightNo;
  }
  @Temporal(TemporalType.DATE)
  @DateTimeFormat(pattern="yyyy-MM-dd")
  @Column(name="deptDate")
  public Date getDeptDate()
  {
    return deptDate;
  }
  
  public void setDeptDate(Date deptDate)
  {
    this.deptDate = deptDate;
  }
  

/**
 * Parameterized constructor for BookingInfo
 * @param booking_Id
 * @param no_of_passengers
 * @param class_Type
 * @param totalFare
 * @param creditCardInfo
 * @param srcCity
 * @param destCity
 * @param flightNo
 * @param deptDate
 * @param flightInfo
 * @param user
 */
public BookingInfo(String booking_Id, long no_of_passengers, String class_Type,
		double totalFare, String creditCardInfo, String srcCity,
		String destCity, int flightNo, Date deptDate, FlightInfo flightInfo,
		UserARS user) {
	super();
	this.booking_Id = booking_Id;
	this.no_of_passengers = no_of_passengers;
	this.class_Type = class_Type;
	this.totalFare = totalFare;
	this.creditCardInfo = creditCardInfo;
	this.srcCity = srcCity;
	this.destCity = destCity;
	this.flightNo = flightNo;
	this.deptDate = deptDate;
	this.flightInfo = flightInfo;
	this.user = user;
}

/* (non-Javadoc)
 * generation of a toString()
 * @see java.lang.Object#toString()
 */
@Override
public String toString() {
	return "BookingInfo [booking_Id=" + booking_Id + ", no_of_passengers="
			+ no_of_passengers + ", class_Type=" + class_Type + ", totalFare="
			+ totalFare + ", creditCardInfo=" + creditCardInfo + ", srcCity="
			+ srcCity + ", destCity=" + destCity + ", flightNo=" + flightNo
			+ ", deptDate=" + deptDate + ", flightInfo=" + flightInfo
			+ ", userARS=" + user + "]";
}
  
  
}
