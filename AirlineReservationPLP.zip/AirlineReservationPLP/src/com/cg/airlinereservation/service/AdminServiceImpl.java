/**
 ***********************************************************************************
 * File:        AdminServiceImpl.java
 * Package:     com.cg.airlinereservation.service
 * Desc:        Server Unit to handle all request from users
 * Version:     1.0
 * Modifications:
 * Author:            Date:          Change Description:
 * Group 1     		21-01-2017     		Initial Version
 ***********************************************************************************
*/
package com.cg.airlinereservation.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.airlinereservation.dao.IAdminRepository;
import com.cg.airlinereservation.dao.IUserRepository;
import com.cg.airlinereservation.entities.BookingInfo;
import com.cg.airlinereservation.entities.FlightInfo;
import com.cg.airlinereservation.entities.UserARS;
import com.cg.airlinereservation.exception.ARSException;

@Service
@Transactional
public class AdminServiceImpl implements IAdminService {

	@Autowired
	IAdminRepository adminRepository;
	
	
	@Autowired
	IUserRepository userRepository;
	
	
	/* (non-Javadoc)
	 * to get the flight information using flight
	 * @see com.cg.airlinereservation.service.IAdminService#getFlightInfo(int)
	 */
	@Override
	public FlightInfo getFlightInfo(int flightno) throws ARSException {
		return adminRepository.getFlightInfo(flightno);
	}

	/* (non-Javadoc)
	 * to update flight related information
	 * @see com.cg.airlinereservation.service.IAdminService#updateFlightInfo(com.cg.airlinereservation.entities.FlightInfo)
	 */
	@Override
	public void updateFlightInfo(FlightInfo flightInfo) throws ARSException {
		adminRepository.updateFlightInfo(flightInfo);

	}

	

	/* (non-Javadoc)
	 * to get the booking list
	 * @see com.cg.airlinereservation.service.IAdminService#getBookingInfoListFlight(int)
	 */
	@Override
	public List<BookingInfo> getBookingInfoListFlight(int flightNo)
			throws ARSException {
		
		return adminRepository.getBookingInfoListFlight(flightNo);
	}

	/* (non-Javadoc)
	 * to update the role of user
	 * @see com.cg.airlinereservation.service.IAdminService#updateUserRole(com.cg.airlinereservation.entities.UserARS)
	 */
	@Override
	public void updateUserRole(UserARS user)
			throws ARSException {
		
		
		adminRepository.updateUserRole(user);
	}

	/* (non-Javadoc)
	 * to get details about flight on the basis of flight date(primary key)
	 * @see com.cg.airlinereservation.service.IAdminService#getFlightInfoReturn(java.lang.String)
	 
	 */
	@Override
	public FlightInfo getFlightInfoReturn(String flightDate)
			throws ARSException {
		
		return adminRepository.getFlightInfoReturn(flightDate);
	}

	

}
