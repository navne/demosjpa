/**
 ***********************************************************************************
 * File:        UserServiceImpl.java
 * Package:     com.cg.airlinereservation.service
 * Desc:        implementaion of nterface user service
 * Version:     1.0
 * Modifications:
 * Author:            Date:          Change Description:
 * Group 1     		21-01-2017     		Initial Version
 ***********************************************************************************
*/
package com.cg.airlinereservation.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.airlinereservation.dao.IUserRepository;
import com.cg.airlinereservation.entities.UserARS;
import com.cg.airlinereservation.exception.ARSException;

@Service
@Transactional
public class UserServiceImpl implements IUserService {

	@Autowired
	private IUserRepository userRepository;
	
	
	/* (non-Javadoc)
	 * to get user details from database
	 * @see com.cg.airlinereservation.service.IUserService#getUser(com.cg.airlinereservation.entities.UserARS)
	 */
	@Override
	public UserARS getUser(UserARS userARS) throws ARSException {
		return userRepository.getUser(userARS);
	}

	/* (non-Javadoc)
	 * to add user in database
	 * @see com.cg.airlinereservation.service.IUserService#addUser(com.cg.airlinereservation.entities.UserARS)
	 */
	@Override
	public void addUser(UserARS userARS) throws ARSException {
		userRepository.addUser(userARS);
		
	}

	/* (non-Javadoc)
	 * to remove user from database
	 * @see com.cg.airlinereservation.service.IUserService#removeUser(com.cg.airlinereservation.entities.UserARS)
	 */
	@Override
	public void removeUser(UserARS userARS) throws ARSException {
		userRepository.removeUser(userARS);
		
	}

	/* (non-Javadoc)
	 * to update user in database
	 * @see com.cg.airlinereservation.service.IUserService#removeUser(com.cg.airlinereservation.entities.UserARS)
	 */
	@Override
	public void updateUser(UserARS userARS) throws ARSException {
		userRepository.updateUser(userARS);
		
	}

	/* (non-Javadoc)
	 * to get user details from database
	 * @see com.cg.airlinereservation.service.IUserService#removeUser(com.cg.airlinereservation.entities.UserARS)
	 */
	@Override
	public UserARS getUserDetails(UserARS user)
			throws ARSException {
		
		return userRepository.getUserDetails(user);
	}

	/* (non-Javadoc)
	 * to update password of user
	 * @see com.cg.airlinereservation.service.IUserService#removeUser(com.cg.airlinereservation.entities.UserARS)
	 */
	@Override
	public void updatePassword(UserARS paramUserARS) throws ARSException {
		userRepository.updatePassword(paramUserARS);
		
	}

}
