/**
 ***********************************************************************************
 * File:        ICustomerService.java
 * Package:     com.cg.airlinereservation.service
 * Desc:        an interface for customer service
 * Version:     1.0
 * Modifications:
 * Author:            Date:          Change Description:
 * Group 1     		21-01-2017     		Initial Version
 ***********************************************************************************
*/
package com.cg.airlinereservation.service;

import java.util.List;

import com.cg.airlinereservation.entities.BookingInfo;
import com.cg.airlinereservation.entities.FlightInfo;
import com.cg.airlinereservation.entities.UserARS;
import com.cg.airlinereservation.exception.ARSException;

public interface ICustomerService 
{
	/**
	 * to fetch booking info
	 * @param bookingId
	 * @return BookingInfo
	 * @throws ARSException
	 */
	public BookingInfo getBookingInfo(String bookingId)throws ARSException ;
	
	/**
	 * to fetch the list of all flights
	 * @param flightInfo
	 * @return List
	 * @throws ARSException
	 */
	public List<FlightInfo> getAllFlights(FlightInfo flightInfo) throws ARSException;
	
	/**
	 * to add a new booking
	 * @param bookingInfo
	 * @throws ARSException
	 */
	public void addBookingInfo(BookingInfo bookingInfo) throws ARSException;
	/*public void updateBooking(BookingInfo bookingInfo) throws ARSException;*/
	
	/**
	 * to delete a booking
	 * @param bookingInfo
	 * @throws ARSException
	 */
	public void deleteBooking(BookingInfo bookingInfo) throws ARSException;

	/**
	 * to generate and fetch an auto-generated bookingID
	 * @return int
	 * @throws ARSException
	 */
	public int bookingId() throws ARSException;

	 /**
	  * to fetch all bookings
	 * @param uMail
	 * @return List
	 * @throws ARSException
	 */
	List<BookingInfo> getAllBookings(String uMail)throws ARSException;
	
	/**
	 * to fetch a list of all customers
	 * @return List
	 * @throws ARSException
	 */
	public List<UserARS> getAllCustomers()
			throws ARSException;
	
	/**
	 * to fetch the details of a customer
	 * @param customer
	 * @return UserARS
	 * @throws ARSException
	 */
	public UserARS getCustomerDetails(UserARS customer) throws ARSException;
}
