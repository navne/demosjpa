package core.cg.ois.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import core.cg.ois.beans.AccountMaster;
import core.cg.ois.beans.Customer;
import core.cg.ois.beans.PayeeTable;
import core.cg.ois.beans.ServiceTracker;
import core.cg.ois.beans.Transaction;
import core.cg.ois.beans.UserTable;
import core.cg.ois.exception.BankingException;
import core.cg.ois.service.IObsService;
import core.cg.ois.service.ObsServiceImpl;

public class ControllerActionClass {
	private IObsService service =null;
	private String id = null;
	private int userId = 0;
	private UserTable user = null;
	private int accountId = 0;
	private Object obj = null;
	private AccountMaster master = null;

	



	public ControllerActionClass() {
		user = new UserTable();
		service = new ObsServiceImpl();
		master = new AccountMaster();
	}




	public String processLogin(HttpSession session , HttpServletRequest request)
	{
		id = request.getParameter("userId");
		String password = request.getParameter("pass");
		if(id != null && password != null)
		{

			userId = Integer.parseInt(id);
			System.out.println(userId);
			user.setUserId(userId);
			user.setPassword(password);	


			try
			{
				accountId = service.loginProcess(user);
				session.setAttribute("accountId", accountId);
				session.setAttribute("userId", userId);
				session.setAttribute("pass", password);
				return "home.do";
			} 
			catch (BankingException e) 
			{	

				e.printStackTrace();
				session.setAttribute("msg", "Invalid UserId  Password");
				return "clientlogin.jsp";
			}
		}
		else
		{
			session = request.getSession(false);
			session.setAttribute("msg", "login first");

			return "clientlogin.jsp";
		}

	}

	public String processHome(HttpSession session , HttpServletRequest request)
	{
		
		if(session != null )
		{
			obj = session.getAttribute("accountId");
			if( obj != null)
			try
			{
				accountId = (int)obj;
				master = service.getAccount(accountId);
				Customer cust = service.getCustomerName(accountId);
				session.setAttribute("cust", cust);
				session.setAttribute("master", master);
				session.setAttribute("accountId", accountId);
				return  "Home.jsp";
			} 
			catch (BankingException e) 
			{	
				e.printStackTrace();
				session.setAttribute("msg", e);
				return "clientlogin.jsp";
			}
			else
			{
				return "clientlogi.jsp";
			}
		}
		else
		{
			session = request.getSession(true);
			session.setAttribute("msg", "Please login first");
			return "clientlogin.jsp";
		}



	}


	public String processMiniStatement(HttpSession session , HttpServletRequest request)
	{
		
		if(session != null && obj != null)
		{
			obj = session.getAttribute("master");
			
			
			AccountMaster master = (AccountMaster) obj;
			int AccountId = master.getAccountId();
			try
			{
				List<Transaction> mList = service.getAllTransaction(AccountId);
				System.out.println(mList);
				session.setAttribute("mList", mList);
				return "mini.jsp";
			}
			catch (BankingException e) {
				session.setAttribute("errormini", "No tansactions");
				e.printStackTrace();
				return "mini.jsp";
			}
			
		}

		else
		{
			session = request.getSession(true);
			session.setAttribute("msg", "Please Login First");
			return "clientlogin.jsp";
		}
	}
	
	
	
	public String processForget(HttpServletRequest request , HttpSession session)
	{
		id = request.getParameter("userId");

		if(session != null && id != null)
		{
			userId = Integer.parseInt(id);
			
			session.setAttribute("userId", userId);
			try
			{
				String getQues = service.securityQues(userId);
				System.out.println(getQues);
				session.setAttribute("ques", getQues);
				return "ans.jsp";
			}
			catch (BankingException e) 
			{
				session.setAttribute("msg" , "userId Does Not exists" );
				
				return "securityQues.jsp";
			}
		}
		else
		{
			session = request.getSession(true);
			session.setAttribute("msg", "Please Enter user Id");
			return "securityQues.jsp";
		}
	
	}
	
	public String processQues(HttpServletRequest request , HttpSession session)
	{
		obj =  session.getAttribute("ques");
		if(session != null && obj != null)
		{
			String ques = (String) obj;
			System.out.println(ques);
			String transPass = request.getParameter("ans");

			try
			{
				int Id = service.confirmQues(ques, transPass);
				return "otp.jsp";
			} 
			catch (BankingException e)
			{
		    	session.setAttribute("error", "Inavlid Answer");
				e.printStackTrace();
				return "ans.jsp";
			}
		}
		else
		{
			session = request.getSession(true);
			session.setAttribute("msg", "login first");
			return "clientogin.jsp";
		}
	}
	
	
	public String changePassword(HttpServletRequest request , HttpSession session)
	{
		obj =  session.getAttribute("userId");
		String pas = request.getParameter("pass");
		System.out.println("int"+ obj);
		if(obj != null && pas != null)
		{


			userId = (int)obj;

			System.out.println(userId);

			try 
			{
				System.out.println(pas);
				service.passwordChange(userId, pas);
				return "clientlogin.jsp";

			} 
			catch (BankingException e)
			{

				session.setAttribute("msg", "Unbale to ChangePassword");
				e.printStackTrace();
				return "cientlogin.jsp";
			}
		}
		else
		{
			session = request.getSession(false);
			session.setAttribute("msg", "login first");
			
			return "clientlogin.jsp";
		}
	}
	
	public String updateCommunication(HttpSession session , HttpServletRequest request)
	{
	
		
		if(session != null )
		{
			obj = session.getAttribute("accountId");
			

			accountId = (int)obj;
//			System.out.println("in update" +accId);
			try
			{
				Customer cust = service.getPersonalDetails(accountId);
				session.setAttribute("cust", cust);
				return  "updateCustomer.jsp";

			}
			catch (BankingException e) {
				session.setAttribute("errorupdate", "Unbale to retrieve Details");
				return "updateCustomer.jsp";
			}
		}
		else
		{
			session = request.getSession();
			session.setAttribute("msg", "login first");
			return "clientlogin.jsp";
		}

	}
	
	public String updateAction(HttpServletRequest request , HttpSession session)
	{
		
		if( session != null )
		{


			String accId = request.getParameter("accId");
			accountId = Integer.parseInt(accId);
			String cName = request.getParameter("cName");
			String cEmail = request.getParameter("cEmail");
			String cAddress = request.getParameter("cAddress");
			String cPanCard = request.getParameter("cPanCard");

			Customer cust = new Customer(accountId, cName, cEmail, cAddress, cPanCard);

			try
			{
				service.updateCustomer(cust);
				session.setAttribute("cust", cust);
				return "updateSucess.jsp";
				

			}
			catch (BankingException e) 
			{
				session.setAttribute("msg", "something went Wrong");
				return "clientlogin.jsp";
			}
		}
		else
		{
			session = request.getSession(true);
			session.setAttribute("msg", "login first");
			
			return "clientlogin.jsp";
	}
	}
	
	
	public String requestService(HttpServletRequest request , HttpSession session)
	{
		
		if(session != null)
		{
			obj =  session.getAttribute("accountId");
			accountId = (int)obj;
			String desc = request.getParameter("desc");
			System.out.println(desc);

			try 
			{
				int serviceId =service.requestCheckBook(accountId, desc);
				System.out.println(serviceId);
				session.setAttribute("serviceId", serviceId);
				request.setAttribute("id" , accountId);
				return "requestsuccess.jsp";
			}
			catch (BankingException e) {
				session.setAttribute("msg", "Please Report this issue to Bank");
				return "clientlogin.jsp";
			}
		}
		else
		{
			session = request.getSession(true);
			session.setAttribute("msg", "login first");
			
			return "clientlogin.jsp";
		}



	}
	
	public String trackService(HttpServletRequest request, HttpSession session){
		
		if(session != null)
		{
			obj = session.getAttribute("accountId");

			accountId = (int)obj;
			try
			{
				List<ServiceTracker> mService =  new ArrayList<ServiceTracker>();
				mService =	service.trackRequest(accountId);
				session.setAttribute("mService", mService);
				return "trackService.jsp";
			} 
			catch (BankingException e) {
				session.setAttribute("msg", "Try Again");
				return "clientlogin.jsp";
			}
		}
		else
		{
			session = request.getSession(true);
			session.setAttribute("msg", "login first");
			return "clientlogin.jsp";
		}
	}
	
	
	public String processFundTransfer(HttpServletRequest request , HttpSession session)
	{
		if(session != null )
		{

			obj  = session.getAttribute("accountId");
			accountId = (int)obj;

			List<PayeeTable> list = new ArrayList<PayeeTable>();
			try
			{
				list = service.getPayeeList(accountId);
				System.out.println(list);
				session.setAttribute("accountId", accountId);
				session.setAttribute("payeeList", list);

				return  "ownTransfer.jsp";
			} 
			catch (BankingException e) {
				session.setAttribute("msg", "login first");
				return "clientlogin.jsp";
			}
		}
		else
		{
			session = request.getSession(true);
			session.setAttribute("msg", "login first");
			return "clientlogin.jsp";
		}


	}
	
	public String transaction(HttpServletRequest request , HttpSession session)
	{
		String payer =request.getParameter("payer");
		String payee =request.getParameter("payee")	;
		String amt = request.getParameter("amount");

		if(session != null &&payer != null && payee != null & amt != null)
		{


			int accountPayer=Integer.parseInt(payer);
			int accountPayee=Integer.parseInt(payee);
			double amount = Double.parseDouble(amt);


			try {
				int transId =service.ownFundTransfer(accountPayer, accountPayee, amount);
				session.setAttribute("transId", transId);
				return "success.jsp";

			} catch (BankingException e1) {
				
				session.setAttribute("msg", "Insufficient Balance");
				return "ownTransfer.jsp";

			}
		}
		else
		{
			session = request.getSession(true);
			session.setAttribute("msg", "login first");
			return "clientlogin.jsp";
		}
	}
	
	
	public String processaddPayee(HttpServletRequest request , HttpSession session)
	{
		
			String accId = request.getParameter("accountId");
            String payeeAccountId = request.getParameter("payeeAccountId");
            String nickname=request.getParameter("nickname");
            if(session !=  null && accId != null && payeeAccountId != null && nickname != null)
    		{
			int accId2=Integer.parseInt(accId);
			int payeeaccId=Integer.parseInt(payeeAccountId);
			

			PayeeTable payee1=new PayeeTable(accId2,payeeaccId,nickname);

			session.setAttribute("Payee",payee1);
			try 
			{
				service.checkPayeeId(payeeaccId);
				return "Urn.jsp";
			}
			catch (BankingException e) {
				session.setAttribute("msg","Account Id doesnot exists");
				return "enterPayeeDetails.jsp";
			}
		}
		else
		{
			session = request.getSession(true);
			session.setAttribute("msg", "login first");
			return "clientlogin.jsp";
		}
		
	}
	
	public String confirmaddPayee(HttpServletRequest request , HttpSession session)
	{
		obj = session.getAttribute("Payee");
		if( session != null && obj != null)
		{
			PayeeTable payee1 = (PayeeTable) obj;


			System.out.println(payee1);
			String urn = request.getParameter("urn");
			if(urn.equals("abc"))
			{
				try 
				{
					service.addPayee(payee1);
					return "payeeSuccess.jsp";
				}
				catch (BankingException e) {
					return "payeeSuccess.jsp";
				}
			}
			else
			{
				session.setAttribute("msg", "Wrong otp");
				return "Urn.jsp";
			}
		}
		else
		{
			session = request.getSession(true);
			session.setAttribute("msg", "login first");
			return "payeeSuccess.jsp";
		}
		
	}



}
