package core.cg.ois.dao;

import java.util.List;

import core.cg.ois.beans.AccountMaster;
import core.cg.ois.beans.Customer;
import core.cg.ois.beans.ServiceTracker;
import core.cg.ois.beans.Transaction;
import core.cg.ois.exception.BankingException;

public interface BankDao 
{
	public void insertAccountHolder(Customer customer) throws BankingException;
	public void insertAccount(AccountMaster account) throws BankingException;
	public int createAccountNo() throws BankingException;
	public List<ServiceTracker> showall() throws BankingException;
	void updateTracker(int accountId, int serviceId, String status) throws BankingException;
	public ServiceTracker searchserviceid(int serviceId) throws BankingException;
	public List<Transaction> getAllTransactions() throws BankingException;
}
