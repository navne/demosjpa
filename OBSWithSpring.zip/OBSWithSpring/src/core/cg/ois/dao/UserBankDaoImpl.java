package core.cg.ois.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import core.cg.ois.beans.AccountMaster;
import core.cg.ois.beans.Customer;
import core.cg.ois.beans.PayeeTable;
import core.cg.ois.beans.ServiceTracker;
import core.cg.ois.beans.Transaction;
import core.cg.ois.beans.UserTable;
import core.cg.ois.exception.BankingException;


@Repository("bankDao")
public class UserBankDaoImpl implements IObsDao {
	
	@PersistenceContext
	EntityManager EntityManager;

	@Override
	public int loginProcess(UserTable user) throws BankingException {
		int accountId = 0;
		int userid = user.getUserId();
		try
		{
			Query query = EntityManager.createQuery("select accountId , lockStatus from UserTable where userid = :user_id ");
			query.setParameter("user_id", userid);
			user = (UserTable) query.getSingleResult();
			accountId = user.getAccountId();
			
		}		
		catch (Exception e)
		{
			e.printStackTrace();
			throw new BankingException("Something Went Wrong in Dao" +e);
		}
		if(accountId ==  0)
		{
			throw new BankingException();
		}
		
		
		return accountId;
	}

	@Override
	public void update(int lock) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public AccountMaster getAccount(int accountId) throws BankingException {
		AccountMaster account = null;
		try 
		{
			Query query = EntityManager.createQuery("From AccountMaster where accountId = :account_id ");
			query.setParameter("account_id", accountId);
			account = (AccountMaster) query.getSingleResult();
		} 
		catch (Exception e) {
			throw new BankingException("problem in getAccount" +e);
		}
		
		return account;
	}

	@Override
	public String securityQues(int userId) throws BankingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int confirmQues(String ques, String transPass)
			throws BankingException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void passwordChange(int userId, String pas) throws BankingException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Transaction> getAllTransaction(int accId)
			throws BankingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer getPersonalDetails(int accId) throws BankingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateCustomer(Customer cust) throws BankingException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int requestCheckBook(int accId, String desc) throws BankingException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<ServiceTracker> trackRequest(int accId) throws BankingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer getCustomerName(int accounId) throws BankingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PayeeTable> getPayeeList(int accId) throws BankingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addPayee(PayeeTable payee) throws BankingException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<AccountMaster> checkPayeeId(int payeeId)
			throws BankingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int ownFundTransfer(int accountPayer, int accountPayee, double amount)
			throws BankingException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean register(UserTable user) throws BankingException {
		// TODO Auto-generated method stub
		return false;
	}

	
}
