package core.cg.ois.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "fundtransfer")
public class FundTransfer 
{
	@Id
	@Column(name = "fundtransferid")	
	private int fundTransferId;
	
	@Column(name = "account_id")
	private int accountId;
	
	@Column(name = "payee_account_id")
	private int payeeAccountId;
	
	@Column(name = "date_of_transfer")
	private Date dateOfTransaction;
	
	@Column(name = "transfer_amount")
	private Double transferAmount;
	public FundTransfer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public FundTransfer(int fundTransferId, int accountId, int payeeAccountId,
			Date dateOfTransaction, Double transferAmount) {
		super();
		this.fundTransferId = fundTransferId;
		this.accountId = accountId;
		this.payeeAccountId = payeeAccountId;
		this.dateOfTransaction = dateOfTransaction;
		this.transferAmount = transferAmount;
	}
	@Override
	public String toString() {
		return "FundTransfer [fundTransferId=" + fundTransferId
				+ ", accountId=" + accountId + ", payeeAccountId="
				+ payeeAccountId + ", dateOfTransaction=" + dateOfTransaction
				+ ", transferAmount=" + transferAmount + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accountId;
		result = prime
				* result
				+ ((dateOfTransaction == null) ? 0 : dateOfTransaction
						.hashCode());
		result = prime * result + fundTransferId;
		result = prime * result + payeeAccountId;
		result = prime * result
				+ ((transferAmount == null) ? 0 : transferAmount.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FundTransfer other = (FundTransfer) obj;
		if (accountId != other.accountId)
			return false;
		if (dateOfTransaction == null) {
			if (other.dateOfTransaction != null)
				return false;
		} else if (!dateOfTransaction.equals(other.dateOfTransaction))
			return false;
		if (fundTransferId != other.fundTransferId)
			return false;
		if (payeeAccountId != other.payeeAccountId)
			return false;
		if (transferAmount == null) {
			if (other.transferAmount != null)
				return false;
		} else if (!transferAmount.equals(other.transferAmount))
			return false;
		return true;
	}
	public int getFundTransferId() {
		return fundTransferId;
	}
	public void setFundTransferId(int fundTransferId) {
		this.fundTransferId = fundTransferId;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public int getPayeeAccountId() {
		return payeeAccountId;
	}
	public void setPayeeAccountId(int payeeAccountId) {
		this.payeeAccountId = payeeAccountId;
	}
	public Date getDateOfTransaction() {
		return dateOfTransaction;
	}
	public void setDateOfTransaction(Date dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}
	public Double getTransferAmount() {
		return transferAmount;
	}
	public void setTransferAmount(Double transferAmount) {
		this.transferAmount = transferAmount;
	}
	
	
}
