package core.cg.ois.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "user_table")
public class UserTable
{
	@Id
	@Column(name = "account_id")
	private int accountId;
	@Column(name  = "user_id")
	private int userId;
	@Column(name = "login_password")
	private String password;
	@Column(name = "secret_question")
	private String secretQuestion;
	@Column(name = "transaction_password")
	private String transactionPassword;
	@Column(name = "lock_status")
	private String lockStatus;
	public UserTable() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UserTable(int accountId, int userId, String password,
			String secretQuestion, String transactionPassword, String lockStatus) {
		super();
		this.accountId = accountId;
		this.userId = userId;
		this.password = password;
		this.secretQuestion = secretQuestion;
		this.transactionPassword = transactionPassword;
		this.lockStatus = lockStatus;
	}
	@Override
	public String toString() {
		return "UserTable [accountId=" + accountId + ", userId=" + userId
				+ ", password=" + password + ", secretQuestion="
				+ secretQuestion + ", transactionPassword="
				+ transactionPassword + ", lockStatus=" + lockStatus + "]";
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSecretQuestion() {
		return secretQuestion;
	}
	public void setSecretQuestion(String secretQuestion) {
		this.secretQuestion = secretQuestion;
	}
	public String getTransactionPassword() {
		return transactionPassword;
	}
	public void setTransactionPassword(String transactionPassword) {
		this.transactionPassword = transactionPassword;
	}
	public String getLockStatus() {
		return lockStatus;
	}
	public void setLockStatus(String string) {
		this.lockStatus = string;
	}




}
