package core.cg.ois.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name  = "transaction")
public class Transaction 
{
	@Id
	@Column(name = "transaction_id")
	private int transactionId;
	@Column(name = "tran_description")
	private String transactionDesc;
	@Column(name = "dateoftransaction")
	private Date dateOfTransaction;
	@Column(name = "transactiontype")
	private String transactionType;
	@Column(name = "tranamount")
	private Double tranAmount;
	@Column(name = "account_no")
	private int accountNo;
	
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Transaction(int transactionId, String transactionDesc,
			Date dateOfTransaction, String transactionType, Double tranAmount,
			int accountNo) {
		super();
		this.transactionId = transactionId;
		this.transactionDesc = transactionDesc;
		this.dateOfTransaction = dateOfTransaction;
		this.transactionType = transactionType;
		this.tranAmount = tranAmount;
		this.accountNo = accountNo;
	}
	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId
				+ ", transactionDesc=" + transactionDesc
				+ ", dateOfTransaction=" + dateOfTransaction
				+ ", transactionType=" + transactionType + ", tranAmount="
				+ tranAmount + ", accountNo=" + accountNo + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accountNo;
		result = prime
				* result
				+ ((dateOfTransaction == null) ? 0 : dateOfTransaction
						.hashCode());
		result = prime * result
				+ ((tranAmount == null) ? 0 : tranAmount.hashCode());
		result = prime * result
				+ ((transactionDesc == null) ? 0 : transactionDesc.hashCode());
		result = prime * result + transactionId;
		result = prime * result
				+ ((transactionType == null) ? 0 : transactionType.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Transaction other = (Transaction) obj;
		if (accountNo != other.accountNo)
			return false;
		if (dateOfTransaction == null) {
			if (other.dateOfTransaction != null)
				return false;
		} else if (!dateOfTransaction.equals(other.dateOfTransaction))
			return false;
		if (tranAmount == null) {
			if (other.tranAmount != null)
				return false;
		} else if (!tranAmount.equals(other.tranAmount))
			return false;
		if (transactionDesc == null) {
			if (other.transactionDesc != null)
				return false;
		} else if (!transactionDesc.equals(other.transactionDesc))
			return false;
		if (transactionId != other.transactionId)
			return false;
		if (transactionType == null) {
			if (other.transactionType != null)
				return false;
		} else if (!transactionType.equals(other.transactionType))
			return false;
		return true;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionDesc() {
		return transactionDesc;
	}
	public void setTransactionDesc(String transactionDesc) {
		this.transactionDesc = transactionDesc;
	}
	public Date getDateOfTransaction() {
		return dateOfTransaction;
	}
	public void setDateOfTransaction(Date dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public Double getTranAmount() {
		return tranAmount;
	}
	public void setTranAmount(Double tranAmount) {
		this.tranAmount = tranAmount;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	
	
}
