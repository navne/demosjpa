package com.capgemini.entity;

public class UserTable
{
	private int accountId;
	private int userId;
	private String password;
	private String secretQuestion;
	private String transactionPassword;
	private String lockStatus;
	public UserTable() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UserTable(int accountId, int userId, String password,
			String secretQuestion, String transactionPassword, String lockStatus) {
		super();
		this.accountId = accountId;
		this.userId = userId;
		this.password = password;
		this.secretQuestion = secretQuestion;
		this.transactionPassword = transactionPassword;
		this.lockStatus = lockStatus;
	}
	@Override
	public String toString() {
		return "UserTable [accountId=" + accountId + ", userId=" + userId
				+ ", password=" + password + ", secretQuestion="
				+ secretQuestion + ", transactionPassword="
				+ transactionPassword + ", lockStatus=" + lockStatus + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accountId;
		result = prime * result
				+ ((lockStatus == null) ? 0 : lockStatus.hashCode());
		result = prime * result
				+ ((password == null) ? 0 : password.hashCode());
		result = prime * result
				+ ((secretQuestion == null) ? 0 : secretQuestion.hashCode());
		result = prime
				* result
				+ ((transactionPassword == null) ? 0 : transactionPassword
						.hashCode());
		result = prime * result + userId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserTable other = (UserTable) obj;
		if (accountId != other.accountId)
			return false;
		if (lockStatus == null) {
			if (other.lockStatus != null)
				return false;
		} else if (!lockStatus.equals(other.lockStatus))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (secretQuestion == null) {
			if (other.secretQuestion != null)
				return false;
		} else if (!secretQuestion.equals(other.secretQuestion))
			return false;
		if (transactionPassword == null) {
			if (other.transactionPassword != null)
				return false;
		} else if (!transactionPassword.equals(other.transactionPassword))
			return false;
		if (userId != other.userId)
			return false;
		return true;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSecretQuestion() {
		return secretQuestion;
	}
	public void setSecretQuestion(String secretQuestion) {
		this.secretQuestion = secretQuestion;
	}
	public String getTransactionPassword() {
		return transactionPassword;
	}
	public void setTransactionPassword(String transactionPassword) {
		this.transactionPassword = transactionPassword;
	}
	public String getLockStatus() {
		return lockStatus;
	}
	public void setLockStatus(String lockStatus) {
		this.lockStatus = lockStatus;
	}
	
	

}
