package com.capgemini.dao;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import com.capgemini.entity.AccountMaster;
import com.capgemini.entity.Customer;
import com.capgemini.entity.PayeeTable;
import com.capgemini.entity.ServiceTracker;
import com.capgemini.entity.Transaction;
import com.capgemini.entity.UserTable;
import com.capgemini.exception.BankingException;
import com.capgemini.utility.DBUtil;

public class UserBankDao implements IUserBankDao
{
	private DataSource dataSource;
	private Connection connection;
	
	
	/*
	 * 
	 * USER LOGIN
	 * 
	 * */
	@Override
	public int login(int userId, String password) throws BankingException  {
		int a=0;
		try {
			/*dataSource=DBUtil.getDataSource();
			Connection connection=dataSource.getConnection();*/
			//dataSource=DBUtil.getDataSource();
			connection=DBUtil.getConnection();		
			//System.out.println(userId +"     " +password);
			PreparedStatement ps=connection.prepareStatement("Select * from user_Table where user_Id=? and Login_password=?");
			ps.setInt(1, userId);
			ps.setString(2, password);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				
				a=rs.getInt("Account_Id");
				System.out.println(a+"In Login");
				connection.close();
				
			}
			return a;
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new BankingException("technical problem contact branch");
		}
		
		
	}

	
	
	
	/*
	 * REGISTER EMPLOYEE
	 * 
	 * */
	@Override
	public boolean register(UserTable user) throws BankingException {
		Connection connection;
		
			int m;
			try {
				/*dataSource=DBUtil.getDataSource();
				connection = dataSource.getConnection();*/
				//dataSource=DBUtil.getDataSource();
				connection=DBUtil.getConnection();		
				PreparedStatement ps1=connection.prepareStatement("select * from AccountMaster where Account_Id=?");
				ps1.setInt(1, user.getAccountId());
				ResultSet rs=ps1.executeQuery();
				if(rs==null)
					throw new BankingException("You are not authorize to register... Contact Bank");
				PreparedStatement ps=connection.prepareStatement("Insert into User_Table values(?,?,?,?,?,?)");
				ps.setInt(1, user.getAccountId());
				ps.setInt(2, user.getUserId());
				ps.setString(3, user.getPassword());
				ps.setString(4, user.getSecretQuestion());
				ps.setString(5, user.getTransactionPassword());
				ps.setString(6, user.getLockStatus());
				m = ps.executeUpdate();
				connection.close();
			} catch (SQLException e) {
				throw new BankingException("Unable to process request...Please contact bank.");
			}
			if(m==1)
				return true;
				
		
		return false;
	}


	/*
	 * MINI STATEMENT
	 * 
	 * */

	@Override
	public List<Transaction> getDetailsMini(int accountNo) {
		Connection connection;
		
		ArrayList<Transaction> transaction=null;
		ResultSet rs=null;
		PreparedStatement ps=null;		
		try
		{
			/*dataSource=DBUtil.getDataSource();
			connection = dataSource.getConnection();*/
			//dataSource=DBUtil.getDataSource();
			connection=DBUtil.getConnection();		
		
		
		ps=connection.prepareStatement("select * from transaction where rowNum <=10 and Account_no=?  order by dateoftransaction desc");
		ps.setInt(1, accountNo);
		rs=ps.executeQuery();
		transaction=new ArrayList<>();
		while(rs.next())
		{
			Transaction tran=new Transaction();
			tran.setTransactionId(rs.getInt("Transaction_ID")); 
			tran.setTransactionDesc(rs.getString("Tran_Description"));
			tran.setDateOfTransaction(rs.getDate("DateOfTransaction"));
			tran.setTransactionType(rs.getString("TransactionType"));
			tran.setTranAmount(rs.getDouble("TranAmount"));
			tran.setAccountNo(rs.getInt("Account_No"));
			transaction.add(tran);
			
			
		}
		connection.close();
		}
		catch(SQLException e)	//logger
		{
			e.printStackTrace();
		}
		catch(Exception e)					//Generic catch block
		{
			e.printStackTrace();
		}
		
		return transaction;
	}


	/*
	 * TO CREATE SESSION
	 * 
	 * */

	@Override
	public AccountMaster getAccount(int res) throws BankingException
	{
		System.out.println(res+" in get account");
		Connection connection;
		AccountMaster master= new AccountMaster();
		ResultSet rs=null;
		try {
			/*dataSource=DBUtil.getDataSource();
			connection = dataSource.getConnection();*/
			//dataSource=DBUtil.getDataSource();
			connection=DBUtil.getConnection();		
			PreparedStatement ps=connection.prepareStatement("select * from AccountMaster where Account_Id=?");
			ps.setInt(1, res);
			rs=ps.executeQuery();
			System.out.println(rs+"  Result set");
			if(rs.next())
			{
				master.setAccountId(rs.getInt("Account_Id"));
				master.setAccountType(rs.getString("Account_Type"));
				master.setAccountBalance(rs.getDouble("Account_Balance"));
				master.setOpenDate(rs.getDate("open_date"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new BankingException("Unable to follow your request.. pls contact bank");
		}
		System.out.println(master+"****************");
		return master; 
	}




	@Override
	public String getAddress(int accountNo) throws BankingException {
		String address=null;
		Connection connection;
		try {
			/*dataSource=DBUtil.getDataSource();
			connection = dataSource.getConnection();*/
			//dataSource=DBUtil.getDataSource();
			connection=DBUtil.getConnection();	
			PreparedStatement ps=connection.prepareStatement("Select Address from customer where Account_Id=?");
			ps.setInt(1, accountNo);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
				address=rs.getString("Address");
			
			connection.close();
		} catch (SQLException e) {
			throw new BankingException("Unable to process your request");
		}
		return address;
	}




	@Override
	public int updateAddress(String add,int accountNo) throws BankingException {
		Connection connection;
		int row;
		try {
			/*dataSource=DBUtil.getDataSource();
			connection = dataSource.getConnection();*/
			//dataSource=DBUtil.getDataSource();
			connection=DBUtil.getConnection();	
			PreparedStatement ps=connection.prepareStatement("update customer set address=? where Account_Id=?");
			ps.setString(1, add);
			ps.setInt(2, accountNo);
			row = ps.executeUpdate();
		} catch (SQLException e) {
			throw new BankingException("Unable to update");
		}
		return row;
				
	}

	@Override
	public int reqCheckBook(int account1) throws BankingException
	{
		int serviceId=generateService();
		
		
			Connection connection;
		
		try {
			/*dataSource=DBUtil.getDataSource();
			connection = dataSource.getConnection();*/
			//dataSource=DBUtil.getDataSource();
			connection=DBUtil.getConnection();	
			PreparedStatement ps=connection.prepareStatement("insert into serviceTracker values(?,'Apply for checkbook',?,sysdate,'pending')");
			ps.setInt(1, serviceId);
			ps.setInt(2, account1);
			int a=ps.executeUpdate();
			if(a==0)
				throw new BankingException("unable to process your request...please contact bank");
			
	
		} catch (SQLException e) {
			throw new BankingException("unable to process your request...please contact bank");
		}
		
			return serviceId;	
		}
	
	int generateService()
	{
		int serviceId=0;
		Connection connection;
		try {
			/*dataSource=DBUtil.getDataSource();
			connection = dataSource.getConnection();*/
			//dataSource=DBUtil.getDataSource();
			connection=DBUtil.getConnection();	
			PreparedStatement ps1=connection.prepareStatement("select serv_seq.NEXTVAL from dual");
			ResultSet rs=ps1.executeQuery();
			if(rs.next())
				serviceId=rs.getInt(1);
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return serviceId;
	}
	

	@Override
	public List<ServiceTracker> serviceView(int account2)
	{
		Connection connection;
		ArrayList<ServiceTracker> tracker=new ArrayList<>();
		ResultSet rs=null;
		PreparedStatement ps=null;		
		try
		{
			/*dataSource=DBUtil.getDataSource();
			connection = dataSource.getConnection();*/
			//dataSource=DBUtil.getDataSource();
			connection=DBUtil.getConnection();		
		
		
		ps=connection.prepareStatement("select * from ServiceTracker where Account_Id=?");
		ps.setInt(1, account2);
		rs=ps.executeQuery();
		//tracker=new ArrayList<>();
		while(rs.next())
		{
			ServiceTracker track=new ServiceTracker();
			track.setServiceId(rs.getInt("Service_Id"));
			track.setServiceDescripton(rs.getString("Service_Description"));
			track.setAccountId(rs.getInt("Account_Id"));
			track.setServiceRaisedDate(rs.getDate("Service_Raised_Date"));
			track.setServiceStatus(rs.getString("Service_Status"));
			
			System.out.println(track+" in dao tracker");
			tracker.add(track);
			
			
		}
		connection.close();
		}
		catch(SQLException e)	//logger
		{
			e.printStackTrace();
		}
		catch(Exception e)					//Generic catch block
		{
			e.printStackTrace();
		}
		
		return tracker;
	}
	


	@Override
	public int changePassword(int userId, String password) throws BankingException 
	{
		Connection connection;
		int row;
		try {
			/*dataSource=DBUtil.getDataSource();
			connection = dataSource.getConnection();*/
			//dataSource=DBUtil.getDataSource();
			connection=DBUtil.getConnection();		
			System.out.println(userId+"   "+password+"   in changepassword");
			PreparedStatement ps=connection.prepareStatement("update User_Table set login_password=? where user_Id=?");
			ps.setString(1, password);
			ps.setInt(2, userId);
			row = ps.executeUpdate();
		} catch (SQLException e) 
		{
			throw new BankingException("Unable to update");
		}
		return row;
	}

	@Override
	public List<UserTable> getAccountId(int userId) {
		
		Connection connection;
		ArrayList<UserTable> users=new ArrayList<>();
		ResultSet rs=null;
		PreparedStatement ps=null;		
		//int accid[]=null;
		try
		{
			/*dataSource=DBUtil.getDataSource();
			connection = dataSource.getConnection();*/
			//dataSource=DBUtil.getDataSource();
			connection=DBUtil.getConnection();	
		
		
		ps=connection.prepareStatement("select * from UserTable where User_Id=?");
		ps.setInt(1, userId);
		rs=ps.executeQuery();
		//users=new ArrayList<>();
		int i=0;
		
		while(rs.next())
		{
			UserTable tab=new UserTable(); 
			tab.setAccountId(rs.getInt("Account_Id"));
			tab.setUserId(rs.getInt("user_Id"));
			tab.setPassword(rs.getString("login_password"));
			tab.setSecretQuestion(rs.getString("secret_question"));
			tab.setTransactionPassword(rs.getString("transaction_password"));
			tab.setLockStatus(rs.getString("lock_statuss"));
			//accid[i]=rs.getInt("Account_Id");
			i++;
			System.out.println(tab.toString());
			users.add(tab);
			
			
		}
		connection.close();
		}
		catch(SQLException e)	//logger
		{
			e.printStackTrace();
		}
		catch(Exception e)					//Generic catch block
		{
			e.printStackTrace();
		}
		
		return users;
	}

	@Override
	public void ownFundTransfer(int accountPayer, int accountPayee,double amount) throws BankingException, SQLException {
		
		Connection connection = null;
		ResultSet rs=null;
		PreparedStatement ps=null;
		double currentBalance=getBalance(accountPayer);
		double a=0;
		double b=0;
		if(currentBalance < amount){
			
			throw new BankingException("Insufficient Balance !");
		}
		else 
		{
			a=currentBalance-amount;
			try 
			{
				/*dataSource=DBUtil.getDataSource();
				connection = dataSource.getConnection();*/
				//dataSource=DBUtil.getDataSource();
				connection=DBUtil.getConnection();	
				//connection.commit();
				connection.setAutoCommit(false);
				System.out.println(accountPayer);
				System.out.println(accountPayee);
				ps=connection.prepareStatement("update AccountMaster set Account_Balance=? where Account_Id=?");
				ps.setDouble(1,a);
				ps.setInt(2, accountPayer);
				ps.executeQuery();
				double currBalance=getBalance(accountPayee);
				b=currBalance+amount;
				ps=connection.prepareStatement("update AccountMaster set Account_Balance=? where Account_Id=?");
				ps.setDouble(1,b);
				ps.setInt(2, accountPayee);
				ps.executeQuery();
				ps=connection.prepareStatement("insert into FundTransfer values(fundtran_seq.NEXTVAL,?,?,sysdate,?)");
				ps.setInt(1, accountPayer);
				ps.setInt(2, accountPayee);
				ps.setDouble(3, amount);
				ps.execute();
				ps=connection.prepareStatement("insert into transaction values(tran_seq.NEXTVAL,'debit',sysdate,'Fund Transfer',?,?)");
				ps.setDouble(1, amount);
				ps.setInt(2, accountPayer);
				ps.executeQuery();
				ps=connection.prepareStatement("insert into transaction values(tran_seq.NEXTVAL,'credit',sysdate,'Fund Transfer',?,?)");
				ps.setDouble(1, amount);
				ps.setInt(2, accountPayee);
				ps.executeQuery();
				connection.commit();
				
			} catch (SQLException e) {
				
				e.printStackTrace();
				connection.rollback();
				throw new BankingException("Failed transfer !");
			}
		}
		
		connection.close();
	}
	
	public double getBalance(int accountId) throws BankingException{
		
		Connection connection;
		ResultSet rs=null;
		PreparedStatement ps=null;
		double amount;
		try {
			/*dataSource=DBUtil.getDataSource();
			connection = dataSource.getConnection();*/
			//dataSource=DBUtil.getDataSource();
			connection=DBUtil.getConnection();	
			amount = 0;
			
			
			ps=connection.prepareStatement("select Account_Balance from AccountMaster where Account_ID=?");
			ps.setInt(1,accountId);
			rs=ps.executeQuery();
			if(rs.next()){
				amount=rs.getDouble("Account_Balance");
			}
		} catch (SQLException e) {
			throw new BankingException("Unavailable to retrieve balances");
		}
		return amount;
		}
	
	public List<PayeeTable> getPayee(int accountId)
	{
		Connection connection;
		ArrayList<PayeeTable> payee=null;
		ResultSet rs=null;
		PreparedStatement ps=null;		
		try
		{
			/*dataSource=DBUtil.getDataSource();
			connection = dataSource.getConnection();*/
			//dataSource=DBUtil.getDataSource();
			connection=DBUtil.getConnection();	
		
		
		ps=connection.prepareStatement("select * from PayeeTable where Account_Id=?");
		ps.setInt(1, accountId);
		rs=ps.executeQuery();
		payee=new ArrayList<>();
		while(rs.next())
		{
			PayeeTable tab=new PayeeTable();
			tab.setAccountId(rs.getInt("AccountId"));
			tab.setPayeeAccountId(rs.getInt("Payee_Account_Id"));
			tab.setNickname(rs.getString("Nickname"));
			

			payee.add(tab);
			
			
		}
		connection.close();
		}
		catch(SQLException e)	//logger
		{
			e.printStackTrace();
		}
		catch(Exception e)					//Generic catch block
		{
			e.printStackTrace();
		}
		
		return payee;
	}

	@Override
	public void addPayee(PayeeTable payee) throws BankingException {
		Connection connection;
		PreparedStatement ps;
		//dataSource=DBUtil.getDataSource();
		try {
			/*dataSource=DBUtil.getDataSource();
			connection = dataSource.getConnection();*/
			//dataSource=DBUtil.getDataSource();
			connection=DBUtil.getConnection();	
			ps=connection.prepareStatement("insert into payeeTable values(?,?,?)");
			ps.setInt(1, payee.getAccountId());
			ps.setInt(2, payee.getPayeeAccountId());
			ps.setString(3, payee.getNickname());
			ps.executeQuery();
			connection.close();
		} catch (SQLException e) {
			throw new BankingException("Failed to add!!! Contact Bank !");
		}
	}




	@Override
	public void insertAccountHolder(Customer customer) 
	{
		Connection connection = null;
		ResultSet res = null;
		PreparedStatement pstmt = null;
		try 
		{
			/*dataSource=DBUtil.getDataSource();
			connection = dataSource.getConnection();*/
			//dataSource=DBUtil.getDataSource();
			connection=DBUtil.getConnection();	
			
			pstmt=connection.prepareStatement("insert into customer values(?,?,?,?,?)");
			
			pstmt.setString(2, customer.getCustomerName());
			pstmt.setString(3, customer.getEmail());
			pstmt.setString(4, customer.getAddress());
			pstmt.setLong(1, customer.getAccountId())
			;
			
			pstmt.execute();

			connection.close();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}




	@Override
	public void insertAccount(AccountMaster account) {
		// TODO Auto-generated method stub
		
	}




	@Override
	public void updateTracker(long accountId, String status) {
		// TODO Auto-generated method stub
		
	}




	@Override
	public UserTable getUser(int userId) {
	Connection connection;
	ResultSet res = null;
	PreparedStatement pstmt = null;
	UserTable user=new UserTable();
	try {
		/*dataSource=DBUtil.getDataSource();
		connection = dataSource.getConnection();*/
		//dataSource=DBUtil.getDataSource();
		connection=DBUtil.getConnection();	
		pstmt=connection.prepareStatement("select * from user_table where user_Id=?");
		pstmt.setInt(1, userId);
		res=pstmt.executeQuery();
		if(res.next())
		{
			user.setAccountId(res.getInt("Account_Id"));
			user.setUserId(res.getInt("User_Id"));
			user.setPassword(res.getString("Login_password"));
			user.setSecretQuestion(res.getString("Secret_Question"));
			user.setTransactionPassword(res.getString("Transaction_Password"));
			user.setLockStatus(res.getString("Lock_Status"));
		}
		connection.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		return user;
	}

	}
		
	
		
	


