package com.capgemini.dao;

import java.sql.SQLException;
import java.util.List;

import com.capgemini.entity.AccountMaster;
import com.capgemini.entity.Customer;
import com.capgemini.entity.PayeeTable;
import com.capgemini.entity.ServiceTracker;
import com.capgemini.entity.Transaction;
import com.capgemini.entity.UserTable;
import com.capgemini.exception.BankingException;

public interface IUserBankDao 
{

	public void insertAccountHolder(Customer customer);
	public void insertAccount(AccountMaster account);
	public void updateTracker(long accountId, String status);
	
	
	int login(int userId, String password) throws BankingException;

	boolean register(UserTable user) throws BankingException;

	

	List<Transaction> getDetailsMini(int accountNo);

	AccountMaster getAccount(int res) throws BankingException;

	String getAddress(int accountNo) throws BankingException;

	int updateAddress(String add,int accountNo) throws BankingException;

	int reqCheckBook(int account1) throws BankingException;

	List<ServiceTracker> serviceView(int account2);
	
	int changePassword(int userId, String password) throws BankingException;

	List<UserTable> getAccountId(int userId);

	void ownFundTransfer(int accountPayer, int accountPayee, double amount) throws BankingException, SQLException;
	
	List<PayeeTable> getPayee(int accountId);

	void addPayee(PayeeTable payee) throws BankingException;
	 UserTable getUser(int userId);


	

}
