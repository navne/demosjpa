package com.capgemini.dao;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import com.capgemini.entity.AccountMaster;
import com.capgemini.entity.Customer;
import com.capgemini.utility.DBUtil;


public class BankDaoImpl implements BankDao 
{
	private DataSource dataSource;
	//private int accountId=createAccountNo();
	
	@Override
	public void insertAccountHolder(Customer customer) 
	{		
		
		Connection connection = null;
		ResultSet res = null;
		PreparedStatement pstmt = null;
		try 
		{
		//	dataSource=DBUtil.getDataSource();
			connection=DBUtil.getConnection();
			//accountId=createAccountNo();
			
			pstmt=connection.prepareStatement("insert into Customer  values(?,?,?,?,?)");
			
			//pstmt.setLong(1, accountId);
			pstmt.setInt(1, customer.getAccountId());
			pstmt.setString(2, customer.getCustomerName());
			pstmt.setString(3, customer.getEmail());
			pstmt.setString(4, customer.getAddress());
			pstmt.setString(5,customer.getPanCard());
			
			pstmt.execute();

			connection.close();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		
	}

	@Override
	public void insertAccount(AccountMaster account) 
	{
		Connection connection = null;
		ResultSet res = null;
		PreparedStatement pstmt = null;
		try 
		{
			//dataSource=DBUtil.getDataSource();
			connection=DBUtil.getConnection();			
			pstmt=connection.prepareStatement("insert into AccountMaster values (?,?,?,SYSDATE)");
			
			//pstmt.setLong(1, accountId);
			pstmt.setInt(1, account.getAccountId());
			pstmt.setString(2, account.getAccountType());
			pstmt.setDouble(3, account.getAccountBalance());
			
			pstmt.execute();
			connection.close();
			
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	
	}

	@Override
	public void updateTracker(int accountId,int serviceId, String status) 
	{

		Connection connection = null;
		ResultSet res = null;
		PreparedStatement pstmt = null;
		try 
		{
			//dataSource=DBUtil.getDataSource();
			connection=DBUtil.getConnection();		
			/*dataSource=DBUtil.getDataSource();
			connection=dataSource.getConnection();*/
			
			pstmt=connection.prepareStatement("Update serviceTracker SET service_status=? WHERE Account_Id=? and service_id=?");
			pstmt.setInt(3, serviceId);
			pstmt.setInt(2,accountId);
			pstmt.setString(1,status);
			
			pstmt.execute();
			connection.close();
			
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}

	@Override
	public int createAccountNo()
	{
		Connection connection = null;
		ResultSet res = null;
		PreparedStatement pstmt = null;
		int accountId=0;
		try 
		{
			//dataSource=DBUtil.getDataSource();
			connection=DBUtil.getConnection();		
			/*dataSource=DBUtil.getDataSource();
			connection=dataSource.getConnection();
			*/
			pstmt=connection.prepareStatement("SELECT account_seq.NEXTVAL from dual");
			res=pstmt.executeQuery();
			if(res.next())
				accountId=res.getInt(1);
			
			
			connection.close();
			
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	

		return accountId;
	}



}
