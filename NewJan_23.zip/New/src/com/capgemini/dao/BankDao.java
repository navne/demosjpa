package com.capgemini.dao;

import com.capgemini.entity.AccountMaster;
import com.capgemini.entity.Customer;

public interface BankDao 
{
	public void insertAccountHolder(Customer customer);
	public void insertAccount(AccountMaster account);
	public int createAccountNo();
	
	void updateTracker(int accountId, int serviceId, String status);
}
