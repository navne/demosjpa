package com.capgemini.utility;

import java.sql.Connection;
import java.sql.SQLException;

import oracle.jdbc.pool.OracleDataSource;

//singleton
public class DBUtil {
	
private static OracleDataSource ods;
	
	static {
		try {
			ods=new OracleDataSource();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//private static Connection connection;
	
	public static Connection getConnection() throws SQLException{
		Connection connection=null;
				
		//if(connection==null){
			//OracleDataSource ods=new OracleDataSource();
			ods.setURL("jdbc:oracle:thin:@Shailja_Pal__SPAcer:1521:XE");
			ods.setUser("system");
			ods.setPassword("1234");
			ods.setDriverType("thin");
			ods.setNetworkProtocol("tcp");
			connection=ods.getConnection();
			
		//}
			return connection;
					
	}
	
	
}
