package com.capgemini.controller;

import java.io.IOException;

import javax.jms.Session;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.capgemini.dao.BankDao;
import com.capgemini.dao.BankDaoImpl;
import com.capgemini.dao.UserBankDao;
import com.capgemini.dao.IUserBankDao;
import com.capgemini.entity.AccountMaster;
import com.capgemini.entity.Customer;
import com.capgemini.entity.PayeeTable;
import com.capgemini.entity.ServiceTracker;
import com.capgemini.entity.Transaction;
import com.capgemini.entity.UserTable;
import com.capgemini.exception.BankingException;



@WebServlet("*.do")
public class BankController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	IUserBankDao dao=null;
	HttpSession session=null;
	int usernow=0;
	BankDao daoB=null;
	/*private BankService service;*/
	//private HttpSession session;
	private AccountMaster accountMaster;
	private Customer customer;
	
    public BankController() 
    {
        dao=new UserBankDao();
        daoB=new  BankDaoImpl() ;
			
		
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

			doPost(request, response);
	}
	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uri=request.getRequestURI();
		String action=uri.substring(uri.lastIndexOf("/"),uri.length());
		switch (action)
		{
		
		case"/balance.do":
			response.sendRedirect("/New/view/balance.jsp");
			break;
		
		case"/forgotPassword.do":
			response.sendRedirect("/New/view/secretQuestion.jsp");
			break;
			
		case "/secretQuestion.do":
			int userId5=Integer.parseInt(request.getParameter("userId"));
			UserTable user1=dao.getUser(userId5);
			request.setAttribute("user", user1);
			RequestDispatcher dispatcher12=request.getRequestDispatcher("/view/regenpass.jsp");
			dispatcher12.forward(request, response);
			break;
		
		case"/logout.do":
			session.invalidate();
			response.sendRedirect("/New/view/index.jsp");
			break;
		
		case "/account.do":
		{
			String Customer_Name = request.getParameter("Customer_Name");
			String Address = request.getParameter("Address");
			String mobileNumber = request.getParameter("mobileNumber");
			String Email = request.getParameter("Email");
			String Account_Type = request.getParameter("Account_Type");
			String Pancard= request.getParameter("panCard");
			//System.out.println(Account_Type);
			
			double openingBal = Double.parseDouble(request.getParameter("openingBal"));
			
			accountMaster = new AccountMaster(Account_Type, openingBal);
			
		
			customer= new Customer( Customer_Name, Email, Address, Pancard);
			System.out.println(customer);
			System.out.println(accountMaster);
			
			try 
			{
				 int accountId=daoB.createAccountNo();
				 customer.setAccountId(accountId);
				 accountMaster.setAccountId(accountId);
				daoB.insertAccount(accountMaster);
				daoB.insertAccountHolder(customer);
				System.out.println("inserted");
				response.sendRedirect("/New/view/adminfunc.jsp");
			} 
			catch (Exception e) 
			{				
				e.printStackTrace();
			}
			
			break;
		}
			
		case "/insertFormAdmin.do":
		{
			response.sendRedirect("NewAccountPage.jsp");
			break;
		}

		case "/updateTrackerForm.do":
		{
			response.sendRedirect("updateTrackerForm.jsp");
			break;
		}
		
		case "/updateTracker.do":
		{
			String status=request.getParameter("status");
			int accountId=Integer.parseInt(request.getParameter("id"));
			int serviceId=Integer.parseInt(request.getParameter("servId"));
			try 
			{
				daoB.updateTracker(accountId,serviceId, status);
				response.sendRedirect("/New/view/adminfunc.jsp");
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			}
			break;
		}
		

		
		case"/admincheck.do":
			String adname=request.getParameter("addname");
			String password10=request.getParameter("password");
			if(adname.equals("admin") && password10.equals("admin"))
				response.sendRedirect("/New/view/adminfunc.jsp");
			else
			{
				String pro="Invalid credentials";
				request.setAttribute("message", pro);
				RequestDispatcher dispatcher=request.getRequestDispatcher("/view/loginadmin.jsp");
				dispatcher.forward(request, response);
			}
				
			break;
		case"/adminLogin.do":
			response.sendRedirect("/New/view/loginadmin.jsp");
			break;
		
		case"/login.do":
			response.sendRedirect("/New/view/login.jsp");
			break;
			
		case"/changeforpass.do":
			String password15=request.getParameter("password");
			int userId15=(int) session.getAttribute("userId");
			try {
				dao.changePassword(userId15, password15);
			} catch (BankingException e3) {
				// TODO Auto-generated catch block
				e3.printStackTrace();
			}
			response.sendRedirect("/New/view/success.jsp");
			break;
		case"/home.do":
			int userId25=Integer.parseInt(request.getParameter("userId"));
			String password5=request.getParameter("password");
			if(password5.equals("SBQrT5"))
			{
				session=request.getSession();
				session.setAttribute("userId", userId25);
				response.sendRedirect("/New/view/changepass.jsp");
				
			}
			int res=0;
			try {
				res = dao.login(userId25,password5);
				
			} catch (BankingException e2) {
				e2.printStackTrace();
				throw new ServletException(e2.getMessage(),e2);
			}
			AccountMaster master=new AccountMaster();
			if(res>0)
			{
				
			try {
					master=dao.getAccount(res);
				} catch (BankingException e) {
					e.printStackTrace();
					throw new ServletException(e.getMessage(),e);
				}
				session=request.getSession();
				session.setAttribute("Master", master);
				session.setAttribute("userId", userId25);
				usernow=userId25;
				response.sendRedirect("/New/view/home.jsp");
			}
			else
			{
				//System.out.println("&&&&&&&&&&&&&&"+res);
				String pro="Invalid credentials";
				request.setAttribute("message", pro);
				RequestDispatcher dispatcher=request.getRequestDispatcher("/view/login.jsp");
				dispatcher.forward(request, response);
			}
			break;
		
		case"/register.do":
				response.sendRedirect("/New/view/registerDetails.jsp");
			break;
		
		case"/registerDetails.do":
				int accountId=Integer.parseInt(request.getParameter("accountId"));
				int userId1=Integer.parseInt(request.getParameter("userId"));
				String password1=request.getParameter("password");
				String secretQuestion=request.getParameter("secretQuestion");
				String transactionPassword=request.getParameter("transactionPassword");
				UserTable user=new UserTable(accountId, userId1, password1, secretQuestion, transactionPassword, "0");
			boolean flag=false;
			try {
				flag = dao.register(user);
			} catch (BankingException e1) {
				// TODO Auto-generated catch block
				throw new ServletException(e1.getMessage(),e1);
			}
				if(flag==true)
					response.sendRedirect("/New/view/login.jsp");
				else
					response.sendRedirect("/New/view/registerDetails.jsp");
			break;
			
		case"/mini.do":
			try {
				AccountMaster mas=new AccountMaster();
				mas=(AccountMaster) session.getAttribute("Master");
				System.out.println(mas +"in mini");
				int accountNo=mas.getAccountId();
				List<Transaction> list=dao.getDetailsMini(accountNo);
				if(list.isEmpty()){
					throw new BankingException("No Transaction");
				}
				else{
				request.setAttribute("list", list);
				RequestDispatcher dispatcher=request.getRequestDispatcher("/view/mini.jsp");
				dispatcher.forward(request, response);
				}
			} catch (BankingException e) {
				throw new ServletException(e.getMessage(),e);
			}
			break;
			
		case"/updateAddress.do":
			AccountMaster mas=(AccountMaster) session.getAttribute("Master");
			int accountNo=mas.getAccountId();
			String address=null;
			try {
				address=dao.getAddress(accountNo);
			} catch (BankingException e) {
				throw new ServletException(e.getMessage(),e);
		
			}
			request.setAttribute("address", address);
			RequestDispatcher rd=request.getRequestDispatcher("/view/update.jsp");
			rd.forward(request, response);
			
			break;
			
		case"/update.do":
			AccountMaster mas1=(AccountMaster) session.getAttribute("Master");
			int account=mas1.getAccountId();
			String add=request.getParameter("address");
			int row;
			try {
				row = dao.updateAddress(add,account);
			} catch (BankingException e) {
				throw new ServletException(e.getMessage(),e);
			}
			response.sendRedirect("/New/view/success.jsp");
				
			break;
		case"/requestCheckbook.do":
			AccountMaster mas2=(AccountMaster) session.getAttribute("Master");
			int account1=mas2.getAccountId();
			try {
				int serviceId=dao.reqCheckBook(account1);
			} catch (BankingException e) {
				throw new ServletException(e.getMessage(),e);
			}
			
			response.sendRedirect("/New/view/success.jsp");
			
			break;
			
		case"/trackServices.do":
			AccountMaster mas3=(AccountMaster) session.getAttribute("Master");
			int account2=mas3.getAccountId();
			List<ServiceTracker> tracker=dao.serviceView(account2);
			request.setAttribute("list", tracker);
			RequestDispatcher rd1=request.getRequestDispatcher("/view/viewServices.jsp");
			rd1.forward(request, response);
			
			break;
		case"/changePassword.do":
			response.sendRedirect("/New/view/changePassword.jsp");
			break;
		case"/changePass.do":
			int userId2=(int) session.getAttribute("userId");
			String password2=request.getParameter("password");
			
			try 
			{
				int flag1=dao.changePassword(userId2, password2);
			} 
			catch (BankingException e) 
			{
				throw new ServletException(e.getMessage(),e);
			}
			response.sendRedirect("/New/view/success.jsp");
			break;
		case"/fundTransfer.do":
			response.sendRedirect("/New/view/mainFundTransfer.jsp");
			break;
	case"/ownTransfer.do":
			int userId3=(int) session.getAttribute("userId");
			
			List<UserTable> list=dao.getAccountId(userId3);
			request.setAttribute("accountIds", list);
			RequestDispatcher ds=request.getRequestDispatcher("/view/ownTransfer.jsp");
			ds.forward(request, response);
			break;
			
		case "/fundownTransfer.do":
			
			int accountPayer=Integer.parseInt(request.getParameter("payer"));
			int accountPayee=Integer.parseInt(request.getParameter("payee"));
			double amount=Double.parseDouble(request.getParameter("amount"));
			
			try {
				dao.ownFundTransfer(accountPayer,accountPayee,amount);
			} catch (BankingException | SQLException e) {
				e.printStackTrace();
			}
			response.sendRedirect("/New/view/success.jsp");
			
			break;
		case"/otherTransfer.do":
			int userId4=(int) session.getAttribute("userId");
			List<UserTable> list1=dao.getAccountId(userId4);
			request.setAttribute("accountIds", list1);
			RequestDispatcher ds1=request.getRequestDispatcher("/view/otherTransfer.jsp");
			ds1.forward(request, response);
			break;
			
		case"/genpayee.do":
			int accId=Integer.parseInt(request.getParameter("payer"));
			List <PayeeTable> payeeList=dao.getPayee(accId);
			request.setAttribute("payeeList",payeeList );
			RequestDispatcher ds2=request.getRequestDispatcher("/view/otherTransfer.jsp");
			ds2.forward(request, response);
			break;
			
		case"/addpayee.do":
			int accId1=Integer.parseInt(request.getParameter("payer"));
			request.setAttribute("payer", accId1 );
			RequestDispatcher ds3=request.getRequestDispatcher("/view/enterPayeeDetails.jsp");
			ds3.forward(request, response);
			break;
			
		case"/addPayeeTable.do":
			int accId2=Integer.parseInt(request.getParameter("accountId"));
			int payeeaccId=Integer.parseInt(request.getParameter("payeeAccountId"));
			String nickname=request.getParameter("nickname");
			PayeeTable payee=new PayeeTable(accId2,payeeaccId,nickname);
			try {
				dao.addPayee(payee);
			} catch (BankingException e) {
				throw new ServletException(e.getMessage(),e);
			}
			response.sendRedirect("/New/view/success.jsp");
			break;
			
		case "/firstpage.do":
		{
			response.sendRedirect("/New/view/home.jsp");
			break;
		}
		}
		
		
		
	}

}
