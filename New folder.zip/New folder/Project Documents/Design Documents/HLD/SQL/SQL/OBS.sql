


drop table usertable;
drop table customer;
drop table account_master;
drop table transactions;
drop sequence trans_seq;
drop table service_tracker;
drop table admintable;
truncate table fund_transfer;
truncate table payee;
truncate table myaccountanotherbank;
drop table myaccountanotherbank;
drop table payee;
drop table fund_transfer;

create table UserTable
(Account_ID NUMBER REFERENCES Customer(account_id),
user_id NUMBER primary key,
login_password VARCHAR2(15) Unique,
secret_question VARCHAR2(50) Unique,
Transaction_password VARCHAR2(15),
lock_status VARCHAR2(1),
counter number
);

insert into UserTable values(10001,101,'pass@123','tommy','password','N',0);
insert into UserTable values(10002,102,'pass789','tom','pass012','N',0);
insert into UserTable values(10003,103,'pass567','nick','pass890','N',0);


create sequence user_seq start with 104;
create table Customer
( 
Account_ID NUMBER(10) primary key, 
customer_name VARCHAR2(50) not null, 
Email VARCHAR2(30) Unique, 
Address VARCHAR2(100), 
Pancard VARCHAR2(15) Unique,
Mobile Varchar2(10),
Account_type char(1),
Balance number
);

insert into Customer values(10001,'Harshita','harshita@gmail.com','pune','332211','9549994145','S',15000);
insert into Customer values(10002,'Shikhar','shikhar@gmail.com','pune','7894','7894561230','C',20000);
insert into Customer values(10003,'Yogesh','Yogesh@gmail.com','bangalore','44556','7418529630','S',22000);

create table Account_Master(
Account_ID NUMBER(10) REFERENCES Customer(account_id), 
Account_Type VARCHAR2(25), 
Account_Balance NUMBER(15),
Open_Date DATE);

insert into Account_Master values(10001,'S',15000,sysdate);
insert into Account_Master values(10002,'C',20000,sysdate);
insert into Account_Master values(10003,'S',22000,sysdate);





create table Transactions( 
Transaction_ID NUMBER primary key,
Tran_description VARCHAR2(100), 
DateofTransaction DATE, 
TransactionType VARCHAR2(1),
 TranAmount NUMBER(15),
Account_No NUMBER(10)REFERENCES Customer(account_id)
);
create sequence trans_seq start with 3001;
insert into Transactions values(trans_seq.nextval,'credited','12-feb-2014','S',5000,10001);

insert into Transactions values(trans_seq.nextval,'debited','13-mar-2013','A',3000,10002);
insert into Transactions values(trans_seq.nextval,'credited','10-apr-2012','D',4000,10004);
insert into Transactions values(trans_seq.nextval,'debited','12-may-2014','F',6000,10005);
insert into Transactions values(trans_seq.nextval,'credited','12-jun-2014','s',8000,10001);

insert into Transactions values(trans_seq.nextval,'debited','16-aug-2011','A',2000,10002);
insert into Transactions values(trans_seq.nextval,'credited','09-jan-2012','D',4000,10004);
insert into Transactions values(trans_seq.nextval,'debited',23-aug-2010','F',5000,10005);
insert into Transactions values(trans_seq.nextval,'credited','03-dec-2014','S',6000,10001);
insert into Transactions values(trans_seq.nextval,'debited','08-oct-2016','A',7000,10002);
insert into Transactions values(trans_seq.nextval,'debited','10-nov-2015','D',8000,10004);
insert into Transactions values(trans_seq.nextval,'credited','17-mar-2013','F',9000,10005);
insert into Transactions values(trans_seq.nextval,'debited','22-feb-2012','S',1000,10001);
insert into Transactions values(trans_seq.nextval,'credited','18-apr-2011','A',20000,10002);
insert into Transactions values(trans_seq.nextval,'credited','20-jun-2014','D',4000,10004);
insert into Transactions values(trans_seq.nextval,'debited','18-jul-2015','F',30000,10005);
insert into Transactions values(trans_seq.nextval,'credited','30-aug-2013','S',90000,10001);


Create table Service_Tracker(
Service_ID NUMBER, 
Service_Description VARCHAR2(100),
Account_ID NUMBER REFERENCES Customer(account_id), 
Service_Raised_Date DATE ,
Service_status VARCHAR2(20),
userid number REFERENCES usertable(user_id)
);


insert into Service_tracker values(45612,'CheckBookRequest',10001,'12-jan-2014','open',101);
insert into Service_tracker values(51236,'CheckBookRequest',10002,'25-jul-2013','open',102);
insert into Service_tracker values(789456,'CheckBookRequest',10003,'12-mar-2012','open',103);


create table AdminTable(
admin_id varchar2(10) primary key,
password varchar2(10) unique,
name varchar2(10)
);


insert into AdminTable values('3001','password','Harshita');
insert into AdminTable values('3002','pass','Namita');


create table payee(account_id number(7)  REFERENCES Customer(account_id),payee_account_id number primary key,nickname varchar(20));
insert into payee values(10001,10002,'Shikhar');
insert into payee values(10001,10002,'Shikhar');
insert into payee values(10001,10003,'yogesh');
insert into payee values(10002,10001,'harshita');
insert into payee values(10002,10003,'yogesh');
insert into payee values(10003,10001,'harshita');
insert into payee values(10003,10002,'shikhar');

create table fund_transfer (fundtransfer_id number primary key,account_id number  REFERENCES Customer(account_id),payee_account_id number REFERENCES payee(payee_account_id),date_of_transfer date,transfer_amount number);

 
create table myaccountanotherbank(name varchar(20),account_id number REFERENCES Customer(account_id),bankname varchar(10));
insert into myaccountanotherbank values( 'Harshita',000,'-----');
insert into myaccountanotherbank values( 'Harshita',000,'-----');
insert into myaccountanotherbank values( 'Harshita',10001,'sbi');
insert into myaccountanotherbank values( 'Harshita',10001,'hdfc');
insert into myaccountanotherbank values( 'Shikhar',10002,'sbi');
insert into myaccountanotherbank values( 'Shikhar',10002,'hdfc');
insert into myaccountanotherbank values( 'Shikhar',10002,'icici');
insert into myaccountanotherbank values( 'Yogesh',10003,'icici');
insert into myaccountanotherbank values( 'Yogesh',10003,'sbi');
insert into myaccountanotherbank values( 'Yogesh',10003,'citi');







