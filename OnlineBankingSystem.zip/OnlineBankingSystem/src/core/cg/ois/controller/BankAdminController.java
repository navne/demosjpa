package core.cg.ois.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import core.cg.ois.beans.AccountMaster;
import core.cg.ois.beans.Customer;
import core.cg.ois.beans.ServiceTracker;
import core.cg.ois.beans.Transaction;
import core.cg.ois.exception.LoginException;
import core.cg.ois.service.BankServiceImpl;
import core.cg.ois.service.IBankservice;


@WebServlet("*.mvc")
public class BankAdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private AccountMaster accountMaster = null;
	private Customer customer = null;
	private IBankservice service = null;


	@Override
	public void init() throws ServletException {
		accountMaster = new AccountMaster();
		customer = new Customer();
		service = new BankServiceImpl();
	}


	public BankAdminController() {
		super();
		// TODO Auto-generated constructor stub
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);

	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getServletPath();
		HttpSession session = null;
		String actionPage = null;
		System.out.println(action);
		

		switch (action) {
		case "/adminlogin.mvc":
			session = request.getSession(true);
			String userName = request.getParameter("adminUserId");
			String adminPass = request.getParameter("adminPass");
			session.setAttribute("userId", userName);


			if(userName.equals("admin") && adminPass.equals("admin"))
			{
				actionPage = "adminhome.jsp";
			}
			else
			{
				
				session.setAttribute("msg", "invalid userId and Passworsd");
				actionPage = "adminlogin.jsp";
			}
			break;

		case "/createnewaccount.mvc":
			session = request.getSession(false);
			if(session != null)
			{
				
				actionPage = "newaccount.jsp";
			}
			else
			{
				session =request.getSession(false);
				session.setAttribute("msg", "you need to login first");
				actionPage = "adminlogin.jsp";
			}
			break;

		case "/account.mvc":
			session = request.getSession(false);
			if(session != null)
			{

			String Customer_Name = request.getParameter("Customer_Name");
			String Address = request.getParameter("Address");
			String mobileNumber = request.getParameter("mobileNumber");
			String Email = request.getParameter("Email");
			String Account_Type = request.getParameter("Account_Type");
			String Pancard= request.getParameter("panCard");
			//System.out.println(Account_Type);

			double openingBal = Double.parseDouble(request.getParameter("openingBal"));

			accountMaster = new AccountMaster(Account_Type, openingBal);


			customer= new Customer( Customer_Name, Email, Address, Pancard);
			System.out.println(customer);
			System.out.println(accountMaster);

			try 
			{
				int accountId=service.createAccountNo();
				System.out.println(accountId);
				customer.setAccountId(accountId);
				accountMaster.setAccountId(accountId);
				service.insertAccount(accountMaster);
				service.insertAccountHolder(customer);
				session.setAttribute("accountId", accountId);
				System.out.println("inserted");
				actionPage ="successaccount.jsp";
			} 
			catch (LoginException e) 
			{				
				e.printStackTrace();
			}
			}
			else
			{
				session = request.getSession(false);
			
				session.setAttribute("msg", "you need to login first");
				actionPage = "adminlogin.jsp";
			}

			break;
		case "/trackservicerequest.mvc":
			System.out.println("inview");
			session = request.getSession(false);
			if(session != null)
			{
				try
				{
					List<ServiceTracker> servicelist = service.showall();
					session.setAttribute("list", servicelist);
					actionPage = "servicelist.jsp";


				}
				catch (LoginException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else
			{
				session = request.getSession(false);
				session.setAttribute("msg", "you need to login first");
				actionPage ="adminlogin.jsp";
				
			}


			break;

		case "/updateform.mvc":
			session = request.getSession(false);
			String id = request.getParameter("id");
			System.out.println(id);
			ServiceTracker serviceTracker = new ServiceTracker();
			if(session != null && id != null)
			{
				int serviceId = Integer.parseInt(id);
				try {
					serviceTracker = service.searchserviceid(serviceId);
					actionPage = "updatetrackerform.jsp";
					session.setAttribute("service" , serviceTracker);
				} catch (LoginException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			else 
			{
				
				session.setAttribute("msg", "you need to login first");
				actionPage="adminlogin.jsp";

			}
			break;

		case "/updateTracker.mvc":

			session = request.getSession(false);
			
			if(session != null)
			{

			String status=request.getParameter("status");
			String accId=request.getParameter("id");
			String serId=request.getParameter("servId");

			int accountId=Integer.parseInt(request.getParameter("id"));
			int serviceId=Integer.parseInt(request.getParameter("servId"));

			try 
			{
				
				service.updateTracker(accountId,serviceId, status);
				actionPage = "trackservicerequest.mvc";
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			}
			}
			else
			{
				session = request.getSession(false);
				
				session.setAttribute("msg", "you need to login first");
				actionPage = "adminlogin.jsp";
			}

		break;
		
		case "/viewalltransaction.mvc":
			session = request.getSession(false);
			
			System.out.println("inview");
			if(session != null )
			{
		
					try
					{
		
						List<Transaction> mList = service.getAllTransactions();
						System.out.println(mList);
						session.setAttribute("mList", mList);
						actionPage ="transactiondetails.jsp";
					}
					catch (LoginException e) {
						
						
						session.setAttribute("error", "No Transaction");
						actionPage ="transactiondetails.jsp";
						e.printStackTrace();
					}
					 
				}
		
				else
				{
					session = request.getSession(false);

					
					session.setAttribute("msg", "you need to login first");
					actionPage = "adminlogin.jsp";
				}

				
				
			break;
		
		
		
		
		case "/logout.mvc":
			session = request.getSession(false);
			if(session != null)
			{
			session.invalidate();
			actionPage ="adminlogin.jsp";
			}
			else
			{
				session = request.getSession(false);
				session.setAttribute("msg", "you need to login first");
				actionPage = "adminlogin.jsp";
				session.invalidate();
			}
			break;
			
			
		














	default:
		actionPage ="adminlogin.jsp";
		break;
	}
	RequestDispatcher view = request.getRequestDispatcher(actionPage);
	view.forward(request, response);



}

}
