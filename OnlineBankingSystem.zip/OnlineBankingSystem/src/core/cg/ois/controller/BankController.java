package core.cg.ois.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import core.cg.ois.beans.AccountMaster;
import core.cg.ois.beans.UserTable;
import core.cg.ois.exception.BankingException;
import core.cg.ois.service.IObsService;
import core.cg.ois.service.ObsServiceImpl;


@WebServlet("*.do")
public class BankController extends HttpServlet {
	UserTable user = null;
	IObsService service = null;
	AccountMaster master = null;
	ControllerActionClass bankAction = null;

	@Override
	public void init() throws ServletException {
		
		bankAction = new ControllerActionClass();
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{

		String action = request.getServletPath();
		if(action==null) action="";
		System.out.println("URI: "+action);
		String actionPage = null;
		int userId = 0;		
		Object obj = null;



		switch (action) {

		case "/login.do":
			HttpSession session = request.getSession(true);
			actionPage = bankAction.processLogin(session, request);
			break;

		case "/home.do":
			System.out.println("inhome");
			session = request.getSession(false);
			actionPage = bankAction.processHome(session, request);
			break;


		case "/mini.do":
			session = request.getSession(false);
			System.out.println("mini");
			actionPage = bankAction.processMiniStatement(session , request);
			break;

		case "/ForgetPassword.do":

			actionPage = "securityQues.jsp";
			response.sendRedirect(actionPage);
			break;

		case "/forget.do":
			session = request.getSession(true);
			System.out.println("In Forget");
			actionPage = bankAction.processForget(request, session);			
			break;

		case "/recover.do":
			session = request.getSession(false);
			actionPage = bankAction.processQues(request, session);
			break;	

		case "/otp.do" :
			session = request.getSession(false);


			String otp = request.getParameter("otp");
			if(session != null && otp != null)
			{
				if(otp.equals("abc"))
				{
					actionPage = "enterpassword.jsp";
				}
				else
				{
					actionPage = "otp.jsp";
					session.setAttribute("errorotp", "Wrong Otp");	

				}
			}
			else
			{
				session = request.getSession(true);
				session.setAttribute("msg", "Invalid Input");
				actionPage = "clientlogin.jsp";
			}


			break;



		case "/changePassword.do":
			session = request.getSession(false);

			obj = session.getAttribute("userId");
			if(obj != null)
			{

				userId = (int)obj;
				session.setAttribute("userId", userId);
				actionPage = "changePass.jsp";
			}
			else
			{
				session = request.getSession(false);
				session.setAttribute("msg", "login first");

				actionPage = "clientlogin.jsp";
			}


			break;

		case "/changePass.do":
			session = request.getSession(false);
			actionPage = bankAction.changePassword(request, session);

			break;

		case "/updateAddress.do":
			session = request.getSession(false);
			actionPage = bankAction.updateCommunication(session, request);
			break;

		case "/Update.do" :
			session = request.getSession(false);
			actionPage = bankAction.updateAction(request, session);
			break;

		case "/ServiceRequest.do":
			session = request.getSession(false);

			//			userId = (int) session.getAttribute("userId");

			if(session != null)
			{
				obj = session.getAttribute("accountId");
				int accountId = (int)obj;
				actionPage =  "servicerequest.jsp";
			}
			else 
			{
				session = request.getSession(true);
				session.setAttribute("msg", "login first");	
				actionPage ="clientlogin.jsp";
			}





			break;


		case "/requestCheckbook.do":
			session = request.getSession(false);
			actionPage = bankAction.requestService(request, session);
			break;

		case "/trackServices.do" :
			session = request.getSession(false);
			actionPage = bankAction.trackService(request, session);
			break;

		case "/logout.do":
			session = request.getSession(false);
			if(session != null)
			{
				session.invalidate();
				actionPage = "clientlogin.jsp";
			}
			else
			{
				session = request.getSession(true);
				session.setAttribute("msg", "login first");
				actionPage = "clientlogin.jsp";
			}
			break;



		case"/fundTransfer.do":
			session = request.getSession(false);	

			if(session != null)
			{

				actionPage ="mainFundTransfer.jsp";
			}
			else
			{
				session = request.getSession(true);
				session.setAttribute("msg", "login first");
				actionPage ="clientlogin.jsp";
			}

			break;
		case"/ownTransfer.do":
			session = request.getSession(false);
			actionPage = bankAction.processFundTransfer(request, session);

			break;



		case "/fundownTransfer.do":
			session = request.getSession(false);
			actionPage= bankAction.transaction(request, session);
			break;


		case"/addPayee.do":
			session   = request.getSession(false);

			if(session != null)
			{
				actionPage ="enterPayeeDetails.jsp";
			}
			else
			{
				session = request.getSession(true);
				session.setAttribute("msg", "Please login first");
				actionPage = "clientlogin.jsp";
			}
			break;
			//				
		case"/addPayeeTable.do":
			session = request.getSession(false);
			actionPage = bankAction.processaddPayee(request, session);

			break;


		case"/addPayeeConfirm.do":
			session = request.getSession(false);
			actionPage = bankAction.confirmaddPayee(request , session);



			break;
		case "/register.do":
			actionPage = "register.jsp";


		case "/registerDetails.do":
			session = request.getSession();

			int accountId1 = Integer.parseInt(request.getParameter("accountId"));
			int userId1=Integer.parseInt(request.getParameter("userId"));
			String password1=request.getParameter("password");
			String secretQuestion=request.getParameter("secretQuestion");
			String transactionPassword=request.getParameter("transactionPassword");
			UserTable user=new UserTable(accountId1, userId1, password1, secretQuestion, transactionPassword, "0");
			boolean flag=false;
			try {
				flag = service.register(user);
			} catch (BankingException e1) {

				session.setAttribute("mesg", "Please Contact Bank");
				actionPage = "register.jsp";

			}
			if(flag==true)
			{
				session.setAttribute("user", user);
				actionPage = "successregister.jsp";
			}
			else
			{
				PrintWriter out = response.getWriter();
				out.println("invalid useriDd");
			}


			break;







		default:
			actionPage = "index.jsp";
			break;



		}
		RequestDispatcher rd = request.getRequestDispatcher(actionPage);
		rd.forward(request	, response);






	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}


}
