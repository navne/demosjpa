package core.cg.ois.service;

import com.cg.ois.exception.LoginException;

import core.cg.ois.beans.UserTable;

public interface IObsService 
{
	public int loginProcess(UserTable user) throws LoginException;
	public void update(int lock);

}
