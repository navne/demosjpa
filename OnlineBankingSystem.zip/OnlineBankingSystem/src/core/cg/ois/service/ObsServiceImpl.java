package core.cg.ois.service;

import com.cg.ois.exception.LoginException;

import core.cg.ois.beans.UserTable;
import core.cg.ois.dao.IObsDao;
import core.cg.ois.dao.ObsDaoImpl;

public class ObsServiceImpl implements IObsService {
	private IObsDao dao = null;




	public ObsServiceImpl() {
		dao = new ObsDaoImpl();
		// TODO Auto-generated constructor stub
	}




	@Override
	public int loginProcess(UserTable user) throws LoginException {
		return dao.loginProcess(user);
		// TODO Auto-generated method stub

	}




	@Override
	public void update(int lock) {
		dao.update(lock);
		
	}

}
