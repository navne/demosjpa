package core.cg.ois.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.sun.xml.internal.fastinfoset.sax.Properties;

public class dbUtil
{
	Properties pros = new Properties();

	
	static Connection con = null;
	
	public static Connection getConnection() {
		try {
			InitialContext  ic = new InitialContext();
			 DataSource ds  = (DataSource)ic.lookup("java:/newDS");
			  con = ds.getConnection();
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
		
	}
	

}
