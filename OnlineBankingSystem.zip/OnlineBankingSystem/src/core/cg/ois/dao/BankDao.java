package core.cg.ois.dao;

import java.util.List;

import core.cg.ois.beans.AccountMaster;
import core.cg.ois.beans.Customer;
import core.cg.ois.beans.ServiceTracker;
import core.cg.ois.beans.Transaction;
import core.cg.ois.exception.LoginException;

public interface BankDao 
{
	public void insertAccountHolder(Customer customer) throws LoginException;
	public void insertAccount(AccountMaster account) throws LoginException;
	public int createAccountNo() throws LoginException;
	public List<ServiceTracker> showall() throws LoginException;
	void updateTracker(int accountId, int serviceId, String status) throws LoginException;
	public ServiceTracker searchserviceid(int serviceId) throws LoginException;
	public List<Transaction> getAllTransactions() throws LoginException;
}
