package core.cg.ois.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.ois.exception.LoginException;

import core.cg.ois.beans.UserTable;
import core.cg.ois.util.dbUtil;

public class ObsDaoImpl implements IObsDao {


	public int loginProcess(UserTable user) throws LoginException {
		int status = 0;
		int accountId = 0;
		
		
		Connection con         = dbUtil.getConnection();
		PreparedStatement pstm = null;
		
		List<UserTable> login =new ArrayList<UserTable>();
		
		
		
		String Query = "SELECT LOCK_STATUS , Account_Id  FROM USER_TABLE where USER_ID = ? AND LOGIN_PASSWORD = ? ";
		ResultSet res = null;
		try
		{
			pstm = con.prepareStatement(Query);
			pstm.setInt(1, user.getUserId());
			pstm.setString(2, user.getPassword());
			
			res = pstm.executeQuery();
			
			while(res.next())
			{
				UserTable user1 = new UserTable();
				user1.setLockStatus(res.getInt("lock_status"));
				user1.setAccountId(res.getInt("Account_Id"));
				login.add(user1);
				status = user1.getLockStatus();
				accountId = user1.getAccountId();
			
			}
			if(login.isEmpty())
			{
				throw new LoginException("Invalid UserIdPassWord");	

			}
			
			if(status == 1)
			{
				throw new LoginException("Account is locked Please contact Admin");
			}
			
			
						
		} 
		catch (SQLException e)
		{
			throw new LoginException("Please contact bank admin "  +e);
		}
		finally
		{
			if(con != null && pstm != null && res != null)
			{
				try
				{
					con.close();
					pstm.close();
					res.close();
				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			
		}
		return accountId;
				
	}

	@Override
	public void update(int lock) {
		
		Connection con = dbUtil.getConnection();
		PreparedStatement pstm = null;
		String queryTwo = "update lockstatus = 1 where userId = ?";
		try 
		{
			pstm = con.prepareStatement(queryTwo);
			pstm.setInt(1, lock);
			pstm.executeUpdate();
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("unable to update lock status " +e);
		}
		
		
	}

}

