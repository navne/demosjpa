package core.cg.ois.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import core.cg.ois.beans.AccountMaster;
import core.cg.ois.beans.Customer;
import core.cg.ois.beans.PayeeTable;
import core.cg.ois.beans.ServiceTracker;
import core.cg.ois.beans.Transaction;
import core.cg.ois.beans.UserTable;
import core.cg.ois.exception.BankingException;
import core.cg.ois.util.dbUtil;

public class ObsDaoImpl implements IObsDao {
	private Connection connection = null;
	private PreparedStatement pstm = null;
	private ResultSet res = null;





	

	public int loginProcess(UserTable user) throws BankingException {
		String status= null;
		int accountId = 0;


		 connection = dbUtil.getConnection();
	     pstm = null;

	



		String Query = "SELECT LOCK_STATUS , Account_Id  FROM USER_TABLE where USER_ID = ? AND login_PASSWORD = ? ";
		
		ResultSet res = null;
		try
		{
			pstm = connection.prepareStatement(Query);
			pstm.setInt(1, user.getUserId());
			pstm.setString(2, user.getPassword());

			res = pstm.executeQuery();

			while(res.next())
			{
				status = res.getString("Lock_status");
				accountId = res.getInt("Account_id");


			}
			if(accountId == 0)			
			{
						
				throw new BankingException("Invalid UserIdPassWord");	

			}

			if(status.equals("3"))
			{
				throw new BankingException("Account is locked Please contact Admin");
			}



		} 
		catch (SQLException e)
		{
			throw new BankingException("Please contact bank admin " );
		}
		finally
		{
			if(connection != null && pstm != null && res != null)
			{
				try
				{
					connection.close();
					pstm.close();
					res.close();
				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}
		return accountId;

	}

	@Override
	public void update(int lock) {

		Connection con = dbUtil.getConnection();
		PreparedStatement pstm = null;
		String queryTwo = "update lockstatus = ? where userId = ?";
		try 
		{
			pstm = con.prepareStatement(queryTwo);
			pstm.setInt(1, lock);
			pstm.executeUpdate();
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("unable to update lock status " );
		}
		if(con != null && pstm != null)
		{
			try
			{
				con.close();
				pstm.close();
			
			}
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}


	}

	@Override
	public AccountMaster getAccount(int accountId) throws BankingException {
		 connection = dbUtil.getConnection();
		AccountMaster master= new AccountMaster();
		String QueryThree = "Select * from Accountmaster where account_id=?";
		try 
		{
			pstm = connection.prepareStatement(QueryThree);
			System.out.println(accountId);
			pstm.setInt(1, accountId);
		    res = pstm.executeQuery();

			while (res.next()) 
			{
				master.setAccountId(res.getInt(1));
				master.setAccountBalance(res.getDouble(3));
				master.setAccountType(res.getString(2));
				master.setOpenDate(res.getDate(4));


			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			throw new BankingException("Something went Wrong");

		}
		finally
		{
			if(connection != null && pstm != null && res != null )
			{
				try
				{
					connection.close();
					pstm.close();

				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
			}	


		}
		return master;
	}

	@Override
	public String securityQues(int userId) throws BankingException {
		connection        = dbUtil.getConnection();
		String ques = null;
		String Query = "SELECT secret_question FROM USER_TABLE where user_id=?";
		
		try
		{
			pstm = connection.prepareStatement(Query);
			pstm.setInt(1,userId);
            res = pstm.executeQuery();

			while(res.next())
			{
				ques = res.getString("secret_question");


			}
			if(ques == null)
			{
				throw new BankingException("Invalid UserId");	

			}


		} 
		catch (SQLException e)
		{
			throw new BankingException("Please contact bank admin " );
		}
		finally
		{
			if(connection != null && pstm != null && res != null)
			{
				try
				{
					connection.close();
					pstm.close();
					res.close();
				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}
		return ques;

	}

	@Override
	public int confirmQues(String ques, String transPass) throws BankingException {
		int accountId = 0;
		connection = dbUtil.getConnection();
		




		String Query = "SELECT  Account_Id  FROM USER_TABLE where transaction_password = ? and secret_question = ?";
		ResultSet res = null;
		try
		{
			pstm = connection.prepareStatement(Query);

			pstm.setString(1, transPass);
			pstm.setString(2, ques);

			res = pstm.executeQuery();

			while(res.next())
			{

				accountId = res.getInt("Account_id");


			}
			if(accountId == 0)
			{
				throw new BankingException("Invalid Security Ques");	

			}




		} 
		catch (SQLException e)
		{
			throw new BankingException("Please contact bank admin "  );
		}
		finally
		{
			if(connection != null && pstm != null && res != null)
			{
				try
				{
					connection.close();
					pstm.close();
					res.close();
				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}
		return accountId;

	}

	@Override
	public void passwordChange(int userId, String pas) throws BankingException {
		connection = dbUtil.getConnection();
		PreparedStatement pstm = null;

		String queryFour = "update user_table set login_password=? where user_id = ?";
		try 
		{
			pstm = connection.prepareStatement(queryFour);
			pstm.setString(1, pas);
			pstm.setInt(2, userId);

			pstm.executeUpdate();
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new BankingException("unable to change password" );
		}
		finally
		{
			if(connection != null && pstm != null )
			{
				try
				{
					connection.close();
					pstm.close();

				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}

	}

	@Override
	public List<Transaction> getAllTransaction(int accId) throws BankingException {
		List<Transaction> mTransactions = new ArrayList<Transaction>();
		connection = dbUtil.getConnection();
		Transaction trans = null;

		try 
		{
			String queryFive =  "select * from transaction where account_no = ?";
			pstm = connection.prepareStatement(queryFive);
			pstm.setInt(1, accId);
			ResultSet res = pstm.executeQuery();
			while(res.next())
			{
				trans = new Transaction();
				trans.setTransactionId(res.getInt(1));
				trans.setTransactionDesc(res.getString(2));
				trans.setDateOfTransaction(res.getDate(3));
				trans.setTransactionType(res.getString(4));
				trans.setTranAmount((res.getDouble(5)));
				trans.setAccountNo(res.getInt(6));
				mTransactions.add(trans);

			}

			if(mTransactions.isEmpty())
			{
				throw new BankingException("NO Transaction Done" );
			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new BankingException("something went Wrong" );
		}
		finally
		{
			if(connection != null && pstm != null )
			{
				try
				{
					connection.close();
					pstm.close();

				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}

		return mTransactions;
	}

	@Override
	public Customer getPersonalDetails(int accId) throws BankingException {

		connection = dbUtil.getConnection();
		Customer cust = null;
		List<Customer> mCust = new ArrayList<Customer>();

		try 
		{
			String queryFive =  "select * from customer where account_id = ?";
			pstm = connection.prepareStatement(queryFive);
			pstm.setInt(1, accId);
			 res = pstm.executeQuery();
			while(res.next())
			{
				cust = new Customer();
				cust.setAccountId(res.getInt(1));
				cust.setCustomerName(res.getString(2));
				cust.setEmail(res.getString(3));
				cust.setAddress(res.getString(4));
				cust.setPanCard(res.getString(5));
				mCust.add(cust);


			}

			if(mCust.isEmpty())
			{
				throw new BankingException("NO Details Found" );
			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new BankingException("something went Wrong" );
		}
		finally
		{
			if(connection != null && pstm != null )
			{
				try
				{
					connection.close();
					pstm.close();

				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}
		return cust;

	}

	@Override
	public void updateCustomer(Customer cust) throws BankingException {
		connection = dbUtil.getConnection();
	

		String querySix = "Update customer set customer_name = ?,email = ?,address = ? ,pancard= ? where account_id = ?";
		try 
		{
			pstm = connection.prepareStatement(querySix);
			pstm.setString(1, cust.getCustomerName());
			pstm.setString(2, cust.getEmail());
			pstm.setString(3, cust.getAddress());
			pstm.setString(4, cust.getPanCard());
			pstm.setInt(5, cust.getAccountId());
			pstm.executeUpdate();
		} 
		catch (SQLException e) {
			e.printStackTrace();
			throw new BankingException("error in updation" );

		}


		finally
		{
			if(connection != null && pstm != null )
			{
				try
				{
					connection.close();
					pstm.close();

				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}

	}

	@Override
	public int requestCheckBook(int accId , String desc) throws BankingException {
		int serviceId = 0;
		connection = dbUtil.getConnection();
		

		String querySeven = "Insert into servicetracker values(serv_seq.nextval,?,?,sysdate,'pending')";
		try {
			pstm = connection.prepareStatement(querySeven);
			pstm.setString(1, desc);
			pstm.setInt(2, accId);
			pstm.executeUpdate();

			String queryEight = "select serv_seq.currval from dual";
			PreparedStatement pstm1 = connection.prepareStatement(queryEight);
			ResultSet res = pstm1.executeQuery();
			while (res.next()) {
				serviceId = res.getInt(1);

			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new BankingException("unable to update request " );


		}
		finally
		{
			if(connection != null && pstm != null )
			{
				try
				{
					connection.close();
					pstm.close();

				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}
		return serviceId;

	}

	@Override
	public List<ServiceTracker> trackRequest(int accId) throws BankingException {
		connection = dbUtil.getConnection();
	
		List<ServiceTracker> mService = new ArrayList<ServiceTracker>();
		ServiceTracker service = null;

		try {
			String querynine = "select * from servicetracker where account_id =?";
			pstm = connection.prepareStatement(querynine);
			pstm.setInt(1, accId);
	        res = pstm.executeQuery();
			while(res.next())
			{
				service = new ServiceTracker();
				service.setServiceId(res.getInt(1));
				service.setServiceDescripton(res.getString(2));
				service.setAccountId(res.getInt(3));
				service.setServiceRaisedDate(res.getDate(4));
				service.setServiceStatus(res.getString(5));

				System.out.println("in res " +service);
				mService.add(service);
			}
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(connection != null && pstm != null )
			{
				try
				{
					connection.close();
					pstm.close();

				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}
		System.out.println(mService);
		return mService;

	}

	@Override
	public Customer getCustomerName(int accounId) throws BankingException {
		connection = dbUtil.getConnection();

		Customer cust = null;

		String query = "Select * From customer  where Account_Id = ?";
		try {
			pstm = connection.prepareStatement(query);
			pstm.setInt(1, accounId);

			res = pstm.executeQuery();
			while (res.next())
			{
				cust = new Customer();
				cust.setAccountId(res.getInt(1));
				cust.setCustomerName(res.getString(2));
				cust.setEmail(res.getString(3));
				cust.setAddress(res.getString(4));
				cust.setPanCard(res.getString(5));

			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new BankingException("Please try again after sometime ...." );
		}
		finally
		{
			if(res!= null && connection != null && pstm != null )
			{
				try
				{
					connection.close();
					pstm.close();
					res.close();

				}
				catch (SQLException e)
				{
					e.printStackTrace();
					throw new BankingException("somethin");
				}

			}

		}
		return cust;



	}

	@Override
	public List<PayeeTable> getPayeeList(int accId)
			throws BankingException {
		 connection = dbUtil.getConnection();
		
		
		List<PayeeTable> ownPayeeList = new ArrayList<PayeeTable>();

		String query = "Select * from payeetable where Account_id = ?";
		try {
			pstm = connection.prepareStatement(query);
			pstm.setInt(1, accId);;

			 res = pstm.executeQuery();
			while (res.next())
			{
				PayeeTable payee = new PayeeTable();
				payee.setAccountId(res.getInt(1));
				payee.setPayeeAccountId(res.getInt(2));
				payee.setNickname(res.getString(3));
				ownPayeeList.add(payee);
			}


		} catch (SQLException e) {
			e.printStackTrace();
			throw new BankingException("Please try again after sometime ...." );
		}
		finally
		{
			if(res != null && connection != null && pstm != null )
			{
				try
				{
					connection.close();
					pstm.close();
					res.close();

				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}
		return ownPayeeList;

	}

	@Override
	public void addPayee(PayeeTable payee) throws BankingException {
	
		
		try {
			
			connection=dbUtil.getConnection();	
			pstm=connection.prepareStatement("insert into payeeTable values(?,?,?)");
			pstm.setInt(1, payee.getAccountId());
			pstm.setInt(2, payee.getPayeeAccountId());
			pstm.setString(3, payee.getNickname());
			pstm.executeQuery();
			connection.close();
		}
		catch (SQLException e)
		{
			throw new BankingException("Failed to add!!! Contact Bank !");
		}
		finally
		{
			if(res != null && connection != null && pstm != null )
			{
				try
				{
					connection.close();
					pstm.close();
					res.close();

				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}
	}





	@Override
	public List<AccountMaster> checkPayeeId(int payeeId) throws BankingException {
		connection = dbUtil.getConnection();
		
		List<AccountMaster>  accMaster = new ArrayList<AccountMaster>();
		

		try {
			String query = "select * from accountmaster where account_id =?";
			pstm = connection.prepareStatement(query);
			pstm.setInt(1, payeeId);
			 res = pstm.executeQuery();

			while(res.next())
			{
				AccountMaster account = new AccountMaster();
				account.setAccountId(res.getInt(1));
				account.setAccountType(res.getString(2));
				account.setAccountBalance(res.getDouble(3));
				account.setOpenDate(res.getDate(4));
				accMaster.add(account);
			}

			if(accMaster.isEmpty())
			{
				throw new BankingException("Account ID doesnot exist");
			}
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally
		{
			if(res != null && connection != null && pstm != null )
			{
				try
				{
					connection.close();
					pstm.close();
					res.close();

				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}

		return accMaster;



	}

	@Override
	public int ownFundTransfer(int accountPayer, int accountPayee, double amount) throws BankingException {
		double currentBalance=getBalance(accountPayer);
		double a=0;
		double b=0;
		int transId = 0;
		if(currentBalance < amount){

			throw new BankingException("Insufficient Balance !");
		}
		else 
		{
			a=currentBalance-amount;
			try 
			{
			
				connection=dbUtil.getConnection();	
				//connection.commit();
				connection.setAutoCommit(false);
				System.out.println(accountPayer);
				System.out.println(accountPayee);
				pstm=connection.prepareStatement("update AccountMaster set Account_Balance=? where Account_Id=?");
				pstm.setDouble(1,a);
				pstm.setInt(2, accountPayer);
				pstm.executeQuery();
				double currBalance=getBalance(accountPayee);
				b=currBalance+amount;
				pstm=connection.prepareStatement("update AccountMaster set Account_Balance=? where Account_Id=?");
				pstm.setDouble(1,b);
				pstm.setInt(2, accountPayee);
				pstm.executeQuery();
				pstm=connection.prepareStatement("insert into FundTransfer values(fundtran_seq.NEXTVAL,?,?,sysdate,?)");
				pstm.setInt(1, accountPayer);
				pstm.setInt(2, accountPayee);
				pstm.setDouble(3, amount);
				pstm.execute();
				pstm=connection.prepareStatement("insert into transaction values(tran_seq.NEXTVAL,'debit',sysdate,'Fund Transfer',?,?)");
				pstm.setDouble(1, amount);
				pstm.setInt(2, accountPayer);
				pstm.executeQuery();
				pstm=connection.prepareStatement("insert into transaction values(tran_seq.NEXTVAL,'credit',sysdate,'Fund Transfer',?,?)");
				pstm.setDouble(1, amount);
				pstm.setInt(2, accountPayee);
				pstm.executeQuery();
				pstm = connection.prepareStatement("select tran_seq.currval from dual");
				ResultSet res = pstm.executeQuery();
				connection.commit();


				while(res.next())
				{
					transId = res.getInt(1);

				}

			} catch (SQLException e) {

				e.printStackTrace();
				try {
					connection.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					throw new BankingException("Failed transfer !");
				}
				throw new BankingException("Failed transfer !");
			}
			finally
			{
				if(res != null && connection != null && pstm != null )
				{
					try
					{
						connection.close();
						pstm.close();
						res.close();

					}
					catch (SQLException e)
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}

			}
		}
		return transId;




	}





	public double getBalance(int accountId) throws BankingException{
		System.out.println("ds" +accountId);

		Connection connection = null;
		res=null;
		PreparedStatement pstm=null;
		double amount;
		try {
			
			connection=dbUtil.getConnection();	
			amount = 0;


			pstm=connection.prepareStatement("select Account_Balance from AccountMaster where Account_ID=?");
			pstm.setInt(1,accountId);
			res=pstm.executeQuery();
			if(res.next()){
				amount=res.getDouble("Account_Balance");
			}
		} catch (SQLException e) {
			throw new BankingException("Unavailable to retrieve balances");
		}

		finally
		{
			try 
			{
				connection.close();
				pstm.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return amount;
	}
	
	
	@Override
	public boolean register(UserTable user) throws BankingException {
	

		int status;
		try {

			connection=dbUtil.getConnection();		
			pstm=connection.prepareStatement("select * from AccountMaster where Account_Id=?");
			pstm.setInt(1, user.getAccountId());
			res=pstm.executeQuery();
			if(res==null)
			{
				throw new BankingException("You are not authorize to register... Contact Bank");
			}
			pstm=connection.prepareStatement("Insert into User_Table values(?,?,?,?,?,?)");
			pstm.setInt(1, user.getAccountId());
			pstm.setInt(2, user.getUserId());
			pstm.setString(3, user.getPassword());
			pstm.setString(4, user.getSecretQuestion());
			pstm.setString(5, user.getTransactionPassword());
			pstm.setString(6, user.getLockStatus());
			status = pstm.executeUpdate();
			
		}
		catch (SQLException e)
		{
//			myLog.info("Problem in database");
			throw new BankingException("Unable to process request...Please contact bank.");
		}
		
		finally
		{
			if(connection != null && pstm != null && res != null)
			
			try
			{
				connection.close();
				pstm.close();
				res.close();
			}
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if(status==1)
		{
			return true;
		}
		
	



		return false;
	}









}



