package core.cg.ois.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;










import core.cg.ois.beans.AccountMaster;
import core.cg.ois.beans.Customer;
import core.cg.ois.beans.PayeeTable;
import core.cg.ois.beans.ServiceTracker;
import core.cg.ois.beans.Transaction;
import core.cg.ois.beans.UserTable;
import core.cg.ois.exception.LoginException;
import core.cg.ois.util.dbUtil;

public class ObsDaoImpl implements IObsDao {
	



	@Override
	public boolean register(UserTable user) throws LoginException {
		Connection connection;

		int status;
		try {

			connection=dbUtil.getConnection();		
			PreparedStatement ps1=connection.prepareStatement("select * from AccountMaster where Account_Id=?");
			ps1.setInt(1, user.getAccountId());
			ResultSet rs=ps1.executeQuery();
			if(rs==null)
				throw new LoginException("You are not authorize to register... Contact Bank");
			PreparedStatement ps=connection.prepareStatement("Insert into User_Table values(?,?,?,?,?,?)");
			ps.setInt(1, user.getAccountId());
			ps.setInt(2, user.getUserId());
			ps.setString(3, user.getPassword());
			ps.setString(4, user.getSecretQuestion());
			ps.setString(5, user.getTransactionPassword());
			ps.setString(6, user.getLockStatus());
			status = ps.executeUpdate();
			connection.close();
		} catch (SQLException e) {
//			myLog.info("Problem in database");
			throw new LoginException("Unable to process request...Please contact bank.");
		}
		
		if(status==1)
		{
			return true;
		}
		
	



		return false;
	}


	public int loginProcess(UserTable user) throws LoginException {
		String status= null;
		int accountId = 0;


		Connection con         = dbUtil.getConnection();
		PreparedStatement pstm = null;

	



		String Query = "SELECT LOCK_STATUS , Account_Id  FROM USER_TABLE where USER_ID = ? AND login_PASSWORD = ? ";
		String QueryTwo = "Update table User_table set lock_status = ? where user_id= ?";
		ResultSet res = null;
		try
		{
			pstm = con.prepareStatement(Query);
			pstm.setInt(1, user.getUserId());
			pstm.setString(2, user.getPassword());

			res = pstm.executeQuery();

			while(res.next())
			{
				status = res.getString("Lock_status");
				accountId = res.getInt("Account_id");


			}
			if(accountId == 0)			{
				
				throw new LoginException("Invalid UserIdPassWord");	

			}

			if(status.equals("3"))
			{
				throw new LoginException("Account is locked Please contact Admin");
			}



		} 
		catch (SQLException e)
		{
			throw new LoginException("Please contact bank admin " );
		}
		finally
		{
			if(con != null && pstm != null && res != null)
			{
				try
				{
					con.close();
					pstm.close();
					res.close();
				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}
		return accountId;

	}

	@Override
	public void update(int lock) {

		Connection con = dbUtil.getConnection();
		PreparedStatement pstm = null;
		String queryTwo = "update lockstatus = 1 where userId = ?";
		try 
		{
			pstm = con.prepareStatement(queryTwo);
			pstm.setInt(1, lock);
			pstm.executeUpdate();
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("unable to update lock status " );
		}


	}

	@Override
	public AccountMaster getAccount(int accountId) throws LoginException {
		Connection con = dbUtil.getConnection();
		PreparedStatement pstm = null;
		AccountMaster master= new AccountMaster();
		String QueryThree = "Select * from Accountmaster where account_id=?";
		try 
		{
			pstm = con.prepareStatement(QueryThree);
			System.out.println(accountId);
			pstm.setInt(1, accountId);
			ResultSet resOne = pstm.executeQuery();

			while (resOne.next()) 
			{
				master.setAccountId(resOne.getInt(1));
				master.setAccountBalance(resOne.getDouble(3));
				master.setAccountType(resOne.getString(2));
				master.setOpenDate(resOne.getDate(4));


			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			throw new LoginException("Something went Wrong");

		}
		finally
		{
			if(con != null && pstm != null )
			{
				try
				{
					con.close();
					pstm.close();

				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
			}	


		}
		return master;
	}

	@Override
	public String securityQues(int userId) throws LoginException {
		Connection con         = dbUtil.getConnection();
		PreparedStatement pstm = null;
		String ques = null;


		String Query = "SELECT secret_question FROM USER_TABLE where user_id=?";
		ResultSet res = null;
		try
		{
			pstm = con.prepareStatement(Query);
			pstm.setInt(1,userId);


			res = pstm.executeQuery();

			while(res.next())
			{
				ques = res.getString("secret_question");


			}
			if(ques == null)
			{
				throw new LoginException("Invalid UserId");	

			}


		} 
		catch (SQLException e)
		{
			throw new LoginException("Please contact bank admin " );
		}
		finally
		{
			if(con != null && pstm != null && res != null)
			{
				try
				{
					con.close();
					pstm.close();
					res.close();
				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}
		return ques;

	}

	@Override
	public int confirmQues(String ques, String transPass) throws LoginException {
		int accountId = 0;
		Connection con         = dbUtil.getConnection();
		PreparedStatement pstm = null;




		String Query = "SELECT  Account_Id  FROM USER_TABLE where transaction_password = ? and secret_question = ?";
		ResultSet res = null;
		try
		{
			pstm = con.prepareStatement(Query);

			pstm.setString(1, transPass);
			pstm.setString(2, ques);

			res = pstm.executeQuery();

			while(res.next())
			{

				accountId = res.getInt("Account_id");


			}
			if(accountId == 0)
			{
				throw new LoginException("Invalid Security Ques");	

			}




		} 
		catch (SQLException e)
		{
			throw new LoginException("Please contact bank admin "  );
		}
		finally
		{
			if(con != null && pstm != null && res != null)
			{
				try
				{
					con.close();
					pstm.close();
					res.close();
				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}
		return accountId;

	}

	@Override
	public void passwordChange(int userId, String pas) throws LoginException {
		Connection con = dbUtil.getConnection();
		PreparedStatement pstm = null;

		String queryFour = "update user_table set login_password=? where user_id = ?";
		try 
		{
			pstm = con.prepareStatement(queryFour);
			pstm.setString(1, pas);
			pstm.setInt(2, userId);

			pstm.executeUpdate();
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new LoginException("unable to change password" );
		}
		finally
		{
			if(con != null && pstm != null )
			{
				try
				{
					con.close();
					pstm.close();

				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}

	}

	@Override
	public List<Transaction> getAllTransaction(int accId) throws LoginException {
		List<Transaction> mTransactions = new ArrayList<Transaction>();
		Connection con = dbUtil.getConnection();
		Transaction trans = null;


		PreparedStatement pstm = null;
		try 
		{
			String queryFive =  "select * from transaction where account_no = ?";
			pstm = con.prepareStatement(queryFive);
			pstm.setInt(1, accId);
			ResultSet res = pstm.executeQuery();
			while(res.next())
			{
				trans = new Transaction();
				trans.setTransactionId(res.getInt(1));
				trans.setTransactionDesc(res.getString(2));
				trans.setDateOfTransaction(res.getDate(3));
				trans.setTransactionType(res.getString(4));
				trans.setTranAmount((res.getDouble(5)));
				trans.setAccountNo(res.getInt(6));
				mTransactions.add(trans);

			}

			if(mTransactions.isEmpty())
			{
				throw new LoginException("NO Transaction Done" );
			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new LoginException("something went Wrong" );
		}
		finally
		{
			if(con != null && pstm != null )
			{
				try
				{
					con.close();
					pstm.close();

				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}

		return mTransactions;
	}

	@Override
	public Customer getPersonalDetails(int accId) throws LoginException {

		Connection con = dbUtil.getConnection();
		Customer cust = null;
		List<Customer> mCust = new ArrayList<Customer>();


		PreparedStatement pstm = null;
		try 
		{
			String queryFive =  "select * from customer where account_id = ?";
			pstm = con.prepareStatement(queryFive);
			pstm.setInt(1, accId);
			ResultSet res = pstm.executeQuery();
			while(res.next())
			{
				cust = new Customer();
				cust.setAccountId(res.getInt(1));
				cust.setCustomerName(res.getString(2));
				cust.setEmail(res.getString(3));
				cust.setAddress(res.getString(4));
				cust.setPanCard(res.getString(5));
				mCust.add(cust);


			}

			if(mCust.isEmpty())
			{
				throw new LoginException("NO Details Found" );
			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new LoginException("something went Wrong" );
		}
		finally
		{
			if(con != null && pstm != null )
			{
				try
				{
					con.close();
					pstm.close();

				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}
		return cust;

	}

	@Override
	public void updateCustomer(Customer cust) throws LoginException {
		Connection con = dbUtil.getConnection();
		PreparedStatement pstm = null;

		String querySix = "Update customer set customer_name = ?,email = ?,address = ? ,pancard= ? where account_id = ?";
		try 
		{
			pstm = con.prepareStatement(querySix);
			pstm.setString(1, cust.getCustomerName());
			pstm.setString(2, cust.getEmail());
			pstm.setString(3, cust.getAddress());
			pstm.setString(4, cust.getPanCard());
			pstm.setInt(5, cust.getAccountId());
			pstm.executeUpdate();
		} 
		catch (SQLException e) {
			e.printStackTrace();
			throw new LoginException("error in updation" );

		}


		finally
		{
			if(con != null && pstm != null )
			{
				try
				{
					con.close();
					pstm.close();

				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}

	}

	@Override
	public int requestCheckBook(int accId , String desc) throws LoginException {
		int serviceId = 0;
		Connection con = dbUtil.getConnection();
		PreparedStatement pstm = null;

		String querySeven = "Insert into servicetracker values(serv_seq.nextval,?,?,sysdate,'pending')";
		try {
			pstm = con.prepareStatement(querySeven);
			pstm.setString(1, desc);
			pstm.setInt(2, accId);
			pstm.executeUpdate();

			String queryEight = "select serv_seq.currval from dual";
			PreparedStatement pstm1 = con.prepareStatement(queryEight);
			ResultSet res = pstm1.executeQuery();
			while (res.next()) {
				serviceId = res.getInt(1);

			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new LoginException("unable to update request " );


		}
		finally
		{
			if(con != null && pstm != null )
			{
				try
				{
					con.close();
					pstm.close();

				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}
		return serviceId;

	}

	@Override
	public List<ServiceTracker> trackRequest(int accId) throws LoginException {
		Connection con = dbUtil.getConnection();
		PreparedStatement pstm = null;
		List<ServiceTracker> mService = new ArrayList<ServiceTracker>();
		ServiceTracker service = null;

		try {
			String querynine = "select * from servicetracker where account_id =?";
			pstm = con.prepareStatement(querynine);
			pstm.setInt(1, accId);
			ResultSet res = pstm.executeQuery();
			while(res.next())
			{
				service = new ServiceTracker();
				service.setServiceId(res.getInt(1));
				service.setServiceDescripton(res.getString(2));
				service.setAccountId(res.getInt(3));
				service.setServiceRaisedDate(res.getDate(4));
				service.setServiceStatus(res.getString(5));

				System.out.println("in res " +service);
				mService.add(service);
			}
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(con != null && pstm != null )
			{
				try
				{
					con.close();
					pstm.close();

				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}
		System.out.println(mService);
		return mService;

	}

	@Override
	public Customer getCustomerName(int accounId) throws LoginException {
		Connection con = dbUtil.getConnection();
		PreparedStatement pstm = null;

		Customer cust = null;

		String query = "Select * From customer  where Account_Id = ?";
		try {
			pstm = con.prepareStatement(query);
			pstm.setInt(1, accounId);

			ResultSet res = pstm.executeQuery();
			while (res.next())
			{
				cust = new Customer();
				cust.setAccountId(res.getInt(1));
				cust.setCustomerName(res.getString(2));
				cust.setEmail(res.getString(3));
				cust.setAddress(res.getString(4));
				cust.setPanCard(res.getString(5));

			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new LoginException("Please try again after sometime ...." );
		}
		finally
		{
			if(con != null && pstm != null )
			{
				try
				{
					con.close();
					pstm.close();

				}
				catch (SQLException e)
				{
					e.printStackTrace();
					throw new LoginException("somethin");
				}

			}

		}
		return cust;



	}

	@Override
	public List<PayeeTable> getPayeeList(int accId)
			throws LoginException {
		Connection con = dbUtil.getConnection();
		PreparedStatement pstm = null;
		
		List<PayeeTable> ownPayeeList = new ArrayList<PayeeTable>();

		String query = "Select * from payeetable where Account_id = ?";
		try {
			pstm = con.prepareStatement(query);
			pstm.setInt(1, accId);;

			ResultSet res = pstm.executeQuery();
			while (res.next())
			{
				PayeeTable payee = new PayeeTable();
				payee.setAccountId(res.getInt(1));
				payee.setPayeeAccountId(res.getInt(2));
				payee.setNickname(res.getString(3));
				ownPayeeList.add(payee);
			}


		} catch (SQLException e) {
			e.printStackTrace();
			throw new LoginException("Please try again after sometime ...." );
		}
		finally
		{
			if(con != null && pstm != null )
			{
				try
				{
					con.close();
					pstm.close();

				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}
		return ownPayeeList;

	}

	@Override
	public void addPayee(PayeeTable payee) throws LoginException {
		Connection connection;
		PreparedStatement ps;
		
		try {
			
			connection=dbUtil.getConnection();	
			ps=connection.prepareStatement("insert into payeeTable values(?,?,?)");
			ps.setInt(1, payee.getAccountId());
			ps.setInt(2, payee.getPayeeAccountId());
			ps.setString(3, payee.getNickname());
			ps.executeQuery();
			connection.close();
		} catch (SQLException e) {
			throw new LoginException("Failed to add!!! Contact Bank !");
		}
	}





	@Override
	public List<AccountMaster> checkPayeeId(int payeeId) throws LoginException {
		Connection con = dbUtil.getConnection();
		PreparedStatement pstm = null;
		List<AccountMaster>  accMaster = new ArrayList<AccountMaster>();
		

		try {
			String query = "select * from accountmaster where account_id =?";
			pstm = con.prepareStatement(query);
			pstm.setInt(1, payeeId);
			ResultSet res = pstm.executeQuery();

			while(res.next())
			{
				AccountMaster account = new AccountMaster();
				account.setAccountId(res.getInt(1));
				account.setAccountType(res.getString(2));
				account.setAccountBalance(res.getDouble(3));
				account.setOpenDate(res.getDate(4));
				accMaster.add(account);
			}

			if(accMaster.isEmpty())
			{
				throw new LoginException("Account ID doesnot exist");
			}
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return accMaster;



	}

	@Override
	public int ownFundTransfer(int accountPayer, int accountPayee, double amount) throws LoginException {
		Connection connection = null;
		
		PreparedStatement ps=null;
		double currentBalance=getBalance(accountPayer);
		double a=0;
		double b=0;
		int transId = 0;
		if(currentBalance < amount){

			throw new LoginException("Insufficient Balance !");
		}
		else 
		{
			a=currentBalance-amount;
			try 
			{
			
				connection=dbUtil.getConnection();	
				//connection.commit();
				connection.setAutoCommit(false);
				System.out.println(accountPayer);
				System.out.println(accountPayee);
				ps=connection.prepareStatement("update AccountMaster set Account_Balance=? where Account_Id=?");
				ps.setDouble(1,a);
				ps.setInt(2, accountPayer);
				ps.executeQuery();
				double currBalance=getBalance(accountPayee);
				b=currBalance+amount;
				ps=connection.prepareStatement("update AccountMaster set Account_Balance=? where Account_Id=?");
				ps.setDouble(1,b);
				ps.setInt(2, accountPayee);
				ps.executeQuery();
				ps=connection.prepareStatement("insert into FundTransfer values(fundtran_seq.NEXTVAL,?,?,sysdate,?)");
				ps.setInt(1, accountPayer);
				ps.setInt(2, accountPayee);
				ps.setDouble(3, amount);
				ps.execute();
				ps=connection.prepareStatement("insert into transaction values(tran_seq.NEXTVAL,'debit',sysdate,'Fund Transfer',?,?)");
				ps.setDouble(1, amount);
				ps.setInt(2, accountPayer);
				ps.executeQuery();
				ps=connection.prepareStatement("insert into transaction values(tran_seq.NEXTVAL,'credit',sysdate,'Fund Transfer',?,?)");
				ps.setDouble(1, amount);
				ps.setInt(2, accountPayee);
				ps.executeQuery();
				ps = connection.prepareStatement("select tran_seq.currval from dual");
				ResultSet res = ps.executeQuery();
				connection.commit();


				while(res.next())
				{
					transId = res.getInt(1);

				}

			} catch (SQLException e) {

				e.printStackTrace();
				try {
					connection.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					throw new LoginException("Failed transfer !");
				}
				throw new LoginException("Failed transfer !");
			}
			finally{
				try {
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return transId;




	}





	public double getBalance(int accountId) throws LoginException{
		System.out.println("ds" +accountId);

		Connection connection = null;
		ResultSet rs=null;
		PreparedStatement ps=null;
		double amount;
		try {
			
			connection=dbUtil.getConnection();	
			amount = 0;


			ps=connection.prepareStatement("select Account_Balance from AccountMaster where Account_ID=?");
			ps.setInt(1,accountId);
			rs=ps.executeQuery();
			if(rs.next()){
				amount=rs.getDouble("Account_Balance");
			}
		} catch (SQLException e) {
			throw new LoginException("Unavailable to retrieve balances");
		}

		finally
		{
			try 
			{
				connection.close();
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return amount;
	}








}



