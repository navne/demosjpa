package core.cg.ois.dao;

import java.util.List;

import core.cg.ois.beans.AccountMaster;
import core.cg.ois.beans.Customer;
import core.cg.ois.beans.PayeeTable;
import core.cg.ois.beans.ServiceTracker;
import core.cg.ois.beans.Transaction;
import core.cg.ois.beans.UserTable;
import core.cg.ois.exception.BankingException;

public interface IObsDao
{
	public int loginProcess(UserTable user) throws BankingException;
	public void update(int lock);
	public AccountMaster getAccount(int accountId) throws BankingException;
	public String securityQues(int userId) throws BankingException;
	public int confirmQues(String ques , String transPass  ) throws BankingException;
	public void passwordChange(int userId, String pas) throws BankingException;
	public List<Transaction> getAllTransaction(int accId) throws BankingException; 
	public Customer getPersonalDetails(int accId) throws BankingException;
	public void updateCustomer(Customer cust) throws BankingException;
	public int requestCheckBook(int accId, String desc) throws BankingException;
	public List<ServiceTracker> trackRequest(int accId) throws BankingException;
	public Customer getCustomerName(int accounId) throws BankingException;
	public List<PayeeTable> getPayeeList(int accId) throws BankingException;
	public void addPayee(PayeeTable payee) throws BankingException;
	public List<AccountMaster>  checkPayeeId(int payeeId) throws BankingException; 
	public int ownFundTransfer(int accountPayer,int accountPayee, double amount) throws BankingException;
	boolean register(UserTable user) throws BankingException;
 
    
	
}
