package core.cg.ois.dao;

import java.util.List;

import core.cg.ois.beans.AccountMaster;
import core.cg.ois.beans.Customer;
import core.cg.ois.beans.PayeeTable;
import core.cg.ois.beans.ServiceTracker;
import core.cg.ois.beans.Transaction;
import core.cg.ois.beans.UserTable;
import core.cg.ois.exception.LoginException;

public interface IObsDao
{
	public int loginProcess(UserTable user) throws LoginException;
	public void update(int lock);
	public AccountMaster getAccount(int accountId) throws LoginException;
	public String securityQues(int userId) throws LoginException;
	public int confirmQues(String ques , String transPass  ) throws LoginException;
	public void passwordChange(int userId, String pas) throws LoginException;
	public List<Transaction> getAllTransaction(int accId) throws LoginException; 
	public Customer getPersonalDetails(int accId) throws LoginException;
	public void updateCustomer(Customer cust) throws LoginException;
	public int requestCheckBook(int accId, String desc) throws LoginException;
	public List<ServiceTracker> trackRequest(int accId) throws LoginException;
	public Customer getCustomerName(int accounId) throws LoginException;
	public List<PayeeTable> getPayeeList(int accId) throws LoginException;
	public void addPayee(PayeeTable payee) throws LoginException;
	public List<AccountMaster>  checkPayeeId(int payeeId) throws LoginException; 
	public int ownFundTransfer(int accountPayer,int accountPayee, double amount) throws LoginException;
	boolean register(UserTable user) throws LoginException;
 
    
	
}
