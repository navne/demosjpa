package core.cg.ois.dao;

import com.cg.ois.exception.LoginException;

import core.cg.ois.beans.UserTable;

public interface IObsDao
{
	public int loginProcess(UserTable user) throws LoginException;
	public void update(int lock);

}
