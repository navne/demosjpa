package com.cg.ois.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.jboss.security.auth.spi.Users.User;

import com.cg.ois.exception.LoginException;

import core.cg.ois.beans.UserTable;
import core.cg.ois.service.IObsService;
import core.cg.ois.service.ObsServiceImpl;


@WebServlet("*.do")
public class BankController extends HttpServlet {
	UserTable user = null;
	IObsService service = null;
	
	@Override
	public void init() throws ServletException {
		user = new  UserTable();
		service = new ObsServiceImpl();
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		String action = request.getServletPath();
		String actionPage = null;
		
		switch (action) {
		case "/UserLogin.do":
			int count = 0;
			HttpSession session = request.getSession();
			int userId = Integer.parseInt(request.getParameter("userId"));
			String pass = request.getParameter("pass");
			user.setUserId(userId);
			user.setPassword(pass);
			
			try
			{
				int accountId = service.loginProcess(user);
				System.out.println(accountId);
				
				actionPage = "Home.jsp";
			} 
			catch (LoginException e) 
			{		
				count++;
				e.printStackTrace();
				session.setAttribute("invalid attempt", count);
				actionPage = "ClientLogin.jsp";
			}
			if(count > 3 )
			{		
				service.update(userId);
			}
			
			break;

		default:
			actionPage = "index.jsp";
			break;
			
		
			
		}
		RequestDispatcher rd = request.getRequestDispatcher(actionPage);
		rd.forward(request	, response);
		
		
		
		
		
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
