package com.cg.ois.junit;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import core.cg.ois.beans.UserTable;
import core.cg.ois.exception.LoginException;
import core.cg.ois.service.IObsService;
import core.cg.ois.service.ObsServiceImpl;

public class TestCases {
	private ObsServiceImpl service ;
	private UserTable user ;
	
	
	@Before
	public void beforetest()
	{
		user = new UserTable();
		service = new ObsServiceImpl();
		
	}

	@Test
	public void logintest() throws LoginException {
		
		user.setUserId(9812);
		user.setPassword("edf");
		int id = service.loginProcess(user);
		assertEquals(0, id);
		
		
	}

}
