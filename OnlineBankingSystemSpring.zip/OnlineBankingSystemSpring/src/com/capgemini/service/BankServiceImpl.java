package com.capgemini.service;

import java.sql.Date;
import java.util.List;

/************************************************************************************
 * File:        BankDaoImpl.java
 * Package:     com.capgemini.service
 * Description:        Service class for Online Banking System (admin)
 * Version:     3.0
 * Author: Group5            Date:02/02/2017        
 ************************************************************************************/
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.dao.IBankDao;
import com.capgemini.entity.AccountMaster;
import com.capgemini.entity.Customer;
import com.capgemini.entity.DateForm;
import com.capgemini.entity.FundTransfer;
import com.capgemini.entity.ServiceTracker;
import com.capgemini.entity.Transaction;
import com.capgemini.exception.BankingException;

@Service
@Transactional
public class BankServiceImpl implements IBankService
{

	@Autowired
	private IBankDao daob;
	
	@Override
	public int insertAccountHolder(Customer customer) throws BankingException {
		return daob.insertAccountHolder(customer);
		
	}

	@Override
	public int insertAccount(AccountMaster account) throws BankingException {
		return daob.insertAccount(account);
		
	}


	@Override
	public int deleteAccount(int accountId) throws BankingException 
	{
		return daob.deleteAccount(accountId);
	}

	@Override
	public ServiceTracker updateTracker(int serviceId) {
		// TODO Auto-generated method stub
		return daob.updateTracker(serviceId);
	}

	@Override
	public void updateTrack(ServiceTracker track) throws BankingException {
		daob.updateTrack(track);
		
	}

	@Override
	public List<FundTransfer> trackTransaction(Date fromDate, Date toDate) throws BankingException {
		// TODO Auto-generated method stub
		return daob.trackTransaction(fromDate, toDate);
	}


	
}
