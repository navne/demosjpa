package com.capgemini.service;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import com.capgemini.entity.AccountMaster;
import com.capgemini.entity.Customer;
import com.capgemini.entity.FundTransfer;
import com.capgemini.entity.PayeeTable;
import com.capgemini.entity.ServiceTracker;
import com.capgemini.entity.Transaction;
import com.capgemini.entity.UserTable;
import com.capgemini.exception.BankingException;

/**
 * The interface for UserService.
 * @author pratbhar
 *
 */
public interface IUserService {




	/**
	 * This method is used to check the login credentials
	 * @param userId integer	
	 * @return UserTable object
	 * @throws BankingException-a user defined exception thrown if any exception occurs
	 */
	public UserTable login(int userId, String password) throws BankingException;
	/**
	 * This method is used by user to register himself
	 * @param user of type UserTable
	 * @return true/false based on if operation is successful or not
	 * @throws BankingException- a user defined exception thrown if any exception occurs
	 */
	public boolean register(UserTable user) throws BankingException;
	
	
	/**
	 * This method is used for getting the mini statement
	 * @param accountNo integer
	 * @return List of transactions
	 * @throws BankingException- a user defined exception thrown if any exception occurs
	 * 
	 */
	List<FundTransfer> getDetailsMini(int accountNo) throws BankingException;

	

	
	/**
	 * This method is used to get the view of the services
	 * @param account2 of type integer 
	 * @return ServiceTracker object containing the service used
	 * @throws BankingException-a user defined exception thrown if any exception occurs
	 */
	ServiceTracker serviceView(int account2) throws BankingException;
	
	
	/**
	 * the method is used to change user Password
	 * @param userId integer
	 * @param password String 
	 * @return 0 or 1 if change successful or not
	 * @throws BankingException-a user defined exception thrown if any exception occurs
	 */
	int changePassword(int userId, String password) throws BankingException;

	
	/**
	 * This method is used to transfer fund to different account of same bank
	 * @param accountPayer integer
	 * @param accountPayee integer
	 * @param amount double
	 * @return 
	 * @throws BankingException-a user defined exception thrown if any exception occurs
	 * @throws SQLException-to specify if the operation is successful or not
	 */
	int ownFundTransfer(int accountPayer, int accountPayee, double amount)
			throws BankingException;

	
	/**
	 * This method is used to add new payee to fund Transfer
	 * @param payee of type PayeeTable
	 * @throws BankingException-a user defined exception thrown if any exception occurs
	 */
	void addPayee(PayeeTable payee) throws BankingException;

	/**
	 * this method is used to get a userTable object for a given userId
	 * @param userId integer 
	 * @return UserTable object
	 */
	UserTable getUser(int userId);
	
	/**
	 * This method is used to get the account Balance
	 * @param accountId integer
	 * @return double balance
	 */
	public double getBalance(int accountId);
	
	/**
	 * This method is used to place service of requesting for cheque book
	 * @param service of type ServiceTracker
	 * @return 0 0r 1 integer specifying if operation is successful or not
	 * @throws BankingException-a user defined exception thrown if any exception occurs
	 */
	public int reqCheckBook(ServiceTracker service) throws BankingException;
	/**
	 * This method is used to fetch the payee list for fund transfer
	 * @param accountId integer
	 * @return List of PayeeTable objects
	 */
	public List<PayeeTable> fetchPayee(int accountId);
	String getName(int accountId);
	public List<ServiceTracker> getList(int accountId);
	Customer getCustomer(int accountId);
	void updateCust(int accountId, Customer cust);
	List<Integer> fetchPayeeOwn(int userId);
	List<FundTransfer> trackMini(Date fromDate , Date toDate, int accountId);
}
