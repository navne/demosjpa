package com.capgemini.service;

import com.capgemini.entity.AccountMaster;
import com.capgemini.entity.Customer;
import com.capgemini.entity.ServiceTracker;
import com.capgemini.exception.BankingException;

public interface IBankService 
{
	public int insertAccountHolder(Customer customer) throws BankingException;
	public int insertAccount(AccountMaster account) throws BankingException;
	
	
	int deleteAccount(int accountId) throws BankingException;
	public ServiceTracker updateTracker(int serviceId);
	public void updateTrack(ServiceTracker track) throws BankingException;
}
