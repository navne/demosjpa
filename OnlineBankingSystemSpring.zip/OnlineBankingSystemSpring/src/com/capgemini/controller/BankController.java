package com.capgemini.controller;

/************************************************************************************
 * File:        BankDaoImpl.java
 * Package:     com.capgemini.controller
 * Description:        Controller class for Online Banking System
 * Version:     3.0
 * Author: Group5            Date:02/02/2017        
 ************************************************************************************/
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;










import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.constants.OBS_Constants;
import com.capgemini.entity.AccountMaster;
import com.capgemini.entity.PayeeTable;
import com.capgemini.entity.ServiceTracker;
import com.capgemini.entity.Transaction;
import com.capgemini.entity.UserTable;
import com.capgemini.exception.BankingException;
import com.capgemini.logger.LogInfo;
import com.capgemini.service.IBankService;
import com.capgemini.service.IUserService;
import com.sun.org.apache.xml.internal.security.Init;


@Controller
@SessionAttributes({"model","user12","user"})
public class BankController 
{
	HttpSession session;

	@Autowired
	private IBankService bankService;
	
	@Autowired
	private IUserService userService;
	
	Logger myLog=Logger.getLogger(LogInfo.class);

	
	/**
	 * @return to the view 
	 */
	@RequestMapping(value=OBS_Constants.MENU,method=RequestMethod.GET )
	public String goToMenu() 
	{	
		return OBS_Constants.USERMENU;
	}
	
	
	
	/**
	 * @return to the view 
	 */
	@RequestMapping(value=OBS_Constants.MENUNEW,method=RequestMethod.GET )
	public String goToMenuNEW() 
	{	
		return OBS_Constants.FRONTMENU;
	}
	/**
	 * The method checks the login and return to different view according forward to new view
	 * @param user of type UserTable
	 * @param res -BindingResult
	 * @param model-Model
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.LOGINUSER)
	public String loginUser(@ModelAttribute("user")@Valid UserTable user, BindingResult res, Model model)	{	
		
		String view="";
		
		UserTable temp=null;
		try 
		{
			temp = userService.login(user.getUserId(), user.getLoginPassword());
		} 
		catch (BankingException e) 
		{
			model.addAttribute("msg",e.getMessage());
			myLog.info("No user exists");
			throw new DataAccessException(e.getMessage(),e) 
			{
				private static final long serialVersionUID = 1L;
			};
		}
		
		
		if(temp!=null)
		{
			model.addAttribute("user12", temp);			
			view= OBS_Constants.USERMENU;			
			myLog.info("Successfull Login");
		}
		else
		{
			model.addAttribute("msg","invalid creditential");		
			view=OBS_Constants.LOGIN;
			myLog.info("Login failed. Invalid Credentials.");
		}
		
		return view;
	}
	
	/**
	 * This method is used to redirect the user to the Login User form.
	 * @param model		an object of Model which is used to pass UserTable object to LoginForm 	
	 * @return String	the view name
	 */
	@RequestMapping(OBS_Constants.LOGINFRONT)
	public String userLogin(Model model)
	{
		
		model.addAttribute("user", new UserTable());
		return OBS_Constants.LOGIN;
		 
	}
	
	
	/**
	 * This method is used to transform control from one view to another
	 * @param model
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.ADMINLOGIN)
	public String adminLogin(Model model)
	{
		return OBS_Constants.ADMIN;
			
	}
	
	/**
	 * Check the credentials of the admin
	 * @param adminName - String 
	 * @param adminPassword - String 
	 * @return String -name of view
	 */
	
	
	
	@RequestMapping(OBS_Constants.SAVEADMIN)
	public ModelAndView loginAdminCheck(@RequestParam(value="adminName") String adminName, @RequestParam(value="adminPassword") String adminPassword){
		
		String view="";
		String msg = "";
		if(adminName.equals("admin") && adminPassword.equals("admin"))
		{
			view= OBS_Constants.ADMINMENU;
			myLog.info("Admin Logged in Successfully");
		}else
		{
			view= OBS_Constants.ADMIN;
			msg = "Wrong Credentials for Admin";
			myLog.info("Wrong Credentials for Admin.");
		}
		return new ModelAndView(view , "msg" , msg);
	}
	
	
	
	/**
	 * This method is used to transfer the control from one view to another
	 * @param model -  Model
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.ADMININSERT)
	public String insertCustomer(Model model)
	{
		model.addAttribute("AccountMaster",new AccountMaster());
		return OBS_Constants.CUSTOMERFORM;
		
	}
	
	/**
	 * This method is used to transfer the control from one view to another
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.DELETEACCOUNT)
	public String deleteAccount()
	{
		return OBS_Constants.DELETEACCOUNTNO;
	}
	
	
	
	/**
	 * This method is used to delete the account used only by admin
	 * @param accountNo -integer
	 * @param model- Model
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.DELETE)
	public String deleteAccountNo(@RequestParam("accountNo") int accountNo,Model model)
	{
		String view="";
		int a=0;
		try
		{
			 a=bankService.deleteAccount(accountNo);
		} 
		catch (BankingException e)
		{
			model.addAttribute("msg",e.getMessage());
			myLog.info("Account Id does not Exists");
			throw new DataAccessException(e.getMessage(),e) {

				/**
				 * 
				 */
				private static final long serialVersionUID = 1L;
			};
		}
		if(a==1)
		{
			myLog.info("Account Id Deleted Successfully");
			return OBS_Constants.ADMINSUCCESS;
		}
		else
		{
			myLog.info("Deletion failed. Contact Bank");
			return OBS_Constants.ADMINFAILURE;
		}
	}
	
	/**
	 * This is used by admin to insert new Customer
	 * @param accoutmaster of type AccountMaster
	 * @param res BindingResult
	 * @param model Model
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.INSERTCUSTOMER)
	public ModelAndView insertNewCustomer(@ModelAttribute("AccountMaster")@Valid AccountMaster accoutmaster,BindingResult res,Model model){
		String view="";
		int accountId = 0;
		if(res.hasErrors())
		{
			view= OBS_Constants.CUSTOMERFORM;
		}
			
			try 
			{
				accountId = bankService.insertAccount(accoutmaster);
			} 
			catch (BankingException e)
			{
					model.addAttribute("msg",e.getMessage());
					myLog.info("Creation of new Account Failed");
					throw new DataAccessException(e.getMessage(),e) {

						/**
						 * 
						 */
						private static final long serialVersionUID = 1L;
					};
				}
			myLog.info("Account created Successfully.");
			view= OBS_Constants.ADMINSUCCESS;
			
			return new ModelAndView(view , "accountId" , accountId);
	}
	
	/**
	 * This is used to transfer control from one view to another
	 * @param model - Model
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.UPDATETRACKERFORM)
	public String updateTracker( Model model){
		model.addAttribute("serviceTracker",new ServiceTracker());
		return OBS_Constants.UPDATETRACKER_FORM;

	}
	
	
	/**
	 * This is used by admin to update the status of the service
	 * @param serviceTracker of type ServiceTracker
	 * @param res of type BindingResults
	 * @param model Model
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.UPDATETRACKER)
	public String updateTrackerStatus(@ModelAttribute("ServiceTracker") ServiceTracker serviceTracker ,BindingResult res,Model model){
		String view="";
		if(res.hasErrors()){
			
			view= OBS_Constants.UPDATETRACKER_FORM;
			
		}else{
			
		}
		myLog.info("Service Tracker status has been updated successfully.");
		view= OBS_Constants.ADMINSUCCESS;
		return view;
	}
	
	/**
	 * This method is used to transfer control from one view to another
	 * @param model - Model
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.REGISTER)
	public String registerUser(Model model){
		model.addAttribute("user",new UserTable());
		return OBS_Constants.REGISTERUSER_FORM;

	}
	
	/**
	 * this is used by user to register
	 * @param user of type UserTable
	 * @param res BindingResult
	 * @param model Model
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.REGISTERUSERFORM)
	public String registerUserForm(@ModelAttribute("user")@Valid UserTable user ,BindingResult res,Model model){
		
		String view="";
		
		if(res.hasErrors()){
			
			view=OBS_Constants.REGISTERUSER_FORM;
			
		}else{
			
			try {
				boolean flag=userService.register(user);
				if(flag==true){
					myLog.info("User has been registered successfully.");
					view=OBS_Constants.FRONTMENU;
				}
			}
			catch (BankingException e)
			{
				myLog.info("Registration Failed. Conatct bank");
				view=OBS_Constants.FAILURE;
			}
			
		}
		return view;
		
	}
	
	
	/**
	 * This is used to view the balance of a certain user
	 * @param user12 Session Attribute of type UserTable 
	 * @param model Model 
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.BALANCE)
	public String balanceEnquiry(@ModelAttribute("user12") UserTable user12, Model model)
	{
		int accountId=user12.getAccountId();
		double balance=userService.getBalance(accountId);
		model.addAttribute("balance",balance);
		myLog.info("Balance Enquiry completed.");
		return OBS_Constants.BALANCEVIEW;
	}
	
	/**
	 * This method is used to request for cheque book by user
	 * @param user12 Session Attribute of type UserTable  
	 * @param model Model
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.REQUESTCHEQUE)
	public String requestChequeBook(@ModelAttribute("user12") UserTable user12 , Model model)
	{
		int serviceId=0;
		ServiceTracker service=new ServiceTracker();
		service.setAccountId(user12.getAccountId());
		service.setServiceDescription("request for cheque book");
		service.setServiceStatus("pending");
		try 
		{
			serviceId=userService.reqCheckBook(service);
		}
		catch (BankingException e) 
		{
			model.addAttribute("msg",e.getMessage());
			myLog.info("Request for Chequebook failed.");
			throw new DataAccessException(e.getMessage(),e) {

				/**
				 * 
				 */
				private static final long serialVersionUID = 1L;
			};
		}
		myLog.info("Request for Chquebook has been placed successfully.");
		model.addAttribute("serviceId",serviceId);
		return OBS_Constants.REQSUCCESS;
	}
	
	
	/**
	 * This is used to transfer control from one view to another
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.TRACKSERVICE)
	public String trackService()
	{
		return OBS_Constants.TRACKSERVICEFORM;
	}
	
	
	/**
	 * This method is used to view the Services
	 * @param serviceId - integer
	 * @param model - Model
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.TRACK)
	public String trackServices(@RequestParam("serviceId") int serviceId, Model model)
	{
		ServiceTracker service=null;
		try {
			service=userService.serviceView(serviceId);
		} catch (BankingException e) {
			model.addAttribute("msg",e.getMessage());
			myLog.info("Service id is wrong. No request found.");
			throw new DataAccessException(e.getMessage(),e) {

				/**
				 * 
				 */
				private static final long serialVersionUID = 1L;
			};
		}
		myLog.info("Service Request Status has been reviewed.");
		model.addAttribute("service",service);
		return OBS_Constants.TRACKEDSERVICE;
	}
	

	/**
	 * This is used to transfer control from one view to another
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.CHANGEPASS)
	public String changePassForm()
	{
		return OBS_Constants.CHANGEPASSFORM;
	}
	
	
	/**
	 * This method is used to change password by a certain user
	 * @param password String 
	 * @param user12 of type UserTAble
	 * @param model Model
	 * @return String -name of view
	*/
	@RequestMapping(OBS_Constants.CHANGEPASSWORD)
	public String changePassword(@RequestParam("newpass1") String password, @ModelAttribute("user12") UserTable user12, Model model)
	{	
		
		int userId=user12.getUserId();
		try
		{
			userService.changePassword(userId, password);
		} 
		catch (BankingException e)
		{
			model.addAttribute("msg",e.getMessage());
			myLog.info("Failed to change the password.");
			throw new DataAccessException(e.getMessage(),e) {

				/**
				 * 
				 */
				private static final long serialVersionUID = 1L;
			};
		}
		myLog.info("Password has been changed successfully.");
		return OBS_Constants.FORWARDLOGOUT;
	}
	
	
	/**
	 * This method used to log a user out
	 * @param user12 Session Attribute of type UserTable
	 * @param session HttpSession
	 * @param status SessionStatus
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.LOGOUT)
	public String logout(@ModelAttribute("user12") UserTable user12, HttpSession session, SessionStatus status)
	{
		status.setComplete();
		session.removeAttribute("user12");
		return OBS_Constants.FRONTMENU;
	}
	
	
	/**
	 * This method is used to transfer control from one view to another
	 * @param user12 Session Attribute
	 * @param model Model
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.FUNDTRANSFER)
	public String fundtransfer(@ModelAttribute("user12") UserTable user12,Model model)
	{	
		List<PayeeTable> payeelist=userService.fetchPayee(user12.getAccountId());
		model.addAttribute("payee",payeelist);
		myLog.info("Payee List has been fetched.");
		return OBS_Constants.FUNDTRANSFERDETAILS;
	}
	
	
	
	/**
	 * This method is used to transfer control from one view to another
	 * @param model Model
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.ADDPAYEE)
	public String addPayee(Model model)
	{
		model.addAttribute("PayeeList", new PayeeTable());
		return OBS_Constants.ADDPAYEEFORM;
	}
	
	
	/**
	 * this method is used to add ne wPayee
	 * @param payee of type PayeeTable
	 * @param model Model
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.ADDNEWPAYEE)
	public String addPayeeDetails(@ModelAttribute("PayeeList") PayeeTable payee, Model model)
	{
		
		try 
		{
			userService.addPayee(payee);
		}
		catch (BankingException e)
		{
			model.addAttribute("msg",e.getMessage());
			myLog.info("Failed to add Payee.");
			throw new DataAccessException(e.getMessage(),e) {

				/**
				 * 
				 */
				private static final long serialVersionUID = 1L;
			};
		}
		myLog.info("Payee has been added successfully.");
		return OBS_Constants.SUCCESS;
	}
	
	/**
	 * This method is used to transfer funds
	 * @param payee integer
	 * @param amount double 
	 * @param payer integer
	 * @param model Model
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.TRANSFERFUNDS)
	public String transferFund(@RequestParam("payee") int payee, @RequestParam("amount") double amount, @RequestParam("payer")int payer ,Model model )
	{
		
		try {
			userService.ownFundTransfer(payer, payee, amount);
		} 
		catch (BankingException | SQLException e) 
		{
			model.addAttribute("msg",e.getMessage());
			myLog.info("Fund Transfer failed.");
			throw new DataAccessException(e.getMessage(),e) {

				/**
				 * 
				 */
				private static final long serialVersionUID = 1L;
			};
		}
		myLog.info("Fund have been transfered successfully.");
		return OBS_Constants.SUCCESS;
	}
	
	
	/**
	 * This method is used to generate the mini statement
	 * @param user12 Session Attribute of type UserTable
	 * @param model Model 
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.MINI)
	public String miniStatement(@ModelAttribute("user12") UserTable user12, Model model )
	{
		List<Transaction> tranlist=null;
		try {
			tranlist = userService.getDetailsMini(user12.getAccountId());
		} 
		catch (BankingException e) 
		{
			model.addAttribute("msg",e.getMessage());
			myLog.info("Failed to fetch the mini statement.");
			throw new DataAccessException(e.getMessage(),e) {

				/**
				 * 
				 */
				private static final long serialVersionUID = 1L;
			};
		}
		model.addAttribute("tranlist", tranlist);
		myLog.info("Mini Statement has been fetched.");
		return OBS_Constants.SHOWMINI;
		
	}
	
	
	/**
	 * To transfer control from one view to another
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.FORGETPASSSWORD)
	public String forgetPasswordForm()
	{
		return OBS_Constants.FORGETPASSWORDFORM ;
	}
	
	
	/**
	 * To generate the security Question
	 * @param userId Session Attribute of type UserTAble
	 * @param model Model
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.GENSECURITYQUESTION)
	public String generateSecurityQuestion(@RequestParam("userId") int userId, Model model)
	{	
		String msg;
		UserTable user=userService.getUser(userId);
		if(user==null)
		{
			msg="User not found";
			model.addAttribute("msg",msg);
			myLog.info("User not found");
		}

		else
		{
			myLog.info("User has been found.");
			model.addAttribute("user12",user);
		}
		return OBS_Constants.FORGETPASSWORDFORM;
	}
	
	
	/**
	 * This is used to check the answer given by user for security Question
	 * @param accAns String 
	 * @param nowAns String 
	 * @param user UserTable
	 * @param model Model
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.CHECKANSWER)
	public String checkanswer(@RequestParam("acctualAns") String accAns, @RequestParam("nowAns") String nowAns , @ModelAttribute("user12") UserTable user, Model model)
	{
		String view="";
		if(accAns.equalsIgnoreCase(nowAns))
		{
			myLog.info("Security Check Passed");
			view=OBS_Constants.FORWARDCHANGEPASS;
		}
		else
		{	
			String msg="Your Answer is Wrong";
			myLog.info("Security Check failed");
			model.addAttribute("msg",msg);
			view= OBS_Constants.FORGETPASSWORDFORM;
		}
		return view;
	}
	
	
	/**
	 * this is used to transfer control from one view to another
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.UPDATETRACKFORM)
	public String updateTracker()
	{
		return OBS_Constants.UPDATETRACKERFROMRETURN;
	}
	
	/**
	 * This method is used to generate service Id for a given service
	 * @param serviceId of type integer
	 * @param model Model
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.GENERATEID)
	public String generateServiceId(@RequestParam("serviceId") int serviceId, Model model)
	{
		String view="";
		
		@SuppressWarnings("unused")
		String msg=null;
		ServiceTracker track=bankService.updateTracker(serviceId);
		if(track==null)
		{
			msg="Service not found";
			myLog.info("Service Not Found. Failed to update");
			view= OBS_Constants.UPDATETRACKERFROMRETURN;
		}
		else
		{
			myLog.info("Service found.");
			model.addAttribute("track",track);
			view= OBS_Constants.UPDATETRACK;
		}
		
		return view;
	}
	
	/**
	 * This is used by admin to update status of a service
	 * @param track of type ServiceTracker
	 * @param res BindingResult
	 * @param model Model
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.UPDATE)
	public String updateService(@ModelAttribute("track")@Valid ServiceTracker track, BindingResult res , Model model)
	{
		String view="" ;
		
		
		if(res.hasErrors())
			view= OBS_Constants.UPDATETRACK;
		
		try 
		{
			bankService.updateTrack(track);
		} 
		catch (BankingException e) 
		{
			model.addAttribute("msg",e.getMessage());
			myLog.info("Failed to update");
			throw new DataAccessException(e.getMessage(),e) {

				/**
				 * 
				 */
				private static final long serialVersionUID = 1L;
			};
		}
		myLog.info("Service Status Updated Successfully.");
		view= OBS_Constants.ADMINSUCCESS;
		
	return view;
	}
	
	
	/**
	 * This method is used to transfer control from one view to another
	 * @return String -name of view
	 */
	@RequestMapping(OBS_Constants.ADMINHOME)
	public String home()
	{
		return OBS_Constants.ADMINMENUHOME ;
	}
}

