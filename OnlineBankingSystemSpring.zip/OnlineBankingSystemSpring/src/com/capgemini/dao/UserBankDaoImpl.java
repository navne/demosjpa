package com.capgemini.dao;

import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.entity.AccountMaster;
import com.capgemini.entity.Customer;
import com.capgemini.entity.FundTransfer;
import com.capgemini.entity.PayeeTable;
import com.capgemini.entity.ServiceTracker;
import com.capgemini.entity.Transaction;
import com.capgemini.entity.UserTable;
import com.capgemini.exception.BankingException;


/************************************************************************************
 * File:        BankDaoImpl.java
 * Package:     com.capgemini.dao
 * Description:        Dao class for Online Banking System (user)
 * Version:     3.0
 * Author: Group5            Date:02/02/2017        
 ************************************************************************************/

@Repository
public class UserBankDaoImpl implements IUserBankDao {

	@PersistenceContext
	private EntityManager manager;
	


	/* (non-Javadoc)
	 * @see com.capgemini.dao.IUserBankDao#login(int)
	 */
	@Override
	public UserTable login(int userId) throws BankingException {
		try {
			UserTable user = manager.find(UserTable.class, userId);
			
			if(user == null)
				throw new BankingException("No user Exists");
			else
				return user;
		} catch (Exception e) {
			throw new BankingException("No user Exists");
		}
	}

	/* (non-Javadoc)
	 * @see com.capgemini.dao.IUserBankDao#register(com.capgemini.entity.UserTable)
	 */
	@Override
	public boolean register(UserTable user) throws BankingException {
		
		int accountId=user.getAccountId();
		AccountMaster master=manager.find(AccountMaster.class ,accountId);
		
		if(master!=null)
		{
			
			try {
				manager.persist(user);
			} catch (Exception e) {
				throw new BankingException();
				
			}
		
		}
		else
			throw new BankingException("Please open new Account at our bank branch.... Contact @1800-5424-800");
		UserTable user_check=manager.find(UserTable.class, user.getUserId());
		if(user_check==null)
			throw new BankingException("Server Error. Contact bank @1800-5424-800");
		else
		
		return true;
	}

	/* (non-Javadoc)
	 * @see com.capgemini.dao.IUserBankDao#getDetailsMini(int)
	 */
	@Override
	public List<FundTransfer> getDetailsMini(int accountNo)
			throws BankingException {
		
		List<FundTransfer> fundList=new ArrayList<>();
		
		String query="select f from FundTransfer f where accountId=:account_id";
		TypedQuery<FundTransfer> query1 = manager.createQuery(query, FundTransfer.class);
		query1.setParameter("account_id", accountNo);
		fundList=query1.getResultList();
	
		if(fundList==null)
			return null;
		else
			return fundList;
		
		
	}

	/* (non-Javadoc)
	 * @see com.capgemini.dao.IUserBankDao#serviceView(int)
	 */
	@Override
	public ServiceTracker serviceView(int serviceId)
			throws BankingException {
		ServiceTracker service=manager.find(ServiceTracker.class,serviceId);
		return service;
	}

	/* (non-Javadoc)
	 * @see com.capgemini.dao.IUserBankDao#changePassword(int, java.lang.String)
	 */
	@Override
	public int changePassword(int userId, String password)
			throws BankingException {
		UserTable user=manager.find(UserTable.class, userId);
		String pass1=user.getLoginPassword();
		user.setLoginPassword(password);
		manager.merge(user);
		String pass2=user.getLoginPassword();
		if(!pass1.equals(pass2))
			return 1;
		else
			throw new BankingException("Server Down... Please Try Again Later....");
	}



	/* (non-Javadoc)
	 * @see com.capgemini.dao.IUserBankDao#ownFundTransfer(int, int, double)
	 */
	@Override
	public int ownFundTransfer(int accountPayer, int accountPayee,
			double amount) throws BankingException{
		double payeebalance;
		double payerbalance;
		double currentBalance;
		double currentBalance1;
		int transactionId ;
		
		
		
		try 
		{
			AccountMaster master=manager.find(AccountMaster.class, accountPayer);
			AccountMaster master1=manager.find(AccountMaster.class, accountPayee);
			if(master1 == null)
			{
				throw new BankingException("Payee doesnot exists");
			}
			
			currentBalance=master.getAccountBalance();
			currentBalance1=master1.getAccountBalance();
			
			payerbalance=currentBalance-amount;
			payeebalance=currentBalance1+amount;
			
			if(currentBalance<amount)
			{
				System.out.println("inbalance");
				throw new BankingException("Insufficient Balance");
			}
			
			master.setAccountBalance(payerbalance);
			master1.setAccountBalance(payeebalance);
			
			manager.merge(master);
			manager.merge(master1);
						
			FundTransfer fund=new FundTransfer();
			fund.setAccountId(accountPayer);
			fund.setPayeeAccountId(accountPayee);
			fund.setTransferAmount(amount);
			manager.persist(fund);
			transactionId = fund.getFundTransferId();
			
			Transaction tran=new Transaction();
			tran.setAccountNo(accountPayer);
			tran.setTranAmount(amount);
			tran.setTransactionDesc("Fund Transfer");
			tran.setTransactionType("Debit");
			
			manager.persist(tran);
						
			Transaction tran1=new Transaction();
			tran1.setAccountNo(accountPayee);
			tran1.setTranAmount(amount);
			tran1.setTransactionDesc("Fund Transfer");
			tran1.setTransactionType("Credit");
			
			manager.persist(tran1);
			
		} 
		catch (Exception e) 
		{
			
			throw new BankingException("Unable to transfer contact Bank");
		}
		return transactionId;
	}

	/* (non-Javadoc)
	 * @see com.capgemini.dao.IUserBankDao#addPayee(com.capgemini.entity.PayeeTable)
	 */
	@Override
	public void addPayee(PayeeTable payee) throws BankingException 
	{
		AccountMaster master=manager.find(AccountMaster.class, payee.getPayeeAccountId());
		if(master == null)
			throw new BankingException("No account number exist for payee specified");
		try {
			manager.persist(payee);
		} catch (Exception e) {
			
			e.printStackTrace();
			throw new BankingException("Unable to add... Contact bank");
		}
		
	}

	/* (non-Javadoc)
	 * @see com.capgemini.dao.IUserBankDao#getUser(int)
	 */
	@Override
	public UserTable getUser(int userId) {
		UserTable user=manager.find(UserTable.class,userId);
		return user;
	}

	/* (non-Javadoc)
	 * @see com.capgemini.dao.IUserBankDao#getBalance(int)
	 */
	@Override
	public double getBalance(int accountId) {
		AccountMaster account=manager.find(AccountMaster.class, accountId);
		return account.getAccountBalance();
	}

	/* (non-Javadoc)
	 * @see com.capgemini.dao.IUserBankDao#reqCheckBook(com.capgemini.entity.ServiceTracker)
	 */
	@Override
	public int reqCheckBook(ServiceTracker service) throws BankingException {
		
		
		
	
		manager.persist(service);
		
		int servId1=service.getServiceId();
		
		return servId1;
		
	}

	/* (non-Javadoc)
	 * @see com.capgemini.dao.IUserBankDao#fetchPayee(int)
	 */
	@Override
	public List<PayeeTable> fetchPayee(int accountId) {
		List<PayeeTable> payeeList=new ArrayList<>();
		String query="select payee from PayeeTable payee where accountId=:paccountId";
		TypedQuery<PayeeTable> query1 = manager.createQuery(query, PayeeTable.class);
		query1.setParameter("paccountId", accountId);
		payeeList=query1.getResultList();
		if(payeeList==null)
			return null;
		else
			return payeeList;
	}

	@Override
	public String getName(int accountId) {
		Customer customer=manager.find(Customer.class, accountId);
		return customer.getCustomerName();
	}

	@Override
	public List<ServiceTracker> getList(int accountId) {
		javax.persistence.Query query = manager.createQuery("from ServiceTracker where accountId = :account_id");
		query.setParameter("account_id", accountId);
		List<ServiceTracker> serviceList = query.getResultList();
		return serviceList;
	}

	@Override
	public Customer getCustomer(int accountId) {
		Customer customer=manager.find(Customer.class, accountId);
		return customer;
	}

	@Override
	public void updateCust(int accountId , Customer customer) {
	javax.persistence.Query query = manager.createQuery("Update Customer Set  customerName = :"
			+ "customer_name , email = :email,address = :address,panCard = :pancard where accountId= :account_Id");
	query.setParameter("customer_name", customer.getCustomerName());
	query.setParameter("email", customer.getEmail());
	query.setParameter("account_Id", accountId);
	query.setParameter("address", customer.getAddress());
	query.setParameter("pancard", customer.getPanCard());
	query.executeUpdate();
	
		
	}

	@Override
	public List<Integer> fetchPayeeOwn(int userId) {
		List<Integer> fetchPayeeOwn = null;
		javax.persistence.Query query = manager.createQuery("Select accountId From UserTable where userId = :user_id");
		query.setParameter("user_id", userId);
		fetchPayeeOwn = query.getResultList();
		return fetchPayeeOwn;
	}

	@Override
	public List<FundTransfer> trackMini(Date fromDate, Date toDate, int accountId) {
		
		javax.persistence.Query query = manager.createQuery("From FundTransfer where accountId = :account_id and dateOfTransaction between :date_of_transfer and :date_of_transfer");
		query.setParameter("date_of_transfer", fromDate);
		query.setParameter("date_of_transfer", toDate);
		query.setParameter("account_id", accountId);
		List<FundTransfer> list = query.getResultList();
		return list;
	}
	
	
	
	





}
