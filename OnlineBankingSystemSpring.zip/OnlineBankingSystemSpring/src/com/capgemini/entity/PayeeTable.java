package com.capgemini.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;


@Entity(name="PayeeTable")
@Table(name="PayeeTable")
public class PayeeTable {
	
	
	@Column(name="accountId")
	private int accountId;
	
	@Id
	@Column(name="payeeAccountId")
	@NotNull(message="payeeAccount Id cannot be Null")
	@Min(value=4, message="Minimum 4 and Maximum 10 digits allowed.")
	private int payeeAccountId;
	
	@Column(name="nickname")
	@NotEmpty(message="Nickname cannot be empty")
	@Size(min=2, max=50, message="Nickname cannot be less than 2 and greater than 50 characters.")
	private String nickName;

	public PayeeTable() {
		super();
	}

	public PayeeTable(int accountId, int payeeAccountId, String nickName) {
		super();
		this.accountId = accountId;
		this.payeeAccountId = payeeAccountId;
		this.nickName = nickName;
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public int getPayeeAccountId() {
		return payeeAccountId;
	}

	public void setPayeeAccountId(int payeeAccountId) {
		this.payeeAccountId = payeeAccountId;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	@Override
	public String toString() {
		return "PayeeTable [accountId=" + accountId + ", payeeAccountId="
				+ payeeAccountId + ", nickName=" + nickName + "]";
	}
	
	
	
	
	

}
