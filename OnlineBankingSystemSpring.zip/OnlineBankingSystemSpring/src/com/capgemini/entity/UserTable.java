package com.capgemini.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.ws.rs.DefaultValue;

import org.hibernate.validator.constraints.NotEmpty;


@Entity(name="UserTable")
@Table(name="User_Table12")
public class UserTable extends AccountId{


	

	@Column(name="Account_Id")
	@NotNull(message="Account Id cannot be Null")
	@Min(value=4, message="Minimum 4 and Maximum 10 digits allowed.")
	private int accountId;
		
	@Id
	@Column(name="User_Id")
	@NotNull(message="Do not keep this field empty ")
	private Integer userId;
		
	@Column(name="Login_Password")
	@NotEmpty(message="Do not keep this field empty ")
	private String loginPassword;
	

	@Column(name="Secret_Question")
	@NotEmpty(message="Do not keep this field empty ")
	private String secretQuestion;
	
	@Column(name="Transaction_password")
	@NotEmpty(message="Please provide an answer to above question ")
	private String transactionPassword;
	

	@Column(name="Lock_Status")
	@DefaultValue(value="0")
	private String lockStatus;
	
	
	
	@OneToOne(mappedBy="user",cascade=CascadeType.ALL )
	private AccountMaster accountMaster;
	
	public UserTable(Integer userId, String loginPassword) {
		super();
		System.out.println("In constructor");
		this.userId = userId;
		this.loginPassword = loginPassword;
	}

	public UserTable(int accountId, Integer userId, String loginPassword,
			String secretQuestion, String transactionPassword,
			String lockStatus, AccountMaster accountMaster) {
		super();
		this.accountId = accountId;
		this.userId = userId;
		this.loginPassword = loginPassword;
		this.secretQuestion = secretQuestion;
		this.transactionPassword = transactionPassword;
		this.lockStatus = lockStatus;
		this.accountMaster = accountMaster;
	}

	public UserTable() {
		super();
	}

	
	
	
	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	
	
	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	
	public String getLoginPassword() {
		return loginPassword;
	}

	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}

	
	public String getSecretQuestion() {
		return secretQuestion;
	}

	public void setSecretQuestion(String secretQuestion) {
		this.secretQuestion = secretQuestion;
	}

	
	
	public String getTransactionPassword() {
		return transactionPassword;
	}

	public void setTransactionPassword(String transactionPassword) {
		this.transactionPassword = transactionPassword;
	}

	
	public String getLockStatus() {
		return lockStatus;
	}

	public void setLockStatus(String lockStatus) {
		this.lockStatus = lockStatus;
	}

	public AccountMaster getAccountMaster() {
		return accountMaster;
	}

	public void setAccountMaster(AccountMaster accountMaster) {
		this.accountMaster = accountMaster;
	}

	@Override
	public String toString() {
		return "UserTable [accountId=" + accountId + ", userId=" + userId
				+ ", loginPassword=" + loginPassword + ", secretQuestion="
				+ secretQuestion + ", transactionPassword="
				+ transactionPassword + ", lockStatus=" + lockStatus
				+" ]";
	}
	
	
}
