package com.cg.ois.junit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import core.cg.ois.beans.AccountMaster;
import core.cg.ois.beans.UserTable;
import core.cg.ois.exception.BankingException;
import core.cg.ois.service.ObsServiceImpl;

public class TestCases {
	private ObsServiceImpl service ;
	private UserTable user ;
	private AccountMaster account;
	
	
	@Before
	public void beforetest()
	{
		user = new UserTable();
		service = new ObsServiceImpl();
		account = new AccountMaster();
	
		
	}

	@Test
	public void logintest() throws BankingException {
		
		user.setUserId(9812);
		user.setPassword("edf");
		int id = service.loginProcess(user);
		assertEquals(0, id);
		
		
	}
	
	@Test
	public void registertest() throws BankingException {
		
		user.setUserId(9812);
		user.setPassword("edf");
		user.setAccountId(3001);
		user.setSecretQuestion("abc");
		user.setTransactionPassword("abc");
		
		assertEquals(true,  service.register(user));
		
		
	}
	
	
	@After
	public void afterest()
	{
		user = null;
		service = null;
	}
	
	

}
