package core.cg.ois.service;

import java.util.List;

import core.cg.ois.beans.AccountMaster;
import core.cg.ois.beans.Customer;
import core.cg.ois.beans.PayeeTable;
import core.cg.ois.beans.ServiceTracker;
import core.cg.ois.beans.Transaction;
import core.cg.ois.beans.UserTable;
import core.cg.ois.dao.IObsDao;
import core.cg.ois.dao.ObsDaoImpl;
import core.cg.ois.exception.BankingException;

public class ObsServiceImpl implements IObsService {
	private IObsDao dao = null;




	public ObsServiceImpl() throws BankingException {
		dao = new ObsDaoImpl();
		// TODO Auto-generated constructor stub
	}




	@Override
	public int loginProcess(UserTable user) throws BankingException {
		return dao.loginProcess(user);
		// TODO Auto-generated method stub

	}




	@Override
	public void update(int lock) {
		dao.update(lock);
		
	}




	@Override
	public AccountMaster getAccount(int accountId) throws BankingException {
		// TODO Auto-generated method stub
		return dao.getAccount(accountId);
	}




	@Override
	public String securityQues(int userId) throws BankingException {
		// TODO Auto-generated method stub
		return dao.securityQues(userId);
	}




	@Override
	public int confirmQues(String ques, String transPass) throws BankingException {
		// TODO Auto-generated method stub
		return dao.confirmQues(ques, transPass);
	}




	@Override
	public void passwordChange(int userId, String pas) throws BankingException {
		dao.passwordChange(userId, pas);
		
	}




	@Override
	public List<Transaction> getAllTransaction(int accId) throws BankingException {
		// TODO Auto-generated method stub
		return dao.getAllTransaction(accId);
	}




	@Override
	public Customer getPersonalDetails(int accId) throws BankingException {
		// TODO Auto-generated method stub
		return dao.getPersonalDetails(accId);
	}




	@Override
	public void updateCustomer(Customer cust) throws BankingException {
		 dao.updateCustomer(cust);
		
	}




	@Override
	public int requestCheckBook(int accId, String desc) throws BankingException {
		// TODO Auto-generated method stub
		return dao.requestCheckBook(accId, desc);
	}




	@Override
	public List<ServiceTracker> trackRequest(int accId) throws BankingException {
		// TODO Auto-generated method stub
		return dao.trackRequest(accId);
	}




	@Override
	public Customer getCustomerName(int accounId) throws BankingException {
		// TODO Auto-generated method stub
		return dao.getCustomerName(accounId);
	}







	@Override
	public List<PayeeTable> getPayeeList(int accId) throws BankingException {
		// TODO Auto-generated method stub
		return dao.getPayeeList(accId);
	}




	@Override
	public void addPayee(PayeeTable payee) throws BankingException {
		dao.addPayee(payee);
		
	}




	@Override
	public List<AccountMaster> checkPayeeId(int payeeId) throws BankingException {
		// TODO Auto-generated method stub
		return dao.checkPayeeId(payeeId);
	}




	@Override
	public int ownFundTransfer(int accountPayer, int accountPayee, double amount) throws BankingException {
		return dao.ownFundTransfer(accountPayer, accountPayee, amount);
		
	}




	@Override
	public boolean register(UserTable user) throws BankingException {
		// TODO Auto-generated method stub
		return dao.register(user);
	}
	
	




	

}
