package core.cg.ois.exception;

public class BankingException extends Exception {

	public BankingException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BankingException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public BankingException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public BankingException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public BankingException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	

}
