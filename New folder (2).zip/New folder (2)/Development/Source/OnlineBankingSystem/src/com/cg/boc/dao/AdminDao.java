package com.cg.boc.dao;

import java.util.List;

import com.cg.boc.dto.AccountHolder;
import com.cg.boc.dto.Account_Master;
import com.cg.boc.dto.Admin;
import com.cg.boc.dto.Customer;
import com.cg.boc.dto.TransactionDetails;
import com.cg.boc.dto.User;
import com.cg.boc.exception.CustomerException;

public interface AdminDao {
	public Admin matchLogin(Admin admin);
	public boolean addCustomer(Customer customer) throws CustomerException;
	public List<TransactionDetails> TransactionsDetails() ;
	public boolean addinUserTable(User user)throws CustomerException ;
	public boolean addinAccount_Master(Account_Master acc_master) ;
	public Customer getId(Customer customer);
	public boolean changemobile(Customer customer) throws CustomerException;
}
