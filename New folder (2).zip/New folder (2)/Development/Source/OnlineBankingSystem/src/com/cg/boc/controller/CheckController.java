package com.cg.boc.controller;


import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.Servlet;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.boc.dto.AccountHolder;
import com.cg.boc.dto.Account_Master;
import com.cg.boc.dto.Admin;
import com.cg.boc.dto.Customer;
import com.cg.boc.dto.TransactionDetails;
import com.cg.boc.dto.User;
import com.cg.boc.exception.CustomerException;
import com.cg.boc.service.AdminService;
import com.cg.boc.service.UserService;





@Controller
public class CheckController {
	Long random_variable=(long)(Math.random()*10000);;
	
	
	int accountid=0;
	int userid=0;
	String name=null;
	double balance=0;
	int random =(int)(Math.random()*100);
	String rand = String.valueOf(random);
	String str ="pass";
	String trans_pass = str+rand;
	Date date = new Date();
	 java.sql.Date sqlDate = new java.sql.Date(date.getTime());
	 
	@Resource(name="adminservice")
	private AdminService services;
	
	@Autowired
	private UserService userService;
	
	
	@RequestMapping("/loginAdmin")
	public String getloginPage(Model model){
		Admin admin = new Admin();
		model.addAttribute("Admin",admin);
		return "LoginAdmin";
	}
	
	@RequestMapping("/postlogin")
	@Scope("session")
	public String loginData(@ModelAttribute("Admin") Admin admin ,Model model,Model model1,HttpSession session){
		boolean flag=false;
		
		Admin admin_test = services.matchLogin(admin);
		System.out.println("in controller: "+admin_test);
		if(admin_test==null){
			String error = "Invalid ID/Password";
			model1.addAttribute("errMsg",error);
			return "LoginErrorAdmin";
		}
	
		System.out.println("flag1 is"+flag);
		if((admin.getAdmin_id().equals(admin_test.getAdmin_id()))&&(admin.getPassword().equals(admin_test.getPassword()))){
			flag=true;
		System.out.println("flag is"+flag);
		}
		System.out.println("name="+admin_test.getName());
		String name = admin_test.getName();
		session.setAttribute("name", name);
		String error = "Invalid ID/Password";
		
		model1.addAttribute("errMsg",error);
		if(flag==true)
			return "AdminSelections";
		else
			return "LoginErrorAdmin";
	
		
	}
	@RequestMapping("/NewAccount")
	
	public String createAccountPage(Model model){
		AccountHolder account = new AccountHolder();
		model.addAttribute("AccountHolder",account);
		return "NewAccount";
	}
	@RequestMapping("/postNewAccount")
	@Scope("session")
	public String createAccount(@ModelAttribute AccountHolder account ,Model model,HttpSession session){
		boolean flag=false;
		boolean flag1 = false;
		boolean flag2= false;
		System.out.println("account is = "+account.toString());
		System.out.println("account_name is = "+account.getName());
		User user=new User();
		Customer customer = new Customer();
		name=account.getName();
		balance=account.getBalance();
		Account_Master account_master = new Account_Master();
		account_master.setAccount_type(account.getAccounttype());
		account_master.setBalance(account.getBalance());
		//account_master.setSysdate(sqlDate);
		customer.setName(account.getName());
		customer.setAddress(account.getAddress());
		customer.setEmail(account.getEmail());
		customer.setMobile(account.getMobile());
		customer.setAccounttype(account.getAccounttype());
		customer.setBalance(account.getBalance());
		customer.setPancard(account.getPancard());
		System.out.println("customer in contrioller is = "+customer.toString());
	
		
		user.setLogin_password(account.getPassword());
		user.setSecret_question(account.getPetname());
		user.setTransaction_password(trans_pass);
		try {
			flag = services.addCustomer(customer);
		} catch (Exception e) {
			model.addAttribute("errMsg","Email/Pancard Number/Password Should be Unique");
			return "Error";
		}
		Customer cust = services.getId(customer);
		accountid = cust.getAccount_id();
		user.setAccount_id(accountid);
		account_master.setAccount_id(accountid);
		System.out.println("1122=:"+user);
		try {
			flag1 = services.addinUserTable(user);
		} catch (Exception e) {
			
			model.addAttribute("errMsg","Email/Pancard Number/Password Should be Unique");
		}
		flag2 = services.addinAccount_Master(account_master);
		System.out.println("flag= "+flag);
		System.out.println("flag1= "+flag1);
		String error = "Something went Wrong";
	
		userid=user.getUser_id();
		model.addAttribute("name",name);
		model.addAttribute("balance",balance);
		model.addAttribute("transaction_password",trans_pass);
		model.addAttribute("userid",userid);
		model.addAttribute("e1",error);
		if(flag==true&&flag1==true)
			return "AccountCreated";
		else
			return "Error";
		
	}
	
	@RequestMapping("/viewtransactions")
	@Scope("session")
	public String seeAllRecords(Model model,HttpSession session){
		System.out.println("in list");
		List<TransactionDetails> list = services.TransactionsDetails();
		System.out.println(list);
		String name= (String) session.getAttribute("name");
		System.out.println("name is 1: " +name);
		session.setAttribute("name", name);
		model.addAttribute("viewAllTransactions", list);
		
		return "TransactionsDetails";
		
		
	}
	
	@RequestMapping("/greetings")
	public String getlogoutPage(Model model){
		
		return "Greetings";
	}

	@RequestMapping("/adminSelections")
	public String getHomePage(Model model){
		
		return "AdminSelections";
	}
	
	@RequestMapping("/loginUser")
	public String getloginPageForUser(Model model){
		User user = new User();
		model.addAttribute("User",user);
		return "LoginUser";
	}
	
	
	@RequestMapping("/login")
	public String getlogin(Model model){
		
		
		return "Login";
	}
	

	@RequestMapping("/postloginUser")
	@Scope("session")
	public String loginDataForUser(@ModelAttribute User user ,Model model,Model model1,HttpSession session){
		boolean flag=false;
		
		User user_test;
		try {
			user_test = userService.matchLoginUser(user);
			System.out.println(user_test);
		
		if(user_test==null || user_test.equals(null)){
			String error = "Invalid ID/Password";
			model1.addAttribute("errMsg",error);
			return "LoginErrorUser";
		}
		else
		{
		
		if((user.getUser_id()==(user_test.getUser_id()))&&(user.getLogin_password().equals(user_test.getLogin_password()))){
			flag=true;
		System.out.println("flag is"+flag);
		}
		int accountid = user_test.getAccount_id();
		Customer customer = userService.getId(accountid);
		userid=user.getUser_id();
	
		String name =customer.getName();
		double balance = customer.getBalance();
		session.setAttribute("name", name);
		session.setAttribute("balance", balance);
		session.setAttribute("accountid", accountid);
		session.setAttribute("userid", userid);
		String error = "Invalid ID/Password";
		
		model1.addAttribute("errMsg",error);
		if(flag==true)
			return "Home";
		else
			return "LoginErrorUser";
		}
		} catch (Exception e) {
			
			String error = "Invalid Details";
			e.printStackTrace();
			model.addAttribute("errMsg",error);
			return "LoginErrorUser";
		}
		
		
	}
	@RequestMapping("/home")
	public String getHomePage1(Model model){
		
		
		return "Home";
	}
	
	@RequestMapping("/statementSelection")
	public String getstatementSelection(Model model){
		
		
		return "StatementSelection";
	}
	
	
	@RequestMapping("/changePassword")
	public String getchangePassword(Model model){
		User user = new User();
		model.addAttribute("User",user);
		
		return "ChangePassword";
	}
	@RequestMapping("/miniStatement")
	public String getministatement(Model model,HttpSession session){
		int accountid = (int) session.getAttribute("accountid");
		System.out.println(accountid);
		List<TransactionDetails> list =userService.TransactionsDetails(accountid);
		System.out.println(list);
		model.addAttribute("MiniTransactions",list);
		return "MiniStatement";
	}
	
	
	@RequestMapping("/detailStatement")
	public String getdetailStatement(Model model,HttpSession session){
		int accountid = (int) session.getAttribute("accountid");
		System.out.println(accountid);
		List<TransactionDetails> list =userService.DetailTransactionsDetails(accountid);
		model.addAttribute("DetailTransactions",list);
		
		return "DetailStatement";
	}
	
	@RequestMapping("/postChangePassword")
	public String changePassword(@ModelAttribute User user,Model model,HttpSession session){

		
		int userid = (int) session.getAttribute("userid");
		System.out.println(userid);
		boolean flag = false;
		try {
			flag=userService.changePassword(user,userid);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			model.addAttribute("errMsg","Enter Correct Password");
			return "PasswordError";
		}
		
		
		return "PasswordChangeSuccess";
	}
	

	
	
	@RequestMapping("/changeMobile")
	@Scope("session")
	public String getchangeMobile(Model model,HttpSession session){
		
		int accountid = (int) session.getAttribute("accountid");
		Customer customer = new Customer();
		customer.setAccount_id(accountid);
		Customer customer_test = services.getId(customer);
		
		model.addAttribute("mobile",customer_test.getMobile());
		model.addAttribute("Customer",customer);
		return "ChangeMobile";
	}
	@RequestMapping("/changeAddress")
	@Scope("session")
	public String getchangeAddress(Model model,HttpSession session){
		int accountid = (int) session.getAttribute("accountid");
		Customer customer = new Customer();
		System.out.println("hello");
		System.out.println(customer);
		customer.setAccount_id(accountid);
		Customer customer_test = services.getId(customer);
		model.addAttribute("Customer",customer);
		model.addAttribute("address",customer_test.getAddress());
		return "ChangeAddress";
	}
	
	@RequestMapping("/postChangeMobile")
	@Scope("session")
	public String changeMobile(@ModelAttribute Customer customer,Model model,HttpSession session){

		int accountid = (int) session.getAttribute("accountid");
		customer.setAccount_id(accountid);
		Customer customer_test = services.getId(customer);
		customer_test.setMobile(customer.getMobile());
		System.out.println("in controller: "+customer_test);
		boolean flag = false;
		try {
			flag=services.changemobile(customer_test);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			model.addAttribute("errMsg","Enter Unique Mobile Number");
			return "Error";
		}
		System.out.println("change mobile is :"+flag);
		
		return "MobileChangeSuccess";
	}
	
	@RequestMapping("/postChangeAddress")
	@Scope("session")
	public String changeAddress(@ModelAttribute Customer customer,Model model,HttpSession session){

		int accountid = (int) session.getAttribute("accountid");
		customer.setAccount_id(accountid);
		Customer customer_test = services.getId(customer);
		customer_test.setAddress(customer.getAddress());
		System.out.println("in controller: "+customer_test);
		boolean flag = false;
		try {
			flag=services.changemobile(customer_test);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("change mobile is :"+flag);
		
		return "AddressChangeSuccess";
	}
	
	@RequestMapping("/forgotpassword")
	public String getforgotPasswordPage(Model model){
		User user = new User();
		model.addAttribute("User",user);
		
		return "ForgotPassword";
	}
	
	@RequestMapping("/postforgotpassword")
	public String postforgotPasswordPage(@ModelAttribute User user,Model model){
	
		Long otp=0l;
		User user_test;
		try {
			user_test = userService.matchLoginUser(user);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			String error = "Invalid Details";
			model.addAttribute("errMsg",error);
			return "LoginErrorUser";
		}
		System.out.println(user_test);
		if(user_test==null){
			String error = "Invalid Details";
			model.addAttribute("errMsg",error);
			return "LoginError";
		}
		
		model.addAttribute("User",user);
		if(user.getUser_id()==user_test.getUser_id()&&user.getSecret_question().equals(user_test.getSecret_question()))
		{
			otp = random_variable;	
				
			model.addAttribute("otp",otp);
			return "OtpGeneration";
		
		}
			
		else
		{
			String error = "Invalid Details";
			model.addAttribute("errMsg",error);
			return "LoginErrorUser";
		}
		
		
		
	}

	@RequestMapping("/otp")
	public String OtpVerification(@ModelAttribute User user,Model model){
		model.addAttribute("User",user);
		System.out.println("1="+user);
User user_test;

try {
	System.out.println("cont random="+random_variable);
	System.out.println("user otp="+user.getOtp());
	user_test = userService.matchLoginUser(user);
	System.out.println(user_test.getUser_id());
	System.out.println(user.getUser_id());

		if(user_test==null){
			
			String error = "Invalid Details";
			model.addAttribute("errMsg",error);
			return "LoginErrorUser";
		}
		
		if(user.getOtp()==random_variable&&user_test.getUser_id()==user.getUser_id()){
			System.out.println(user_test);
			return "NewPassword";
			
		}
		else{
			System.out.println("hellooo");
			String error = "Invalid Details";
			model.addAttribute("errMsg",error);
			return "LoginErrorUser";
		}
} catch (Exception e) {
	// TODO Auto-generated catch block
	String error = "Invalid Details";
	model.addAttribute("errMsg",error);
	return "LoginErrorUser";
}
	
		//model.addAttribute("User",user);
		
		
	}
	
	@RequestMapping("/newpasssword")
	public String NewPassword(@ModelAttribute User user,Model model){
		System.out.println(user.getLogin_password());
		System.out.println(user.getNewpassword());
		model.addAttribute("User",user);
			if(user.getLogin_password().equals(user.getNewpassword())){
				try {
					userService.newPassword(user);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					String error = "Passsword Does Not Match";
					model.addAttribute("errMsg",error);
					return "LoginErrorUser";
				}
			}
			else{
				String error = "Passsword Does Not Match";
				model.addAttribute("errMsg",error);
				return "LoginErrorUser";	
			}
		return "PasswordChangeSuccess";
		
	}
	
	
	
}
