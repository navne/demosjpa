package com.cg.boc.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.boc.dto.Customer;
import com.cg.boc.dto.TransactionDetails;
import com.cg.boc.dto.User;
import com.cg.boc.exception.CustomerException;

public interface UserService {
	public User matchLoginUser(User user) throws CustomerException;
	public Customer getId(int accountid);
	public List<TransactionDetails> DetailTransactionsDetails(int accountid) ;
	public List<TransactionDetails> TransactionsDetails(int accountid) ;
	public boolean changePassword(User user,int userid) throws CustomerException;
	public boolean newPassword(User user)  throws CustomerException;
}
