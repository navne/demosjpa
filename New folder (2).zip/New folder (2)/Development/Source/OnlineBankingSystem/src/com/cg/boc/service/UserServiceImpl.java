package com.cg.boc.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.boc.dao.UserDao;
import com.cg.boc.dto.Customer;
import com.cg.boc.dto.TransactionDetails;
import com.cg.boc.dto.User;
import com.cg.boc.exception.CustomerException;
@Service
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;
	
	
	@Override
	public User matchLoginUser(User user) throws CustomerException{
		
		return userDao.matchLoginUser(user);
	}


	@Override
	public Customer getId(int accountid) {
		// TODO Auto-generated method stub
		return userDao.getId(accountid);
	}


	@Override
	public List<TransactionDetails> TransactionsDetails(int accountid) {
		// TODO Auto-generated method stub
		return userDao.TransactionsDetails(accountid);
	}


	@Override
	public List<TransactionDetails> DetailTransactionsDetails(int accountid) {
		// TODO Auto-generated method stub
		return userDao.DetailTransactionsDetails(accountid);
	}


	@Override
	public boolean changePassword(User user,int userid)  throws CustomerException{
		// TODO Auto-generated method stub
		return userDao.changePassword(user,userid);
	}


	@Override
	public boolean newPassword(User user) throws CustomerException {
		// TODO Auto-generated method stub
		return userDao.newPassword(user);
	}

}
