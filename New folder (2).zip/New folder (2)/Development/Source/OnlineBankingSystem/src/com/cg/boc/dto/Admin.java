package com.cg.boc.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;





@Entity(name="AdminTable")
@Table(name="AdminTable")
public class Admin {
private String admin_id;
private String password;
private String name;
@Column(name="name")
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
@Id
@Column(name="admin_id")
public String getAdmin_id() {
	return admin_id;
}
public void setAdmin_id(String admin_id) {
	this.admin_id = admin_id;
}
@Column(name="password")
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public Admin(String admin_id, String password) {
	super();
	this.admin_id = admin_id;
	this.password = password;
}
public Admin() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Admin [admin_id=" + admin_id + ", password=" + password + ", name="
			+ name + "]";
}


}
