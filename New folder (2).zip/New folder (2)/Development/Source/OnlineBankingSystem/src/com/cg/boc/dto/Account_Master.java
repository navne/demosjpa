package com.cg.boc.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity(name="Account_master")
@Table(name="Account_master")

public class Account_Master implements Serializable{
	
	private int account_id;
	private char account_type;
	private double balance;
	private Date sysdate = new Date();
	@Id 
//	@OneToOne(mappedBy = "account_id")
	 @Column(name="account_id")
	public int getAccount_id() {
		return account_id;
	}
	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}
	
	@Column(name="account_type")
	public char getAccount_type() {
		return account_type;
	}
	public void setAccount_type(char account_type) {
		this.account_type = account_type;
	}
	@Column(name="account_balance")
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Column(name="open_date")
	public Date getSysdate() {
		return sysdate;
	}
	public void setSysdate(Date sysdate) {
		this.sysdate = sysdate;
	}
	public Account_Master(int account_id, char account_type, double balance,
			Date sysdate) {
		super();
		this.account_id = account_id;
		this.account_type = account_type;
		this.balance = balance;
		this.sysdate = sysdate;
	}
	public Account_Master() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Account_Master [account_id=" + account_id + ", account_type="
				+ account_type + ", balance=" + balance + ", sysdate="
				+ sysdate + "]";
	}
	
}
