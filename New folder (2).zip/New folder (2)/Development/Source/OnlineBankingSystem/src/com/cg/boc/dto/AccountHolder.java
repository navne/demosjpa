package com.cg.boc.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


public class AccountHolder {
	
	
	private int account_id;
	private String name;
	private String email;
	private String address;
	private String pancard;
	private String mobile;
	private char accounttype;
	private double balance;
	
	private String password;

	 @Column(name="account_id")
	public int getAccount_id() {
		return account_id;
	}
	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPetname() {
		return petname;
	}
	public void setPetname(String petname) {
		this.petname = petname;
	}
	private String petname;
	@Column(name="pancard")
	public String getPancard() {
		return pancard;
	}
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	@Column(name="customer_name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Column(name="address")
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Column(name="email")
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Column(name="mobile")
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	@Column(name="accounttype")
	public char getAccounttype() {
		return accounttype;
	}
	public void setAccounttype(char accounttype) {
		this.accounttype = accounttype;
	}
	@Column(name="balance")
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	
	public AccountHolder(String name, String address, String email,
			String mobile, char accounttype, double balance, String pancard) {
		super();
		this.name = name;
		this.address = address;
		this.email = email;
		this.mobile = mobile;
		this.accounttype = accounttype;
		this.balance = balance;
		this.pancard = pancard;
	}
	public AccountHolder() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "AccountHolder [name=" + name + ", address=" + address
				+ ", email=" + email + ", mobile=" + mobile + ", accounttype="
				+ accounttype + ", balance=" + balance + ", pancard=" + pancard
				+ ", password=" + password + ", account_id=" + account_id
				+ ", petname=" + petname + "]";
	}

	
}
