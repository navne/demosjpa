package com.cg.boc.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity(name="Customer")
@Table(name="Customer")

public class Customer implements Serializable{
	private static final long serialVersionUID = 1L;
	@Id 
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "account_seq")
	@SequenceGenerator(name="account_seq", sequenceName="account_seq")
	private int account_id;
	private String customer_name;
	private String email;
	private String address;
	private String pancard;
	private String mobile;
	private char account_type;
	private double balance;
	

	@OneToOne
	@JoinColumn(name = "account_id")
	 @Column(name="account_id")
	public int getAccount_id() {
		return account_id;
	}
	
	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}
	
	
	@Column(name="pancard", unique=true , nullable = false , length=20)
	public String getPancard() {
		return pancard;
	}
	
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	@Column(name="customer_name")
	public String getName() {
		return customer_name;
	}
	public void setName(String customer_name) {
		this.customer_name = customer_name;
	}
	@Column(name="address")
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Column(name="email" , unique=true , nullable = false , length=20)
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Column(name="mobile")
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	@Column(name="account_type")
	public char getAccounttype() {
		return account_type;
	}
	public void setAccounttype(char account_type) {
		this.account_type = account_type;
	}
	@Column(name="balance")
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Customer [account_id=" + account_id + ", customer_name=" + customer_name
				+ ", email=" + email + ", address=" + address + ", pancard="
				+ pancard + ", mobile=" + mobile + ", accounttype="
				+ account_type + ", balance=" + balance + "]";
	}
	

}
