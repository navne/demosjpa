package com.cg.boc.service;


import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.boc.dao.AdminDao;
import com.cg.boc.dto.AccountHolder;
import com.cg.boc.dto.Account_Master;
import com.cg.boc.dto.Admin;
import com.cg.boc.dto.Customer;
import com.cg.boc.dto.TransactionDetails;
import com.cg.boc.dto.User;
import com.cg.boc.exception.CustomerException;

@Service("adminservice")
@Transactional
public class AdminServiceImpl implements AdminService{

	@Resource(name="admindao")
	private AdminDao adminDao;
	@Override
	public Admin matchLogin(Admin admin) {
		// TODO Auto-generated method stub
		return adminDao.matchLogin(admin);
	}
	@Override
	public boolean addCustomer(Customer customer) throws CustomerException {
		return adminDao.addCustomer(customer);
	}
	@Override
	public List<TransactionDetails> TransactionsDetails() {
		// TODO Auto-generated method stub
		return adminDao.TransactionsDetails();
	}
	@Override
	public boolean addinUserTable(User user) throws CustomerException {
		// TODO Auto-generated method stub
		return adminDao.addinUserTable(user);
	}
	@Override
	public boolean addinAccount_Master(Account_Master acc_master) {
		// TODO Auto-generated method stub
		return adminDao.addinAccount_Master(acc_master);
	}
	@Override
	public Customer getId(Customer customer) {
		// TODO Auto-generated method stub
		return adminDao.getId(customer);
	}
	@Override
	public boolean changemobile(Customer customer) throws CustomerException {
		// TODO Auto-generated method stub
		return adminDao.changemobile(customer);
	}

}
