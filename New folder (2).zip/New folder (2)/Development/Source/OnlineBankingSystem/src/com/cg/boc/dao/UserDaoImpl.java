package com.cg.boc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.boc.dto.Admin;
import com.cg.boc.dto.Customer;
import com.cg.boc.dto.TransactionDetails;
import com.cg.boc.dto.User;
import com.cg.boc.exception.CustomerException;

@Repository("userdao")
public class UserDaoImpl implements UserDao{

	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public User matchLoginUser(User user) throws CustomerException{	
		User user_test =null;
		try{
		user_test = entityManager.find(User.class,user.getUser_id());
		}
		catch(Exception e){
			throw new CustomerException("Invalid details");
			
			
			
		}
		return user_test;
	}

	
//	public User matchForForgotPassword(User user) {	
//		User user_test = entityManager.find(User.class,user.getUser_id());
//	
//		return user_test;
//	}
//	
	public Customer getId(int accountid){
		Customer customer = entityManager.find(Customer.class,accountid);
		return customer;
	}
	
	
	public List<TransactionDetails> TransactionsDetails(int accountid) {
		TypedQuery qry = entityManager.createQuery("select t from Transactions t where Account_No=:id and rownum<=10",TransactionDetails.class);
		qry.setParameter("id", accountid);
		List<TransactionDetails> list = qry.getResultList();
		return list;
	}
	public List<TransactionDetails> DetailTransactionsDetails(int accountid) {
		TypedQuery qry = entityManager.createQuery("select t from Transactions t where Account_No=:id",TransactionDetails.class);
		qry.setParameter("id", accountid);
		List<TransactionDetails> list = qry.getResultList();
		return list;
	}
	public boolean checkforCurrentPassword(int userid,String password) throws CustomerException {
		boolean flag=false;
		TypedQuery qry = entityManager.createQuery("select t from usertable t where user_id= :id and login_password= :password",User.class);
		qry.setParameter("id", userid);
		qry.setParameter("password", password);
		User user = (User) qry.getSingleResult();
		System.out.println("11="+user);
		String pass = user.getLogin_password();
		if(pass.equals(password)){
			flag=true;
		}
		System.out.println("flag12="+flag);
		return flag;
	}
	
	public boolean changePassword(User user,int userid)  throws CustomerException{
		boolean flag1=false;
		int user_id = Integer.valueOf(userid);
		user.setUser_id(user_id);
		
		System.out.println("in dao user is :"+user);
		String currentpassword = user.getLogin_password();
		String newpassword = user.getNewpassword();
		System.out.println("in dao currentpassword :"+currentpassword);
		System.out.println("in dao newpassword"+newpassword);
		System.out.println("userid"+userid);
		
	
		boolean flag = checkforCurrentPassword(userid,currentpassword);
		System.out.println("in dao flag is:"+flag);
		if(flag==true){
			User user_test = entityManager.find(User.class, user.getUser_id());
			user_test.setLogin_password(newpassword);
		
			user_test=entityManager.merge(user_test);
			System.out.println("new user in dao:"+user_test);

		flag1=true;
		}
		System.out.println("flag23="+flag1);
		return flag1;
	}
	
	
	

	public boolean newPassword(User user)  throws CustomerException{
		boolean flag1=false;

	

		
		
			User user_test = entityManager.find(User.class, user.getUser_id());
			user_test.setLogin_password(user.getNewpassword());
		
			user_test=entityManager.merge(user_test);
			System.out.println("new user in dao:"+user_test);

		flag1=true;
		
		return flag1;
	}
	
}
