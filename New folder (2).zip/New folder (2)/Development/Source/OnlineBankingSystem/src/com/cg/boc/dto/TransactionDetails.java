package com.cg.boc.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity(name="Transactions")
@Table(name="Transactions")
public class TransactionDetails {
private long Transaction_Id;
private String Tran_Description;
private Date DateofTransaction;
private String Transaction_Type;
private double TranAmount;
private long Account_ID;
@Id
@Column(name="Transaction_ID")
public long getTransaction_Id() {
	return Transaction_Id;
}
public void setTransaction_Id(long transaction_Id) {
	this.Transaction_Id = transaction_Id;
}
@Column(name="Tran_description")
public String getTran_Description() {
	return Tran_Description;
}
public void setTran_Description(String tran_Description) {
	this.Tran_Description = tran_Description;
}
@Column(name="DateofTransaction")
public Date getDateofTransaction() {
	return DateofTransaction;
}
public void setDateofTransaction(Date dateofTransaction) {
	this.DateofTransaction = dateofTransaction;
}
@Column(name="TransactionType")
public String getTransaction_Type() {
	return Transaction_Type;
}
public void setTransaction_Type(String transaction_Type) {
	this.Transaction_Type = transaction_Type;
}
@Column(name="TranAmount")
public double getTranAmount() {
	return TranAmount;
}
public void setTranAmount(double tranAmount) {
	this.TranAmount = tranAmount;
}
@Column(name="Account_No")
public long getAccount_ID() {
	return Account_ID;
}
public void setAccount_ID(long account_ID) {
	this.Account_ID = account_ID;
}
public TransactionDetails(long transaction_Id, String tran_Description,
		Date dateofTransaction, String transaction_Type, double tranAmount,
		long account_ID) {
	super();
	this.Transaction_Id = transaction_Id;
	this.Tran_Description = tran_Description;
	this.DateofTransaction = dateofTransaction;
	this.Transaction_Type = transaction_Type;
	this.TranAmount = tranAmount;
	this.Account_ID = account_ID;
}
@Override
public String toString() {
	return "TransactionDetails [Transaction_Id=" + Transaction_Id
			+ ", Tran_Description=" + Tran_Description + ", DateofTransaction="
			+ DateofTransaction + ", Transaction_Type=" + Transaction_Type
			+ ", TranAmount=" + TranAmount + ", Account_ID=" + Account_ID + "]";
}
public TransactionDetails() {
	super();
	// TODO Auto-generated constructor stub
}





}
