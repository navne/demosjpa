package com.cg.boc.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
@Entity(name="usertable")
@Table(name="usertable")
public class User implements Serializable{
	private static final long serialVersionUID = 1L;
	
private int account_id;
@Transient
private long otp;



public long getOtp() {
	return otp;
}
public void setOtp(long otp) {
	this.otp = otp;
}
@Transient
private String newpassword;

public String getNewpassword() {
return newpassword;
}
public void setNewpassword(String newpassword) {
	this.newpassword = newpassword;
}
@Id 
@GeneratedValue(strategy = GenerationType.AUTO, generator = "userid_seq")
@SequenceGenerator(name="userid_seq", sequenceName="userid_seq")
private int user_id;
private String login_password;
private String secret_question;

private String transaction_password;
private String lock_status="N";
private int counter=0;
@OneToOne(mappedBy = "account_id")
@Column(name="account_id")
public int getAccount_id() {
	return account_id;
}
public void setAccount_id(int account_id) {
	this.account_id = account_id;
}

@Column(name="user_id")
public int getUser_id() {
	return user_id;
}
public void setUser_id(int user_id) {
	this.user_id = user_id;
}
@Column(name="login_password",unique=true , nullable = false , length=20)
public String getLogin_password() {
	return login_password;
}
public void setLogin_password(String login_password) {
	this.login_password = login_password;
}
@Column(name="secret_question")
public String getSecret_question() {
	return secret_question;
}
public void setSecret_question(String secret_question) {
	this.secret_question = secret_question;
}
@Column(name="Transaction_password")
public String getTransaction_password() {
	return transaction_password;
}
public void setTransaction_password(String transaction_password) {
	this.transaction_password = transaction_password;
}
@Column(name="lock_status")
public String getLock_status() {
	return lock_status;
}
public void setLock_status(String lock_status) {
	this.lock_status = lock_status;
}
@Column(name="counter")
public int getCounter() {
	return counter;
}
public void setCounter(int counter) {
	this.counter = counter;
}
public User() {
	super();
	// TODO Auto-generated constructor stub
}
public User(int account_id, int user_id, String login_password,
		String secret_question, String transaction_password, String lock_status,
		int counter) {
	super();
	this.account_id = account_id;
	this.user_id = user_id;
	this.login_password = login_password;
	this.secret_question = secret_question;
	this.transaction_password = transaction_password;
	this.lock_status = lock_status;
	this.counter = counter;
}
@Override
public String toString() {
	return "User [account_id=" + account_id + ", user_id=" + user_id
			+ ", login_password=" + login_password + ", secret_answer="
			+ secret_question + ", transaction_password=" + transaction_password
			+ ", lock_status=" + lock_status + ", counter=" + counter + "]";
}



}
