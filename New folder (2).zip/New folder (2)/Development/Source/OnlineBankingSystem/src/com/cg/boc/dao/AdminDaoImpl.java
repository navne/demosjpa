package com.cg.boc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;




import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;





import com.cg.boc.dto.Account_Master;
import com.cg.boc.dto.Admin;
import com.cg.boc.dto.Customer;
import com.cg.boc.dto.TransactionDetails;
import com.cg.boc.dto.User;
import com.cg.boc.exception.CustomerException;



@Repository("admindao")
public class AdminDaoImpl implements AdminDao{
	@PersistenceContext
	private EntityManager entityManager;
	@Override
	public Admin matchLogin(Admin admin) {
		boolean flag=false;
		System.out.println("in dao id:"+admin.getAdmin_id());
		System.out.println("in dao password"+admin.getPassword());
		
	Admin admin_test = entityManager.find(Admin.class,admin.getAdmin_id());
		
	System.out.println("In dao admin_test"+ admin_test);

		
	
		return admin_test;
	}
	
	public boolean addCustomer(Customer customer) throws CustomerException{
		System.out.println(customer.toString());
		try {
			entityManager.persist(customer);
		} catch (Exception e) {
			throw new CustomerException("Can not add");
		}
	
		return true;                                                                  
	}
	
	public Customer getId(Customer customer){
		customer = entityManager.find(Customer.class, customer.getAccount_id());
		System.out.println("in dao :"+customer);
		return customer;
	}
	

	public boolean addinAccount_Master(Account_Master acc_master) {
		
		entityManager.persist(acc_master);
		System.out.println("3");
		return true;                                                                  
	}
	
	public boolean addinUserTable(User user) throws CustomerException{
		System.out.println(user.toString());
		try {
		entityManager.persist(user);
		} catch (Exception e) {
			throw new CustomerException("Can not add");
		}
		System.out.println("2");
		return true;                                                                  
	}
	
	public List<TransactionDetails> TransactionsDetails() {
		TypedQuery qry = entityManager.createQuery("select t from Transactions t",TransactionDetails.class);
		List<TransactionDetails> list = qry.getResultList();
		return list;
	}
	
	public boolean changemobile(Customer customer) throws CustomerException{
	
		
			Customer customer_test=entityManager.merge(customer);
			System.out.println("new customer in dao:"+customer_test);

	
		
	
		return true;
	}
}
