select * from accountmaster;
select * from customer;
select * from payeetable;
select * from servicetracker;
select * from user_table;
select * from transaction;
select * from fundtransfer;

drop table customer cascade constraints;
drop table ACCOUNTMASTER cascade constraints;
drop table payeetable cascade constraints;
drop table user_Table;
drop table ServiceTracker;
drop table FundTransfer;
drop table transaction;


truncate table customer ;
truncate table accountmaster;
truncate table payeetable ;
truncate table user_Table;
truncate table ServiceTracker;
truncate table FundTransfer;
truncate table transaction;

delete from payeeTable where payeeaccountid=987456;

drop sequence account_seq;
drop sequence accountcust_seq;
drop sequence fund_seq;
drop sequence serv_seq;
drop sequence tran_seq;

