package com.capgemini.logger;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.helpers.Loader;
import java.net.URL;


public class LogInfo 
{

		public void configure(){ }

	    public void configureLogging() throws Throwable 
	    {
	         Logger myLog = Logger.getLogger(LogInfo.class);
	         
	         URL url=Loader.getResource("log4j.properties");
	    }
}
