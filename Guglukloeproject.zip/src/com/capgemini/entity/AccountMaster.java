package com.capgemini.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity(name="AccountMaster")
@Table(name="AccountMaster")
public class AccountMaster extends AccountId
{
	@Id
	@Column(name="Account_Id")
	@NotNull(message="Account Id cannot be Null")
	@Min(value=4, message="Minimum 4 and Maximum 10 digits allowed.")
	@GeneratedValue(generator="account_seq", strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(sequenceName="account_seq", name="account_seq", initialValue=3000, allocationSize=1)
	private int accountId;
	
	@Column(name="Account_Type")
	@NotEmpty(message="At least one has to be selected")
	private String accountType;
	
	@Column(name="Account_Balance")
	@Min(value=0, message="Provide positive account balance.")
	private double accountBalance;
	
	@Column(name="Open_Date")
	@Temporal(TemporalType.DATE)
	private Date openDate=new Date();
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="Account_Id")
	@Valid
	private Customer customer;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="Account_Id")
	private UserTable user;

	public Customer getCustomer() {
		return customer;
	}


	public UserTable getUser() {
		return user;
	}

	public void setUser(UserTable user) {
		this.user = user;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	public Date getOpenDate() {
		return openDate;
	}

	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}

	public AccountMaster(String accountType,
			double accountBalance, Date openDate) {
		super();
		
		this.accountType = accountType;
		this.accountBalance = accountBalance;
		this.openDate = openDate;
	}

	public AccountMaster() {
		super();
	}

	/*@Override
	public String toString() {
		return "AccountMaster [accountType="
				+ accountType + ", accountBalance=" + accountBalance
				+ ", openDate=" + openDate + "]";
	}
*/
	
	public int getAccountId() {
		return accountId;
	}

	@Override
	public String toString() {
		return "AccountMaster [accountId=" + accountId + ", accountType="
				+ accountType + ", accountBalance=" + accountBalance
				+ ", openDate=" + openDate + "]";
	}


	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}


	
	
}
