package com.cg.ois.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.ois.dto.AccountMaster;
import com.cg.ois.dto.Customer;
import com.cg.ois.dto.ServiceTracker;
import com.cg.ois.dto.Transaction;

@Repository("bankdao")
public class BankDaoImpl implements IBankDao
{

	@PersistenceContext
	EntityManager entitymanager;
	
	@Override
	public int insertAccountHolder(Customer customer) 
	{

		entitymanager.persist(customer);
		entitymanager.flush();
		return customer.getAccountId();
		
	}

	@Override
	public int insertAccount(AccountMaster account) {

		entitymanager.persist(account);
		entitymanager.flush();
		return account.getAccountId();
	}

	@Override
	public int createAccountNo() {
		
		
		return 0;
	}

	@Override
	public List<ServiceTracker> showall() 
	{
	
		Query queryOne = entitymanager.createQuery("From ServiceTracker");
		List<ServiceTracker> allServices = queryOne.getResultList();
		return allServices;
	}

	@Override
	public void updateTracker(int accountId, int serviceId, String status) 
	{
			
		
	}

	@Override
	public ServiceTracker searchserviceid(int serviceId)
	{
		Query queryFive = entitymanager.createQuery("From ServiceTracker where serviceId =:service_id");
		queryFive.setParameter("service_id", serviceId);
		ServiceTracker service = (ServiceTracker) queryFive.getSingleResult();
		return service;
	}

	@Override
	public List<Transaction> getAllTransactions()
	{
		Query queryOne = entitymanager.createQuery("From Transaction");
		List<Transaction> allTransaction = queryOne.getResultList();
		return allTransaction;
		
	}

}
