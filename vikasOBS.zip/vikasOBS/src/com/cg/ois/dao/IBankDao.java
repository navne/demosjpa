package com.cg.ois.dao;

import java.util.List;

import com.cg.ois.dto.AccountMaster;
import com.cg.ois.dto.Customer;
import com.cg.ois.dto.ServiceTracker;
import com.cg.ois.dto.Transaction;



public interface IBankDao 
{
	public int insertAccountHolder(Customer customer) ;
	public int insertAccount(AccountMaster account) ;
	public int createAccountNo() ;
	public List<ServiceTracker> showall() ;
	void updateTracker(int accountId, int serviceId, String status) ;
	public ServiceTracker searchserviceid(int serviceId) ;
	public List<Transaction> getAllTransactions() ;
}
