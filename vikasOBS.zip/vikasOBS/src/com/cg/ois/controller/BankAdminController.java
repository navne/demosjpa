package com.cg.ois.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ois.dto.Customer;
import com.cg.ois.dto.ServiceTracker;
import com.cg.ois.dto.Transaction;
import com.cg.ois.service.IBankService;




@Controller
public class BankAdminController
{
	@Autowired
	IBankService bankservice;
	
	@RequestMapping(value="newaccount",method=RequestMethod.GET)
	public String insertAccountHolder(@ModelAttribute("my") Customer customer, Map<String, Object>model )
	{
		ArrayList<String> myList = new ArrayList<String>();
		myList.add("Savings");
		myList.add("Current");
		myList.add("Demat");
		
		
		model.put("cType", myList);
		
		return "newaccount";
	}
	
	
	
	@RequestMapping(value="putData", method=RequestMethod.POST)
	public String dataAdd(@ModelAttribute("my") Customer customer)
	{
		bankservice.insertAccountHolder(customer);
		return "redirect:/operationList.jsp";
	}
	
	@RequestMapping(value="viewalltransaction", method=RequestMethod.GET)
	public ModelAndView showData()
	{
		List<Transaction> dataList=bankservice.getAllTransactions();
		
		return new ModelAndView("transactiondetails", "mList", dataList);
		
	}
	
	@RequestMapping(value="trackallservices", method=RequestMethod.GET)
	public ModelAndView showServices()
	{
		List<ServiceTracker> serviceList=bankservice.showall();
		
		return new ModelAndView("trackService", "sList", serviceList);
		
	}
	
}

	
	

