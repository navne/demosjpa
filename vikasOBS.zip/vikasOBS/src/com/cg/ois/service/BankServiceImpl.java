package com.cg.ois.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ois.dao.IBankDao;
import com.cg.ois.dto.AccountMaster;
import com.cg.ois.dto.Customer;
import com.cg.ois.dto.ServiceTracker;
import com.cg.ois.dto.Transaction;

@Service("bankservice")
@Transactional
public class BankServiceImpl implements IBankService
{
	@Autowired
	IBankDao bankdao;

	@Override
	public int insertAccountHolder(Customer customer)
	{
		
		return bankdao.insertAccountHolder(customer);
		
	}

	@Override
	public int insertAccount(AccountMaster account) {
		return 0;
		
		
	}

	@Override
	public int createAccountNo() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<ServiceTracker> showall() {
	
		return bankdao.showall();
	}

	@Override
	public void updateTracker(int accountId, int serviceId, String status) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ServiceTracker searchserviceid(int serviceId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transaction> getAllTransactions() {
		
		return bankdao.getAllTransactions();
	}
	
}
