package com.cg.ois.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "servicetracker")
public class ServiceTracker 
{
	@Id
	@Column(name = "service_id")
	private int serviceId;
	@Column(name = "service_description")
	private String serviceDescripton;
	@Column(name = "account_id")
	private int accountId;
	@Column(name = "service_Raised_Date")
	private Date serviceRaisedDate;
	@Column(name = "service_status")
	private String serviceStatus;
	public ServiceTracker() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ServiceTracker(int serviceId, String serviceDescripton,
			int accountId, Date serviceRaisedDate, String serviceStatus) {
		super();
		this.serviceId = serviceId;
		this.serviceDescripton = serviceDescripton;
		this.accountId = accountId;
		this.serviceRaisedDate = serviceRaisedDate;
		this.serviceStatus = serviceStatus;
	}
	@Override
	public String toString() {
		return "ServiceTracker [serviceId=" + serviceId
				+ ", serviceDescripton=" + serviceDescripton + ", accountId="
				+ accountId + ", serviceRaisedDate=" + serviceRaisedDate
				+ ", serviceStatus=" + serviceStatus + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accountId;
		result = prime
				* result
				+ ((serviceDescripton == null) ? 0 : serviceDescripton
						.hashCode());
		result = prime * result + serviceId;
		result = prime
				* result
				+ ((serviceRaisedDate == null) ? 0 : serviceRaisedDate
						.hashCode());
		result = prime * result
				+ ((serviceStatus == null) ? 0 : serviceStatus.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ServiceTracker other = (ServiceTracker) obj;
		if (accountId != other.accountId)
			return false;
		if (serviceDescripton == null) {
			if (other.serviceDescripton != null)
				return false;
		} else if (!serviceDescripton.equals(other.serviceDescripton))
			return false;
		if (serviceId != other.serviceId)
			return false;
		if (serviceRaisedDate == null) {
			if (other.serviceRaisedDate != null)
				return false;
		} else if (!serviceRaisedDate.equals(other.serviceRaisedDate))
			return false;
		if (serviceStatus == null) {
			if (other.serviceStatus != null)
				return false;
		} else if (!serviceStatus.equals(other.serviceStatus))
			return false;
		return true;
	}
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public String getServiceDescripton() {
		return serviceDescripton;
	}
	public void setServiceDescripton(String serviceDescripton) {
		this.serviceDescripton = serviceDescripton;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public Date getServiceRaisedDate() {
		return serviceRaisedDate;
	}
	public void setServiceRaisedDate(Date serviceRaisedDate) {
		this.serviceRaisedDate = serviceRaisedDate;
	}
	public String getServiceStatus() {
		return serviceStatus;
	}
	public void setServiceStatus(String serviceStatus) {
		this.serviceStatus = serviceStatus;
	}
	
	
}
